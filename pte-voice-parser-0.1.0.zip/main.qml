import QtQuick
import QtQuick.Controls
import QtWebEngine
import org.qfield 1.0

Item {
    id: root

    // ─── INIT: aggiungi bottone alla toolbar ───────────────────
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micButton)
    }

    // ─── BOTTONE TOOLBAR ──────────────────────────────────────
    QfToolButton {
        id: micButton
        iconSource: Qt.resolvedUrl("mic.svg")
        text: "PTE Voice"
        toolTip: "Cattura punto PTE con voce"
        onClicked: {
            captureAndOpen()
        }
    }

    // ─── LOGICA CATTURA GPS + APERTURA DIALOG ─────────────────
    function captureAndOpen() {
        var pos = iface.positioning().sourcePosition

        if (!pos || !pos.isValid) {
            iface.mainWindow().displayToast("GPS non disponibile. Attendi fix.")
            return
        }

        // Salva le coordinate per dopo
        root.capturedLat = pos.coordinate.latitude
        root.capturedLon = pos.coordinate.longitude
        root.capturedAlt = pos.coordinate.altitude || 0

        iface.mainWindow().displayToast(
            "📍 Posizione acquisita: " +
            root.capturedLat.toFixed(6) + ", " +
            root.capturedLon.toFixed(6)
        )

        // Apre il dialog voice parser
        voiceDialog.open()
    }

    property double capturedLat: 0
    property double capturedLon: 0
    property double capturedAlt: 0

    // ─── DIALOG PRINCIPALE ────────────────────────────────────
    Dialog {
        id: voiceDialog
        parent: iface.mainWindow()
        anchors.centerIn: parent

        width: Math.min(parent.width * 0.96, 700)
        height: parent.height * 0.88

        title: "PTE Voice Parser"
        modal: true

        background: Rectangle {
            color: "#0f1117"
            radius: 12
        }

        header: Item {
            width: parent.width
            height: 48

            Rectangle {
                anchors.fill: parent
                color: "#1a1d27"
                radius: 12

                Text {
                    anchors.centerIn: parent
                    text: "⚡ PTE Voice Parser"
                    color: "#5ba3ff"
                    font.pixelSize: 16
                    font.bold: true
                }

                // Tasto chiudi
                Rectangle {
                    anchors.right: parent.right
                    anchors.rightMargin: 12
                    anchors.verticalCenter: parent.verticalCenter
                    width: 30; height: 30
                    radius: 15
                    color: closeHover.containsMouse ? "#3a1a1a" : "transparent"

                    Text {
                        anchors.centerIn: parent
                        text: "✕"
                        color: "#8890a8"
                        font.pixelSize: 14
                    }

                    HoverHandler { id: closeHover }
                    TapHandler {
                        onTapped: voiceDialog.close()
                    }
                }
            }
        }

        // ── WebView con il parser HTML ──
        WebEngineView {
            id: webView
            anchors.fill: parent
            url: Qt.resolvedUrl("pte_parser.html")

            // Permessi microfono
            onFeaturePermissionRequested: function(securityOrigin, feature) {
                if (feature === WebEngineView.MediaAudioCapture) {
                    grantFeaturePermission(securityOrigin, feature, true)
                }
            }

            // Intercetta il risultato da JS
            onJavaScriptConsoleMessage: function(level, message, lineNumber, sourceID) {
                if (message.startsWith("QFIELD_RESULT:")) {
                    var jsonStr = message.replace("QFIELD_RESULT:", "")
                    try {
                        var data = JSON.parse(jsonStr)
                        root.applyFeature(data)
                        voiceDialog.close()
                    } catch(e) {
                        iface.mainWindow().displayToast("Errore JSON: " + e)
                    }
                }
            }
        }

        footer: null
    }

    // ─── APPLICA FEATURE AL LAYER ATTIVO ─────────────────────
    function applyFeature(data) {
        var layer = iface.mapCanvas().currentLayer

        if (!layer) {
            iface.mainWindow().displayToast("⚠ Nessun layer attivo. Seleziona un layer.")
            return
        }

        if (!layer.isEditable()) {
            layer.startEditing()
        }

        // Crea geometria punto dalle coordinate GPS catturate
        var wkt = "POINT(" + root.capturedLon + " " + root.capturedLat + ")"

        // Usa le utilities QField per creare la feature
        var utils = iface.findItemByObjectName("featureUtils")

        if (utils) {
            // Approccio con featureUtils
            utils.createFeatureWithGeometry(layer, wkt, function(feature) {
                applyAttributes(feature, layer, data)
            })
        } else {
            // Fallback: apri il form di digitalizzazione standard
            // con le coordinate preimpostate
            iface.mainWindow().displayToast(
                "✔ Dati vocali pronti. Usa il digitalizzatore per piazzare il punto."
            )
            // Salva i dati per uso nel form
            root.pendingData = data
        }
    }

    property var pendingData: null

    function applyAttributes(feature, layer, data) {
        // Mappa i campi JSON → attributi del layer
        // Adatta i nomi se diversi nel tuo gpkg
        var fieldMap = {
            "stato":          "stato",
            "tipologia":      "tipologia",
            "quartina":       "quartina",
            "armadio":        "armadio",
            "tipo":           "tipo",
            "cavi_attestati": "cavi_attestati",
            "ubicazione":     "ubicazione",
            "note":           "note"
        }

        for (var jsonKey in fieldMap) {
            var layerField = fieldMap[jsonKey]
            var val = data[jsonKey]
            if (val !== undefined && val !== "") {
                var idx = layer.fields().indexFromName(layerField)
                if (idx >= 0) {
                    feature.setAttribute(idx, val)
                }
            }
        }

        layer.updateFeature(feature)
        layer.commitChanges()

        iface.mainWindow().displayToast(
            "✅ PTE salvato: " + (data.stato || "") + " " + (data.tipologia || "")
        )
    }

    // ─── TASTO HARDWARE BT MICROFONO ─────────────────────────
    // Intercetta il tasto fisico del microfono BT
    Item {
        focus: true
        Keys.onPressed: function(event) {
            // Key_MediaRecord = tasto record BT
            // Key_Microphone  = tasto mic BT (alcuni modelli)
            if (event.key === Qt.Key_MediaRecord ||
                event.key === Qt.Key_Microphone  ||
                event.key === Qt.Key_Camera) {
                if (!voiceDialog.visible) {
                    captureAndOpen()
                }
                event.accepted = true
            }
        }
    }
}
