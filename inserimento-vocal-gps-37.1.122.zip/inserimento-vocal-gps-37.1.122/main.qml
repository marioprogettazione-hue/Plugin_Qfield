import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null
    property var selectedLayerDef: null
    // v37.0.30: ricorda il layer originalmente attivo prima del plugin
    property var prevActiveLayer: null
    // v37.1.1: true mentre e' il plugin a cambiare activeLayer (evita auto-rilascio)
    property bool settingLayerInternally: false
    // v37.1.3: diagnostica layer live
    property string dbgLayers: ""
    property bool dbgVisible: false

    property int okCount: 0
    property var parsedData: ({})

    // Stato linea
    property bool lineMode: false
    property var lineVertices: []
    property real pendingX: 0
    // v37.0.26: GPS accuracy check
    // v37.0.32: PIN / licenza
    property string licenseUrl: "https://script.google.com/macros/s/AKfycbxoFrJQFgBd9so6KxL8BrnjPT8JqWKvVsaqtDTGb_NOnE1AhFkB1QdE4nKagg2oH3-WMQ/exec"
    property string licenseDeviceId: ""
    property string licensePin: ""
    property string licenseNome: ""
    property string licenseScadenza: ""
    property bool licenseValid: false
    property bool licenseChecked: false
    property bool licenseInProgress: false
    // v37.0.39: disattivazione remota
    property bool licenseRevalidating: false
    property string licenseRevalidatedAt: ""
    property string licenseDeactivationMsg: ""
    // v37.0.40: verifica giornaliera con posticipi
    property string licenseLastCheckTs: ""        // ISO datetime ultima verifica OK
    property int licensePostponeCount: 0          // 0..2 quante volte ho posticipato
    property string licensePostponeUntilTs: ""    // ISO datetime fino a quando ho posticipato
    property string licenseNetError: ""           // errore di rete da mostrare nel popup
    property bool licenseBlockedOffline: false    // bloccato perché server irraggiungibile dopo 2 posticipi

    function generateDeviceId() {
        // hex random di 16 char
        var chars = "0123456789abcdef"
        var s = ""
        for (var i = 0; i < 16; i++) {
            s += chars.charAt(Math.floor(Math.random() * 16))
        }
        return s
    }

    // v37.0.38: persistenza via Qt.labs.settings (SharedPreferences su Android)
    // con fallback su file se Settings non disponibile
    property string licenseLastWrittenPath: ""
    property string licenseLastError: ""
    property var _licenseSettings: null

    function getLicenseSettings() {
        if (plugin._licenseSettings) return plugin._licenseSettings
        // prova Qt.labs.settings (Qt 5/6)
        var variants = [
            'import Qt.labs.settings 1.0; Settings { category: "VocalGpsPlugin"; property string pin: ""; property string nome: ""; property string scadenza: ""; property string deviceId: ""; property string lastCheckTs: ""; property int postponeCount: 0; property string postponeUntilTs: "" }',
            'import Qt.labs.settings; Settings { category: "VocalGpsPlugin"; property string pin: ""; property string nome: ""; property string scadenza: ""; property string deviceId: ""; property string lastCheckTs: ""; property int postponeCount: 0; property string postponeUntilTs: "" }',
            'import QtCore; Settings { category: "VocalGpsPlugin"; property string pin: ""; property string nome: ""; property string scadenza: ""; property string deviceId: ""; property string lastCheckTs: ""; property int postponeCount: 0; property string postponeUntilTs: "" }'
        ]
        for (var i = 0; i < variants.length; i++) {
            try {
                var s = Qt.createQmlObject(variants[i], plugin, "licSet" + i)
                if (s) {
                    plugin._licenseSettings = s
                    plugin.licenseLastWrittenPath = "Qt.Settings (variant " + i + ")"
                    return s
                }
            } catch(e) {
                if (i === variants.length - 1) {
                    plugin.licenseLastError = "Settings unavailable: " + ("" + e).substring(0, 100)
                }
            }
        }
        return null
    }

    function licensePaths() {
        var paths = []
        paths.push("/storage/emulated/0/Android/data/ch.opengis.qfield/files/QField/vocal_gps_license.json")
        paths.push("/storage/emulated/0/Android/data/ch.opengis.qfield/files/vocal_gps_license.json")
        try {
            if (qgisProject && qgisProject.homePath) {
                paths.push(qgisProject.homePath + "/.vocal_gps_license.json")
            }
        } catch(e) {}
        paths.push("/storage/emulated/0/Download/vocal_gps_license.json")
        return paths
    }

    function readLicenseFile() {
        var paths = licensePaths()
        for (var i = 0; i < paths.length; i++) {
            try {
                var content = FileUtils.readFileContent(paths[i])
                if (content && ("" + content).length > 0) {
                    return { path: paths[i], content: "" + content }
                }
            } catch(e) {}
        }
        return null
    }

    function writeLicenseFile(payload) {
        var paths = licensePaths()
        plugin.licenseLastError = ""
        var errors = []
        for (var i = 0; i < paths.length; i++) {
            var p = paths[i]
            // Estrai directory parent e nome file
            var lastSlash = p.lastIndexOf("/")
            var parent = lastSlash >= 0 ? p.substring(0, lastSlash) : ""
            var name = lastSlash >= 0 ? p.substring(lastSlash + 1) : p
            // v37.0.37: pre-crea la directory tramite platformUtilities (proven working)
            try {
                if (parent !== "") {
                    var pLastSlash = parent.lastIndexOf("/")
                    var pParent = pLastSlash >= 0 ? parent.substring(0, pLastSlash) : ""
                    var pName = pLastSlash >= 0 ? parent.substring(pLastSlash + 1) : parent
                    platformUtilities.createDir(pParent, pName)
                }
            } catch(eD) {}
            // Tentativo 1: writeFileContent(path, content)
            var wRet = "?"
            try {
                wRet = "" + FileUtils.writeFileContent(p, payload)
            } catch(eW) {
                errors.push(name + ": exc " + ("" + eW).substring(0, 60))
                continue
            }
            // Verifica leggendo
            try {
                var check = FileUtils.readFileContent(p)
                var checkStr = "" + (check || "")
                if (checkStr.length > 0) {
                    plugin.licenseLastWrittenPath = p
                    return true
                } else {
                    errors.push(name + ": wRet=" + wRet + " readEmpty")
                }
            } catch(eR) { errors.push(name + ": readbackErr " + eR) }
        }
        plugin.licenseLastError = errors.join(" | ")
        return false
    }

    function loadOrCreateDeviceId() {
        // Prova Settings prima
        var s = getLicenseSettings()
        if (s && s.deviceId && s.deviceId.length > 0) {
            plugin.licenseDeviceId = "" + s.deviceId
            return
        }
        // Prova file fallback
        var rec = readLicenseFile()
        if (rec) {
            try {
                var data = JSON.parse(rec.content)
                if (data && data.deviceId) {
                    plugin.licenseDeviceId = "" + data.deviceId
                    return
                }
            } catch(e) {}
        }
        // Genera nuovo deviceId
        plugin.licenseDeviceId = generateDeviceId()
        if (s) {
            try { s.deviceId = plugin.licenseDeviceId } catch(eS) {}
        } else {
            // fallback file
            var payload = JSON.stringify({
                deviceId: plugin.licenseDeviceId,
                pin: "", nome: "", scadenza: ""
            })
            writeLicenseFile(payload)
        }
    }

    function loadStoredLicense() {
        loadCheckState()  // v37.0.40
        // Prova Settings prima
        var s = getLicenseSettings()
        if (s && s.pin && s.pin.length > 0 && s.nome && s.nome.length > 0) {
            plugin.licensePin = "" + s.pin
            plugin.licenseNome = "" + s.nome
            plugin.licenseScadenza = "" + (s.scadenza || "")
            if (s.deviceId && !plugin.licenseDeviceId) {
                plugin.licenseDeviceId = "" + s.deviceId
            }
            // verifica scadenza
            if (plugin.licenseScadenza) {
                var today = new Date()
                var todayStr = today.getFullYear() + "-" +
                               ("0" + (today.getMonth()+1)).slice(-2) + "-" +
                               ("0" + today.getDate()).slice(-2)
                if (plugin.licenseScadenza < todayStr) {
                    plugin.licenseValid = false
                    return
                }
            }
            plugin.licenseValid = true
            return
        }
        // Fallback su file
        var rec = readLicenseFile()
        if (!rec) return
        try {
            var data = JSON.parse(rec.content)
            if (!data) return
            plugin.licenseLastWrittenPath = rec.path
            if (data.deviceId && !plugin.licenseDeviceId) {
                plugin.licenseDeviceId = "" + data.deviceId
            }
            if (data.pin && data.nome) {
                plugin.licensePin = "" + data.pin
                plugin.licenseNome = "" + data.nome
                plugin.licenseScadenza = "" + (data.scadenza || "")
                if (plugin.licenseScadenza) {
                    var today2 = new Date()
                    var todayStr2 = today2.getFullYear() + "-" +
                                    ("0" + (today2.getMonth()+1)).slice(-2) + "-" +
                                    ("0" + today2.getDate()).slice(-2)
                    if (plugin.licenseScadenza < todayStr2) {
                        plugin.licenseValid = false
                        return
                    }
                }
                plugin.licenseValid = true
            }
        } catch(e) {}
    }

    function saveLicense(pin, nome, scadenza) {
        plugin.licensePin = pin
        plugin.licenseNome = nome
        plugin.licenseScadenza = scadenza || ""
        plugin.licenseValid = true
        // v37.0.40: attivazione conta come verifica riuscita
        saveSuccessfulCheck()
        // Prova Settings prima
        var s = getLicenseSettings()
        if (s) {
            try {
                s.pin = pin
                s.nome = nome
                s.scadenza = scadenza || ""
                if (!s.deviceId || s.deviceId.length === 0) {
                    s.deviceId = plugin.licenseDeviceId
                }
                plugin.licenseLastWrittenPath = "Qt.Settings OK"
                return
            } catch(eS) {
                plugin.licenseLastError = "Settings write err: " + eS
            }
        }
        // Fallback su file
        var payload = JSON.stringify({
            deviceId: plugin.licenseDeviceId,
            pin: pin,
            nome: nome,
            scadenza: scadenza || ""
        })
        writeLicenseFile(payload)
    }

    function verifyLicense(pin, onDone) {
        plugin.licenseInProgress = true
        // v37.0.34: GET con query string (POST causa 405 su Apps Script)
        var url = plugin.licenseUrl +
                  "?pin=" + encodeURIComponent(pin) +
                  "&deviceId=" + encodeURIComponent(plugin.licenseDeviceId) +
                  "&deviceName=" + encodeURIComponent(Qt.platform.os + "-tablet")
        var xhr = new XMLHttpRequest()
        xhr.open("GET", url)
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                plugin.licenseInProgress = false
                var raw = "" + (xhr.responseText || "")
                // Estrai JSON anche da wrapper HTML eventuali
                var jsonStr = raw
                var firstBrace = raw.indexOf("{")
                var lastBrace = raw.lastIndexOf("}")
                if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
                    jsonStr = raw.substring(firstBrace, lastBrace + 1)
                }
                try {
                    var resp = JSON.parse(jsonStr)
                    if (resp && resp.ok) {
                        saveLicense(pin, resp.nome || "?", resp.scadenza || "")
                        if (onDone) onDone(true, resp.nome || "?", "")
                    } else {
                        if (onDone) onDone(false, "", (resp && resp.msg) || "Verifica fallita")
                    }
                } catch(e) {
                    var dbg = "status=" + xhr.status + " resp=" +
                              raw.substring(0, 200).replace(/\s+/g, " ")
                    if (onDone) onDone(false, "", "DEBUG: " + dbg)
                }
            }
        }
        xhr.onerror = function() {
            plugin.licenseInProgress = false
            if (onDone) onDone(false, "", "Errore rete (onerror)")
        }
        try {
            xhr.send()
        } catch(eS) {
            plugin.licenseInProgress = false
            if (onDone) onDone(false, "", "Errore invio: " + eS)
        }
    }

    // v37.0.40: helpers per verifica giornaliera
    function nowIsoStr() {
        return Qt.formatDateTime(new Date(), "yyyy-MM-ddTHH:mm:ss")
    }
    function isoToMs(iso) {
        if (!iso || iso.length === 0) return 0
        var d = new Date(iso.replace(" ", "T"))
        var t = d.getTime()
        return isNaN(t) ? 0 : t
    }
    function loadCheckState() {
        var s = getLicenseSettings()
        if (s) {
            try {
                plugin.licenseLastCheckTs = "" + (s.lastCheckTs || "")
                plugin.licensePostponeCount = parseInt(s.postponeCount || 0) || 0
                plugin.licensePostponeUntilTs = "" + (s.postponeUntilTs || "")
            } catch(e) {}
        }
    }
    function saveSuccessfulCheck() {
        plugin.licenseLastCheckTs = nowIsoStr()
        plugin.licensePostponeCount = 0
        plugin.licensePostponeUntilTs = ""
        plugin.licenseBlockedOffline = false
        plugin.licenseNetError = ""
        var s = getLicenseSettings()
        if (s) {
            try {
                s.lastCheckTs = plugin.licenseLastCheckTs
                s.postponeCount = 0
                s.postponeUntilTs = ""
            } catch(e) {}
        }
    }
    function savePostpone(hours) {
        plugin.licensePostponeCount = plugin.licensePostponeCount + 1
        var until = new Date(new Date().getTime() + hours * 3600 * 1000)
        plugin.licensePostponeUntilTs = Qt.formatDateTime(until, "yyyy-MM-ddTHH:mm:ss")
        var s = getLicenseSettings()
        if (s) {
            try {
                s.postponeCount = plugin.licensePostponeCount
                s.postponeUntilTs = plugin.licensePostponeUntilTs
            } catch(e) {}
        }
    }
    // True se servono >24h dall'ultima verifica E il posticipo è scaduto
    function needsRevalidation() {
        if (!plugin.licensePin || plugin.licensePin.length === 0) return false
        if (plugin.licenseBlockedOffline) return true
        var lastMs = isoToMs(plugin.licenseLastCheckTs)
        // mai verificato? consideralo OK (l'attivazione PIN ha gia' verificato)
        if (lastMs === 0) return false
        var nowMs = new Date().getTime()
        var elapsedH = (nowMs - lastMs) / 3600000
        if (elapsedH < 24) return false
        // verifica posticipo
        var postUntilMs = isoToMs(plugin.licensePostponeUntilTs)
        if (postUntilMs > 0 && nowMs < postUntilMs) return false
        return true
    }

    // v37.0.39: pulisce la licenza memorizzata (Settings + file fallback)
    function clearStoredLicense() {
        plugin.licensePin = ""
        plugin.licenseNome = ""
        plugin.licenseScadenza = ""
        plugin.licenseValid = false
        var s = getLicenseSettings()
        if (s) {
            try {
                s.pin = ""
                s.nome = ""
                s.scadenza = ""
            } catch(e) {}
        }
        try {
            var payload = JSON.stringify({
                deviceId: plugin.licenseDeviceId,
                pin: "", nome: "", scadenza: ""
            })
            writeLicenseFile(payload)
        } catch(eF) {}
    }

    // v37.0.39: re-verifica server-side della licenza memorizzata
    // Se il server risponde DISABLED/NOT_FOUND -> pulisce la licenza locale
    // Se errore di rete -> mantiene la licenza locale (modalita offline)
    function revalidateLicense() {
        if (!plugin.licensePin || plugin.licensePin.length === 0) return
        if (plugin.licenseRevalidating) return
        plugin.licenseRevalidating = true
        var url = plugin.licenseUrl +
                  "?pin=" + encodeURIComponent(plugin.licensePin) +
                  "&deviceId=" + encodeURIComponent(plugin.licenseDeviceId) +
                  "&deviceName=" + encodeURIComponent(Qt.platform.os + "-revalidate") +
                  "&action=check"
        var xhr = new XMLHttpRequest()
        xhr.open("GET", url)
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            plugin.licenseRevalidating = false
            if (xhr.status !== 200) return
            var raw = "" + (xhr.responseText || "")
            var firstBrace = raw.indexOf("{")
            var lastBrace = raw.lastIndexOf("}")
            if (firstBrace === -1 || lastBrace === -1) return
            try {
                var resp = JSON.parse(raw.substring(firstBrace, lastBrace + 1))
                if (!resp) return
                if (resp.ok === false &&
                    (resp.code === "DISABLED" || resp.code === "NOT_FOUND" || resp.code === "WRONG_DEVICE")) {
                    clearStoredLicense()
                    plugin.licenseDeactivationMsg = resp.msg || "Licenza disattivata"
                    plugin.licenseChecked = true
                    try { mainWindow.displayToast("Licenza disattivata: " + (resp.msg || "")) } catch(eT) {}
                    plugin.licenseRevalidatedAt = Qt.formatDateTime(new Date(), "HH:mm")
                } else if (resp.ok === true) {
                    if (resp.nome) plugin.licenseNome = "" + resp.nome
                    if (resp.scadenza) plugin.licenseScadenza = "" + resp.scadenza
                    plugin.licenseRevalidatedAt = Qt.formatDateTime(new Date(), "HH:mm")
                    saveSuccessfulCheck()  // v37.0.40
                    var ss = getLicenseSettings()
                    if (ss) {
                        try {
                            ss.nome = plugin.licenseNome
                            ss.scadenza = plugin.licenseScadenza
                        } catch(eU) {}
                    }
                }
            } catch(e) {}
        }
        try { xhr.send() } catch(eS) { plugin.licenseRevalidating = false }
    }

    // v37.1.114 (Step 3): interpreta il valore della colonna "nativo" del foglio,
    // tollerante a piu' formati (booleano JSON, SI/NO, S/N, YES/NO, 1/0, true/false).
    function parseNativoFlag(v) {
        if (v === true) return true
        if (v === false || v === undefined || v === null) return false
        var s = ("" + v).trim().toUpperCase()
        return (s === "SI" || s === "S" || s === "YES" || s === "Y" ||
                s === "1" || s === "TRUE")
    }

    // v37.1.114 (Step 3): ricontrolla lo stato di sblocco nativo per l'operatore
    // corrente leggendo il campo "nativo" dalla stessa risposta dell'Apps Script
    // gia' usata per la licenza. Chiamata all'avvio e ogni 30 minuti (nativeCheckTimer),
    // INDIPENDENTEMENTE dall'apertura del pannello plugin — cosi' un operatore che
    // lavora tutto il giorno solo col nativo riceve comunque l'aggiornamento/reset.
    // FAIL-SAFE: qualunque dubbio (nessun PIN, errore di rete, risposta non valida,
    // campo assente) -> nativeInhibited torna/resta TRUE (bloccato). Non si sblocca
    // mai "per errore" o "per default".
    function checkNativeUnlock() {
        if (!plugin.licensePin || plugin.licensePin.length === 0) {
            plugin.nativeInhibited = true
            return
        }
        var url = plugin.licenseUrl +
                  "?pin=" + encodeURIComponent(plugin.licensePin) +
                  "&deviceId=" + encodeURIComponent(plugin.licenseDeviceId) +
                  "&deviceName=" + encodeURIComponent(Qt.platform.os + "-nativecheck") +
                  "&action=check"
        var xhr = new XMLHttpRequest()
        try {
            xhr.open("GET", url)
        } catch (eO) {
            plugin.nativeInhibited = true
            return
        }
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status !== 200) { plugin.nativeInhibited = true; return }
            var raw = "" + (xhr.responseText || "")
            var firstBrace = raw.indexOf("{")
            var lastBrace = raw.lastIndexOf("}")
            if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
                plugin.nativeInhibited = true
                return
            }
            try {
                var resp = JSON.parse(raw.substring(firstBrace, lastBrace + 1))
                if (resp && resp.ok === true) {
                    plugin.nativeInhibited = !parseNativoFlag(resp.nativo)
                } else {
                    plugin.nativeInhibited = true
                }
            } catch (eP) {
                plugin.nativeInhibited = true
            }
        }
        xhr.onerror = function() { plugin.nativeInhibited = true }
        try {
            xhr.send()
        } catch (eS) {
            plugin.nativeInhibited = true
        }
    }

    // v37.1.117 (Step 3c) + v37.1.120 (Step 3f): pilota da codice il blocco nativo
    // su TUTTI i layer funzionali, con DUE meccanismi combinati:
    //  1) sessione di editing (startEditing/rollBack) - blocca inserimento e
    //     modifica geometria, confermato sul campo (test A/B), senza rompere il
    //     salvataggio del plugin.
    //  2) layer.readOnly - confermato che blocca ANCHE la modifica attributi
    //     nativa (che il solo toggle sessione non copriva), ma va tolto durante
    //     la finestra in cui il PLUGIN scrive (altrimenti "feature addition
    //     disabled" sulle linee) - vedi onPluginDrawerOpenChanged sopra.
    // allow=true  -> sblocca (matita accesa + readOnly=false)
    // allow=false -> blocca (matita spenta + readOnly=true; annulla anche eventuali
    //                modifiche native non salvate rimaste a meta' se l'operatore
    //                stava usando il nativo nell'istante in cui e' scattato il
    //                blocco - e' il comportamento voluto)
    // v37.1.122 (Step 3h): diagnostica - readOnly effettivo di ogni layer dopo
    // l'ultima chiamata, cosi' se "feature addition disabled" si ripresenta
    // ancora si vede subito se il problema e' che readOnly non e' davvero
    // sceso a false (invece di continuare a indovinare). Consultabile con
    // 🧪 Probe Gatherer API nel pannello Impostazioni.
    property string nativeUnlockDiag: ""
    function applyNativeLayerEditState(allow) {
        var diagParts = []
        for (var i = 0; i < plugin.allLayerNames.length; i++) {
            var name = plugin.allLayerNames[i]
            try {
                var arr = qgisProject.mapLayersByName(name)
                if (!arr || arr.length === 0) { diagParts.push(name + ":no-layer"); continue }
                var lyr = arr[0]
                // v37.1.122 (Step 3h): ordine CRITICO - readOnly va cambiato PRIMA di
                // startEditing()/rollBack(), non dopo. Con l'ordine vecchio, quando si
                // sblocca (allow=true), startEditing() veniva chiamato mentre il layer
                // era ANCORA readOnly=true in quell'istante, quindi falliva/no-op in
                // silenzio - il layer restava senza sessione di editing attiva anche se
                // un attimo dopo readOnly diventava false. Era la causa di "feature
                // addition disabled" rimasta anche dopo il fix v37.1.121 sull'ordine
                // rispetto a drawer.state.
                if (allow) {
                    try { lyr.readOnly = false } catch (eRO1) {}
                    if (typeof lyr.startEditing === "function") lyr.startEditing()
                } else {
                    try { lyr.readOnly = true } catch (eRO2) {}
                    if (typeof lyr.rollBack === "function") lyr.rollBack()
                }
                diagParts.push(name + ":ro=" + lyr.readOnly)
            } catch (e) {
                diagParts.push(name + ":EXC=" + e)
            }
        }
        plugin.nativeUnlockDiag = "allow=" + allow + "  " + diagParts.join(" | ")
    }

    function showLicenseScreen() {
        pinPopup.visible = true
    }

    function isLicensed() {
        if (!plugin.licenseChecked) {
            loadOrCreateDeviceId()
            loadStoredLicense()
            plugin.licenseChecked = true
        }
        return plugin.licenseValid
    }

    property int gpsAccuracyThresholdCm: 50    // v37.1.38: default 50 cm (era 100)
    property real pendingAccuracyM: -1
    property bool gpsAccuracyLoaded: false

    function loadGpsThreshold() {
        if (plugin.gpsAccuracyLoaded) return
        try {
            var v = qgisProject.customProperty("vocalGps_gpsThresholdCm")
            if (v !== undefined && v !== null) {
                var n = parseInt(v)
                if (!isNaN(n) && n > 0) plugin.gpsAccuracyThresholdCm = n
            }
        } catch(e) {}
        plugin.gpsAccuracyLoaded = true
    }

    function saveGpsThreshold(cm) {
        var n = parseInt(cm)
        if (isNaN(n) || n < 1) return false
        plugin.gpsAccuracyThresholdCm = n
        try { qgisProject.setCustomProperty("vocalGps_gpsThresholdCm", n) } catch(e) {}
        return true
    }

    // v37.1.38: soglia deriva movimento (cm) configurabile e persistente
    function loadGpsDrift() {
        if (plugin.gpsDriftLoaded) return
        try {
            var v = qgisProject.customProperty("vocalGps_gpsDriftCm")
            if (v !== undefined && v !== null) {
                var n = parseInt(v)
                if (!isNaN(n) && n > 0) plugin.gpsDriftGuardCm = n
            }
        } catch(e) {}
        plugin.gpsDriftLoaded = true
    }

    function saveGpsDrift(cm) {
        var n = parseInt(cm)
        if (isNaN(n) || n < 1) return false
        plugin.gpsDriftGuardCm = n
        try { qgisProject.setCustomProperty("vocalGps_gpsDriftCm", n) } catch(e) {}
        return true
    }
    property real pendingY: 0
    property bool pendingValid: false

    // Auto-cattura
    property int autoCaptureMs: 2500   // v37.1.24: dimezzato da 5000 a 2500ms

    // v37.1.0: cattura posizione asincrona con media (mediana)
    property var    gpsSamples: []            // campioni {x, y, acc}
    property double gpsSampleStartMs: 0
    property bool   gpsSampleActive: false
    property int    gpsSampleMaxMs: 2000      // tetto impostato a runtime
    property int    gpsSampleMaxMsPoint: 2000 // tetto duro per i punti singoli
    property int    gpsSampleMaxMsVertex: 2000 // v37.1.35: come i punti (operatore fermo 2s)
    property bool   pendingLineFirstVertex: false // v37.1.35: primo vertice in attesa di media
    property int    gpsSampleMinGood: 4       // (non piu' usato per stop anticipato)
    property int    gpsDriftGuardCm: 25       // v37.1.38: soglia deriva movimento (cm), configurabile
    property bool   gpsDriftLoaded: false
    property var    gpsBaseline: null         // v37.1.38: centro dei primi campioni "fermi"
    property int    gpsDriftCount: 0          // v37.1.38: campioni consecutivi in deriva

    // v37.1.47: fonte posizione globale: "gps" (media campioni) | "pointer" (centro mappa)
    property string positionMode: "gps"
    property bool   positionModeLoaded: false

    // v37.1.50 (Step 2): inibizione inserimento/modifica NATIVA di QField
    property bool   nativeInhibited: true      // inserimento nativo bloccato; valore iniziale = bloccato
                                                // finche' checkNativeUnlock() (v37.1.114, Step 3) non conferma
                                                // lo sblocco per l'operatore corrente dal foglio Google
    property bool   pluginDrawerOpen: false    // true mentre e' il PLUGIN a usare il drawer (da non bloccare)
    // v37.1.117 (Step 3c): ogni volta che nativeInhibited cambia, allinea subito
    // la sessione di editing di tutti i layer (vedi applyNativeLayerEditState) -
    // blocca/sblocca inserimento e modifica geometria native in un colpo solo.
    onNativeInhibitedChanged: applyNativeLayerEditState(!plugin.nativeInhibited)
    // v37.1.120 (Step 3f): quando il PLUGIN sta per scrivere (pluginDrawerOpen=true,
    // usato sia per inserimento punti/linee sia per modifica attributi/geometria -
    // vedi tutti i punti "drawer.state=..."/"pluginDrawerOpen=true" nel file), sblocca
    // temporaneamente il readOnly su tutti i layer. Risolve "feature addition
    // disabled" avuto sulle linee col readOnly sempre acceso: il layer readOnly
    // impedisce anche alla stessa API di scrittura del plugin di aggiungere feature,
    // quindi va tolto proprio nella finestra in cui il plugin scrive, e rimesso
    // appena pluginDrawerOpen torna false (se il nativo deve restare bloccato).
    onPluginDrawerOpenChanged: {
        if (plugin.pluginDrawerOpen) {
            applyNativeLayerEditState(true)
        } else if (plugin.nativeInhibited) {
            applyNativeLayerEditState(false)
        }
    }
    property var    nativeDrawer: null         // riferimento al drawer nativo
    property var    nativeFeatureListForm: null // v37.1.54: form identificazione/modifica attributi nativo
    // v37.1.62 (Step 2b): modalita' MODIFICA dal plugin
    property bool   editMode: false            // true = stiamo modificando una feature esistente
    property var    editLayer: null            // layer QGIS della feature in modifica
    property var    editLayerDef: null         // definizione plugin del layer
    property var    editFeature: null          // feature esistente in modifica
    property var    editFid: null              // fid della feature in modifica
    property var    editCandidates: []         // risultati identificazione {layerName, fid, label}
    property var    editCand: null             // candidato attualmente in modifica (con props+geom)
    property var    editLiveFeature: null      // v37.1.87: feature VIVA (focusedFeature, id valido)
    property var    editLiveLayer: null        // v37.1.87: layer della feature viva
    property var    editOriginalData: ({})     // v37.1.95: snapshot valori iniziali (per salvare solo i cambiati)
    property bool   editMoveMode: false        // v37.1.106: modalita' spostamento geometria (mirino)
    // v37.1.107: sessione di editing VERTICI
    property bool   editVertexMode: false      // sessione modifica vertici attiva
    property var    editVertices: []           // vertici [x,y] in 32632 (lista piatta, modificabile)
    property var    editVerticesOrig: []       // v37.1.113: posizioni ORIGINALI dei vertici (per il trascinamento)
    property var    editGeomTemplate: null      // geometria GeoJSON originale (per ricostruire la struttura)
    property int    editActiveVertex: -1       // indice del vertice agganciato (-1 = nessuno)
    property int    editVtxRefresh: 0          // contatore per forzare il ridisegno dei vertici
    // v37.1.112: trascinamento topologico (elementi agganciati che seguono)
    property var    dragQueue: []              // feature agganciate da aggiornare {layerName, fid1, wkt}
    property int    dragIdx: 0
    property bool   dragActive: false
    property string editPrefillDiag: ""        // v37.1.98: diagnostica precompilazione (separata)
    property string editAttrDiag: ""           // diagnostica API attributi feature
    property string editSaveDiag: ""           // diagnostica salvataggio modifica
    property var    editPendingDeleteFid: null // fid della vecchia feature da cancellare dopo il save
    property var    editPendingDeleteLayer: null
    property int    saveOpCount: 0             // v37.1.70: contatore diagnostico salvataggi
    // v37.1.55: diagnostica stati form nativi
    property string stateLog: ""
    property string lastFlfState: "?"
    property string lastDrwState: "?"

    // Voice state tracking
    property string lastParsedText: ""
    property string lastLayerVoiceText: ""
    property string lastVertexVoiceText: ""
    property string lastRadialVoiceText: ""
    property string photo1Path: ""
    property string photo2Path: ""
    property int photoSlot: 1  // 1 -> Foto_1, 2 -> Foto_2; alterna ad ogni scatto

    // Radial menu state
    property var currentPresets: []

    // v37.1.27: detection smartphone (lato corto fisico < 4 pollici).
    // Un tablet 8" (16:10) ha lato corto ~4.2", quindi resta nella categoria
    // tablet. Un telefono anche grande (6.7" diagonale) ha lato corto ~3".
    // 25.4 mm per pollice; Screen.pixelDensity = pixel per mm.
    // Su tablet (>= 4") il radial resta INVARIATO (single ring, layout originale).
    // Su smartphone, se i preset sono >= 8, passa a doppio anello concentrico.
    property bool isSmallScreen: {
        try {
            var px = Math.min(Screen.width, Screen.height)
            var inches = px / Screen.pixelDensity / 25.4
            return inches < 4.0
        } catch(e) { return false }
    }
    property bool radialDoubleRing: isSmallScreen && currentPresets.length >= 8

    // ── v37.0.10: SNAP STATE & SETTINGS ────────────────────────
    property int snapMaxCm: 150
    property bool snapEnabled: true
    property var snapMatrix: ({
        "PTE":              ["TRATTE INTERRATE", "RACCORDI"],
        "ARMADIO":          ["TRATTE INTERRATE", "RACCORDI"],
        "POZZETTI":         ["TRATTE INTERRATE", "CAVI"],
        "GIUNTI":           ["POZZETTI", "TRATTE INTERRATE", "CAVI"],
        "PALI":             [],
        "EXTRA":            [],
        "CAVI":             ["GIUNTI", "PTE", "ARMADIO", "POZZETTI"],
        "RACCORDI":         ["PTE", "ARMADIO"],
        "TRATTE INTERRATE": ["TRATTE INTERRATE", "POZZETTI", "ARMADIO", "PTE", "GIUNTI"]
    })
    property var snapPendingCandidates: []
    property int snapPendingIndex: 0
    property var snapPendingResult: ({})
    property string lastSnapVoiceText: ""
    // v37.0.22: cache features per snap (via export GeoJSON)
    property var snapFeatureCache: ({})
    property int snapCacheTTLms: 30000
    property var allLayerNames: ["PTE","ARMADIO","POZZETTI","GIUNTI","PALI","EXTRA","CAVI","RACCORDI","TRATTE INTERRATE"]
    // v37.0.13: diagnostica snap (toast su salvataggio)
    property string snapLastDiag: ""

    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true,
            voiceKeywords: ["pte", "pta", "p t e", "p.t.e", "punto terminazione"],
            fields: [
                { key: "CENTRALE", label: "Codice Centrale", alias: "Codice Centrale", type: "text",
                  required: true, voiceKeys: ["centrale", "codice centrale", "codice", "central"] },
                { key: "TILABEL", label: "Quartina", alias: "Quartina", type: "text",
                  required: true, numericCombine: true,
                  voiceKeys: ["quartina", "quartine", "label", "nome", "naming", "neming", "etichetta", "numero"] },
                { key: "ARMADIO", label: "Armadio", alias: "Armadio", type: "text",
                  required: true, voiceKeys: ["armadio"] },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  required: true,
                  options: ["PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"],
                  valueMap: { "PTE Interno": "ROE PTE Interno",
                              "PTE Muro Esterno/Palifica": "ROE PTE Muro Esterno",
                              "PTE Sotterraneo": "ROE PTE Sotterraneo",
                              "PTE Colonnina": "ROE PTE Colonnina" },
                  voiceKeys: ["tipologia", "tipo", "interno", "muro esterno", "palifica", "sotterraneo", "colonnina"] },
                { key: "Posizione", label: "Ubicazione", alias: "Ubicazione", type: "picker",
                  required: true,
                  options: ["Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Muro Esterno","Palo","Pontile","Pozzetto",
                           "Seminterrato","Sottoscala"],
                  voiceKeys: ["ubicazione", "posizione", "androne", "centralino", "cortile", "divisorio",
                              "incassato", "intercapedine", "garage", "ingresso", "marciapiede",
                              "palo", "pontile", "pozzetto", "seminterrato", "sottoscala"] },
                { key: "Tipo_T", label: "Modello", alias: "Modello", type: "picker",
                  options: ["Terminale","Transito"],
                  voiceKeys: ["modello", "model", "terminale", "transito"] },
                { key: "COLON", label: "Colonnina Nuova?", alias: "Colonnina Nuova?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["colonnina nuova", "colonnina"],
                  requiredWhen: { field: "TIPOLOGIA", values: ["PTE Colonnina"] },
                  nullWhen: { field: "TIPOLOGIA", notValues: ["PTE Colonnina"] }, requireTipologia: "PTE Colonnina" },
                { key: "BASAM", label: "Basamento nuovo?", alias: "Basamento nuovo?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["basamento", "basam"],
                  requiredWhen: { field: "TIPOLOGIA", values: ["PTE Colonnina"] },
                  nullWhen: { field: "TIPOLOGIA", notValues: ["PTE Colonnina"] }, requireTipologia: "PTE Colonnina" },
                { key: "CAVO_AGG", label: "Presenza cavo spillato?", alias: "Presenza cavo spillato?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["cavo spillato", "spillato", "cavo aggiunto", "cavo agg"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Esistente","Realizzato","NON Realizzato","Progettato"],
                  required: true,
                  voiceKeys: ["stato", "esistente", "realizzato", "non realizzato", "progettato"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota", "annotazione"] },
                { key: "NOTE_ANO", label: "Note Anomalia", alias: "Note Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie", "note anomalia"] }
            ],
            presets: [
                { id: 1,  image: "images/PTE/EST_Progettato.png",       label: "Muro Est progett",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Progettato", Posizione:"Muro Esterno" } },
                { id: 2,  image: "images/PTE/EST_Realizzato.png",       label: "Muro Est realizz",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Realizzato", Posizione:"Muro Esterno" } },
                { id: 3,  image: "images/PTE/EST_Esistente.png",        label: "Muro Est esist",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Esistente",  Posizione:"Muro Esterno" } },
                { id: 4,  image: "images/PTE/EST_NON Realizzato.png",   label: "Muro Est NON real",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"NON Realizzato", Posizione:"Muro Esterno" } },
                { id: 5,  image: "images/PTE/INT_Progettato.png",       label: "Interno progett",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Progettato" } },
                { id: 6,  image: "images/PTE/INT_Realizzato.png",       label: "Interno realizz",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Realizzato" } },
                { id: 7,  image: "images/PTE/INT_Esistente.png",        label: "Interno esist",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Esistente" } },
                { id: 8,  image: "images/PTE/INT_NON Realizzato.png",   label: "Interno NON real",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"NON Realizzato" } },
                { id: 9,  image: "images/PTE/SOT_Progettato.png",       label: "Sotter progett",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Progettato", Posizione:"Pozzetto" } },
                { id: 10, image: "images/PTE/SOT_Realizzato.png",       label: "Sotter realizz",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Realizzato", Posizione:"Pozzetto" } },
                { id: 11, image: "images/PTE/SOT_Esistente.png",        label: "Sotter esist",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Esistente", Posizione:"Pozzetto" } },
                { id: 12, image: "images/PTE/SOT_NON Realizzato.png",   label: "Sotter NON real",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"NON Realizzato", Posizione:"Pozzetto" } },
                { id: 13, image: "images/PTE/COL_Progettato.png",       label: "Colonn progett",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Progettato", Posizione:"Colonnina" } },
                { id: 14, image: "images/PTE/COL_Realizzato.png",       label: "Colonn realizz",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Realizzato", Posizione:"Colonnina" } },
                { id: 15, image: "images/PTE/COL_Esistente.png",        label: "Colonn esist",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Esistente", Posizione:"Colonnina" } },
                { id: 16, image: "images/PTE/COL_NON Realizzato.png",   label: "Colonn NON real",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"NON Realizzato", Posizione:"Colonnina" } }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true, photo2Required: true,
            voiceKeywords: ["armadio", "armadi"],
            fields: [
                { key: "CENTRALE", label: "Codice Centrale", alias: "Codice Centrale", type: "text",
                  required: true, voiceKeys: ["centrale", "codice centrale", "codice", "central"] },
                { key: "ARMADIO", label: "Numero Armadio", alias: "Numero Armadio", type: "text",
                  required: true, voiceKeys: ["numero armadio", "armadio", "numero"] },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Armadio Ottico Esterno","Armadio Ottico Small"],
                  required: true, voiceKeys: ["tipologia", "tipo", "esterno", "small", "ottico"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","NON Realizzato","Esistente"],
                  required: true, voiceKeys: ["stato", "realizzato", "non realizzato", "esistente"] },
                { key: "Posizione", label: "Posizione", alias: "Posizione", type: "picker",
                  options: ["MURO ESTERNO","MURO INTERNO","INCASSATO","MARCIAPIEDE","CORTILE"],
                  voiceKeys: ["posizione", "muro esterno", "muro interno", "incassato", "marciapiede", "cortile"],
                  requiredWhen: { field: "STATO", notValues: ["NON Realizzato"] },
                  nullWhen: { field: "STATO", values: ["NON Realizzato"] } },
                { key: "N_cavi", label: "Cavi attestati (compresa primaria)", alias: "Cavi attestati (compresa primaria)", type: "text",
                  voiceKeys: ["cavi attestati", "cavi", "n cavi", "numero cavi", "attestati"],
                  requiredWhen: { field: "STATO", notValues: ["NON Realizzato"] },
                  nullWhen: { field: "STATO", values: ["NON Realizzato"] } },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalie", alias: "Anomalie", type: "text",
                  voiceKeys: ["anomalie", "anomalia"] }
            ],
            presets: [
                { id: 1, image: "images/ARMADIO/LARGE_Realizzato.png",       label: "Esterno realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Realizzato" } },
                { id: 2, image: "images/ARMADIO/LARGE_NON Realizzato.png",   label: "Esterno NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"NON Realizzato" } },
                { id: 3, image: "images/ARMADIO/LARGE_Esistente.png",        label: "Esterno esist",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Esistente" } },
                { id: 4, image: "images/ARMADIO/Small_Realizzato.png",       label: "Small realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Realizzato" } },
                { id: 5, image: "images/ARMADIO/Small_NON Realizzato.png",   label: "Small NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"NON Realizzato" } },
                { id: 6, image: "images/ARMADIO/Small_Esistente.png",        label: "Small esist",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Esistente" } }
            ]
        },
        {
            name: "POZZETTI", label: "Pozzetti", icon: "⬛",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true,
            voiceKeywords: ["pozzetto", "pozzetti", "bozzetto", "bozzetti", "pozzeto", "pozzeti", "bozzeto", "bozzeti"],
            fields: [
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["125x80","90x70","76x40","40x15","Altro"],
                  required: true, voiceKeys: ["tipologia", "tipo", "125", "90", "76", "40", "altro"] },
                { key: "STATO_1", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente","Progettato"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente", "progettato"] },
                { key: "PROPRIETA", label: "Proprietario", alias: "Proprietario", type: "picker",
                  options: ["FiberCop","TIM","Comune","Enel","Privato","Fastweb","FlashFiber","Ultranet","Infratel"],
                  required: true, voiceKeys: ["proprietario", "proprieta", "fibercop", "tim", "comune", "enel", "privato", "fastweb", "flashfiber", "ultranet", "infratel"] },
                { key: "ANELLI", label: "Presenza Anelli?", alias: "Presenza Anelli?", type: "picker", options: ["Si","No"],
                  requiredWhen: { field: "STATO_1", values: ["Realizzato"] },
                  voiceKeys: ["anelli", "presenza anelli"] },
                { key: "Num_Anelli", label: "Numero anelli", alias: "Numero anelli", type: "picker", options: ["1","2","3"],
                  requiredWhen: { field: "ANELLI", values: ["Si"] },
                  nullWhen: { field: "ANELLI", values: ["No"] },
                  voiceKeys: ["numero anelli", "num anelli"] },
                { key: "1_Anello", label: "1 Anello", alias: "1 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "ANELLI", values: ["Si"] },
                  nullWhen: { field: "ANELLI", values: ["No"] },
                  voiceKeys: ["primo anello", "uno anello", "anello 1", "anello uno"] },
                { key: "2_Anello", label: "2 Anello", alias: "2 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "Num_Anelli", values: ["2","3"] },
                  nullWhen: { field: "Num_Anelli", values: ["1"] },
                  voiceKeys: ["secondo anello", "due anello", "anello 2", "anello due"] },
                { key: "3_Anello", label: "3 Anello", alias: "3 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "Num_Anelli", values: ["3"] },
                  nullWhen: { field: "Num_Anelli", values: ["1","2"] },
                  voiceKeys: ["terzo anello", "tre anello", "anello 3", "anello tre"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Note Anomalia", alias: "Note Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1,  image: "images/POZZETTI/40x15_PROG.png",  label: "40x15 progett",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Progettato" } },
                { id: 2,  image: "images/POZZETTI/40x15_NEW.png",   label: "40x15 realizz",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 3,  image: "images/POZZETTI/40x15_ESIST.png", label: "40x15 esist",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 4,  image: "images/POZZETTI/76x4_PROG.png",   label: "76x40 progett",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Progettato" } },
                { id: 5,  image: "images/POZZETTI/76x40_NEW.png",   label: "76x40 realizz",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 6,  image: "images/POZZETTI/76x40_ESIST.png", label: "76x40 esist",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 7,  image: "images/POZZETTI/90x70_PROG.png",  label: "90x70 progett",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Progettato" } },
                { id: 8,  image: "images/POZZETTI/90x70_NEW.png",   label: "90x70 realizz",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 9,  image: "images/POZZETTI/90x70_ESIST.png", label: "90x70 esist",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 10, image: "images/POZZETTI/125x80_PROG.png", label: "125x80 progett",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Progettato" } },
                { id: 11, image: "images/POZZETTI/125x80_NEW.png",  label: "125x80 realizz",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 12, image: "images/POZZETTI/125x80_ESIST.png",label: "125x80 esist",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 13, image: "images/POZZETTI/ALTRO.png",       label: "Altro",
                  values: { TIPOLOGIA:"Altro" } }
            ]
        },
        {
            name: "GIUNTI", label: "Giunti", icon: "🔗",
            geometryType: "point", photoField: "Foto1",
            photo1Required: true,
            voiceKeywords: ["giunto", "giunti"],
            fields: [
                { key: "TILABEL", label: "Naming", alias: "Naming", type: "text",
                  required: true,
                  voiceKeys: ["naming", "neming", "nome", "label", "numero", "etichetta"],
                  numericCombine: true },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Compatta","Normale","Giunto di Linea"],
                  voiceKeys: ["tipologia", "tipo", "compatta", "normale", "linea", "giunto di linea"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente"],
                  voiceKeys: ["stato", "realizzato", "esistente"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/GIUNTI/Compatta_Realizzato.png", label: "Compatta realizz",
                  values: { TIPOLOGIA:"Compatta", STATO:"Realizzato" } },
                { id: 2, image: "images/GIUNTI/Compatta_Esistente.png",  label: "Compatta esist",
                  values: { TIPOLOGIA:"Compatta", STATO:"Esistente" } },
                { id: 3, image: "images/GIUNTI/Normale_Realizzato.png",  label: "Normale realizz",
                  values: { TIPOLOGIA:"Normale", STATO:"Realizzato" } },
                { id: 4, image: "images/GIUNTI/Normale_Esistente.png",   label: "Normale esist",
                  values: { TIPOLOGIA:"Normale", STATO:"Esistente" } },
                { id: 5, image: "images/GIUNTI/GL_Realizzato.png",       label: "Linea realizz",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Realizzato" } },
                { id: 6, image: "images/GIUNTI/GL_Esistente.png",        label: "Linea esist",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Esistente" } }
            ]
        },
        {
            name: "PALI", label: "Pali", icon: "📏",
            geometryType: "point", photoField: "Foto_1",
            photo1Required: true,
            voiceKeywords: ["palo", "pali"],
            fields: [
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker", options: ["Realizzato","Esistente"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente"] },
                { key: "MATERIALE", label: "Materiale", alias: "Materiale", type: "picker", options: ["Pino","Vtr"],
                  voiceKeys: ["materiale", "pino", "legno", "vtr"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "MODELLO", label: "Modello", alias: "Modello", type: "picker",
                  options: ["Singolo","Abbinato","Contropalo","Opposto"],
                  voiceKeys: ["modello", "singolo", "abbinato", "contropalo", "opposto"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "POSIZIONAM", label: "Posizionamento", alias: "Posizionamento", type: "picker", options: ["Base","Complessa"],
                  voiceKeys: ["posizionamento", "posizionam", "posiziona", "base", "complessa"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "Altezza", label: "Altezza?", alias: "Altezza?", type: "picker", options: ["8","9","10","11","12"],
                  voiceKeys: ["altezza"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "REGGIPALO", label: "Reggipalo?", alias: "Reggipalo?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["reggipalo", "reggi palo"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "TIRANTI_M", label: "Numero Tiranti a muro", alias: "Numero Tiranti a muro", type: "picker", options: ["0","1","2"],
                  voiceKeys: ["tiranti a muro", "tiranti muro", "tirante a muro", "tirante muro", "tiranti su muro", "tiranti a muri", "tiranti muri", "tirante a muri", "tirante muri", "a muro", "a muri", "al muro", "ai muri", "su muro"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "TIRANTI_RO", label: "Numero Tiranti a Roccia", alias: "Numero Tiranti a Roccia", type: "picker", options: ["0","1","2"],
                  voiceKeys: ["tiranti a roccia", "tiranti roccia", "tirante a roccia", "tirante roccia", "tiranti a rocce", "tiranti rocce", "tirante rocce", "tiranti su roccia"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "PALO_ROCCI", label: "Palo VTR in roccia?", alias: "Palo VTR in roccia?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["pali vtr in roccia", "pali vtr roccia", "palo vtr in roccia", "palo vtr roccia", "vtr in roccia", "vtr roccia", "palo in roccia", "palo roccia", "pali in roccia", "pali roccia", "vtr in rocce", "vtr rocce", "palo in rocce", "palo rocce", "pali btr in roccia", "pali btr roccia", "palo btr in roccia", "palo btr roccia", "btr in roccia", "btr roccia", "btr in rocce", "btr rocce", "vetro in roccia", "vetro roccia", "vetro in rocce"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "SCORTA", label: "Presenza Scorta?", alias: "Presenza Scorta?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["scorta", "presenza scorta"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalia", alias: "Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/PALI/Palo Esistente.png",     label: "Esistente",
                  values: { STATO:"Esistente" } },
                { id: 2, image: "images/PALI/Legno Singolo.png",      label: "Legno Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Singolo" } },
                { id: 3, image: "images/PALI/Legno Abbinato.png",     label: "Legno Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Abbinato" } },
                { id: 4, image: "images/PALI/Legno Contropalo.png",   label: "Legno Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Contropalo" } },
                { id: 5, image: "images/PALI/VTR Singolo.png",        label: "VTR Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Singolo" } },
                { id: 6, image: "images/PALI/VTR Abbinato.png",       label: "VTR Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Abbinato" } },
                { id: 7, image: "images/PALI/VTR Contropalo.png",     label: "VTR Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Contropalo" } }
            ]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            geometryType: "point",
            photoField: "Foto1", photoField2: "Foto2",
            photo1Required: true,
            voiceKeywords: ["extra"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Note","Colonna Montante","Foto"],
                  required: true, voiceKeys: ["tipologia", "tipo", "note", "colonna montante", "colonna", "montante", "foto"] },
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker", options: ["Nuovo","Esistente"],
                  voiceKeys: ["stato", "nuovo", "esistente"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] }
            ],
            presets: [
                { id: 1, image: "images/EXTRA/NOTE.png", label: "Note",
                  values: { Tipologia:"Note" } },
                { id: 2, image: "images/EXTRA/CM.png",   label: "Colonna Montante",
                  values: { Tipologia:"Colonna Montante" } },
                { id: 3, image: "images/EXTRA/FOTO.png", label: "Foto",
                  values: { Tipologia:"Foto" } }
            ]
        },
        {
            name: "CAVI", label: "Cavi", icon: "🪢",
            geometryType: "line", photoField: "Foto", lengthField: "Lunghezza",
            photo1Required: true,
            voiceKeywords: ["cavo", "cavi"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Fune Esistente","Nuova Fune"],
                  voiceKeys: ["tipologia", "tipo", "fune", "nuova fune", "esistente"] },
                { key: "Fibre", label: "Fibre", alias: "Fibre", type: "picker",
                  options: ["24","48","72","96","144","192"],
                  voiceKeys: ["fibre", "fibra"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  voiceKeys: ["lunghezza"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANOM", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/CAVI/FUNE_NUOVA.png", label: "Nuova Fune",
                  values: { Tipologia:"Nuova Fune" } },
                { id: 2, image: "images/CAVI/FUNE_ESIST.png", label: "Fune Esistente",
                  values: { Tipologia:"Fune Esistente" } }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰",
            geometryType: "line", photoField: "FOTO1", lengthField: "Lunghezza",
            photo1Required: true,
            voiceKeywords: ["raccordi", "raccordo"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Monofibra","Multifibra"],
                  required: true, voiceKeys: ["tipologia", "tipo", "monofibra", "multifibra"] },
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Progettato"],
                  required: true, voiceKeys: ["stato", "realizzato", "progettato"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  voiceKeys: ["lunghezza"] },
                { key: "NOTE", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalia", alias: "Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/RACCORDI/Monofibra_PROG.png",  label: "Mono progett",
                  values: { Tipologia:"Monofibra", Stato:"Progettato" } },
                { id: 2, image: "images/RACCORDI/Monofibra_REAL.png",  label: "Mono realizz",
                  values: { Tipologia:"Monofibra", Stato:"Realizzato" } },
                { id: 3, image: "images/RACCORDI/Multifibra_PROG.png", label: "Multi progett",
                  values: { Tipologia:"Multifibra", Stato:"Progettato" } },
                { id: 4, image: "images/RACCORDI/Multifibra_REAL.png", label: "Multi realizz",
                  values: { Tipologia:"Multifibra", Stato:"Realizzato" } }
            ]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte", icon: "⛏",
            geometryType: "line", photoField: "Foto1", lengthField: "Lunghezza",
            photo1Required: true,
            voiceKeywords: ["tratta", "tratte", "tratte interrate", "interrate"],
            fields: [
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente","Progetto"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente", "progetto", "progettato"] },
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Canalizzazione","Trincea","Trincea Sterrato","Trincea Pregiato",
                           "Minitrincea","Microtrincea","No-Dig"],
                  required: true, voiceKeys: ["tipologia", "tipo", "canalizzazione", "trincea", "sterrato", "pregiato", "minitrincea", "microtrincea", "no dig", "no-dig", "nodig"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  // v37.1.53: in modalita' puntatore, se Stato e' Realizzato o Esistente la lunghezza e' obbligatoria (la misura l'operatore)
                  requiredWhen: { allOf: [ { pointerMode: true }, { field: "Stato", values: ["Realizzato","Esistente"] } ] },
                  voiceKeys: ["lunghezza"] },
                // ── v37.1.8: TUBIERA (sostituisce "tubiera_co") ──────────
                // Campi del gruppo "Tubiera" come da schema QGIS.
                // Regole/condizioni (copia ultima tubazione, value list,
                // checkbox) sono definite nel progetto QGIS: il plugin scrive
                // i valori grezzi e il form nativo di QField applica default
                // ed eventuali vincoli al salvataggio.
                // "Ultima Tubazione": sola lettura, valore calcolato da QGIS.
                { key: "Ultima_Tub", label: "Ultima Tubazione", alias: "Ultima Tubazione", type: "text",
                  readOnly: true },
                // "Copia Ultima Tubazione Inserita": checkbox 0/1.
                // A voce basta dire l'alias (es. "copia ultima tubazione") per
                // attivarla (=Si); dire "no" la disattiva.
                { key: "Copia_Ulti", label: "Copia Ultima Tubazione Inserita", alias: "Copia Ultima Tubazione Inserita",
                  type: "picker", widget: "checkbox", options: ["Si","No"], valueMap: { "Si": 1, "No": 0 },
                  offValue: "No", impliedValue: "Si",
                  voiceKeys: ["copia ultima tubazione", "copia ultima", "copia tubazione",
                              "copia precedente", "stessa tubazione", "stessa tubiera",
                              "come la precedente", "come prima", "copia"] },
                { key: "Tipo_Min1", label: "Tipologia Minitubi", alias: "Tipologia Minitubi", type: "picker",
                  options: ["12","14"],
                  voiceKeys: ["tipologia minitubi", "tipo minitubi", "tipologia mini tubi",
                              "tipo mini tubi", "tipologia minitubo", "minitubi tipologia"] },
                { key: "Num_Min1", label: "Q.ta Minitubi Totale", alias: "Q.ta Minitubi Totale", type: "text",
                  // v37.1.44: obbligatorio se Tipo_Min1 e' 12 o 14
                  requiredWhen: { field: "Tipo_Min1", values: ["12","14"] },
                  voiceKeys: ["quantità minitubi totale", "quantita minitubi totale",
                              "quantità minitubi", "quantita minitubi", "numero minitubi",
                              "quantità mini tubi", "quantita mini tubi", "minitubi quantità",
                              "minitubi totale", "minitubi totali"] },
                { key: "Q.ta_Min_N", label: "Q.ta Minitubi Nuovi", alias: "Q.ta Minitubi Nuovi", type: "text",
                  // obbligatorio (non nullo) solo se Tipo_Min1 e' 12 o 14; altrimenti puo' essere nullo
                  requiredWhen: { allOf: [
                      { field: "Tipo_Min1", values: ["12","14"] }
                  ] },
                  // v37.1.44: se Stato=Realizzato -> uguale a Num_Min1 (che si valorizza prima)
                  autoFill: { fromField: "Num_Min1", when: { field: "Stato", values: ["Realizzato"] } },
                  voiceKeys: ["quantità minitubi nuovi", "quantita minitubi nuovi",
                              "minitubi nuovi", "mini tubi nuovi", "quantità mini tubi nuovi",
                              "numero minitubi nuovi", "minitubi nuovo"] },
                { key: "Tipo_Tub1", label: "Tipologia Tubo", alias: "Tipologia Tubo", type: "picker",
                  options: ["40","50","63","80","100","110","125","160"],
                  voiceKeys: ["tipologia tubo", "tipo tubo", "tipologia del tubo",
                              "diametro tubo", "diametro del tubo"] },
                { key: "Num_Tubo1", label: "Quantità Tubi", alias: "Quantità Tubi", type: "text",
                  // v37.1.44: obbligatorio se Tipo_Tub1 e' valorizzato
                  requiredWhen: { field: "Tipo_Tub1", notEmpty: true },
                  voiceKeys: ["quantità tubi", "quantita tubi", "quanti tubi",
                              "quantità tubo", "quantita tubo", "numero tubo"] },
                { key: "Occ_Tub1", label: "Numero Tubi Occupati", alias: "Numero Tubi Occupati", type: "text",
                  voiceKeys: ["numero tubi occupati", "tubi occupati", "occupati", "tubi occupate", "occupate"] },
                { key: "TIP_RIP", label: "Tipologia Ripristino", alias: "Tipologia Ripristino", type: "picker",
                  options: ["Bitume","Asfalto Colato","Cemento","Mattonelle cemento","Cubetti","Basoli","Ghiaia","No"],
                  // v37.1.22: obbligatorio se Stato=Realizzato AND Tipologia != No-Dig
                  requiredWhen: { allOf: [
                      { field: "Stato",     values:    ["Realizzato"] },
                      { field: "Tipologia", notValues: ["No-Dig"] }
                  ] },
                  voiceKeys: ["tipologia di ripristino", "tipologia del ripristino", "tipologia ripristino", "tipo ripristino", "tipo di ripristino", "tip ripristino", "tip rip", "bitume", "asfalto", "cemento", "mattonelle", "cubetti", "basoli", "ghiaia"] },
                { key: "LARGH_RIP", label: "Larghezza Ripristino", alias: "Larghezza Ripristino", type: "text",
                  metricUnits: true,
                  // v37.1.22: obbligatoria se TIP_RIP e' valorizzata e != "No"
                  requiredWhen: { allOf: [
                      { field: "TIP_RIP", notEmpty: true },
                      { field: "TIP_RIP", notValues: ["No"] }
                  ] },
                  // se TIP_RIP e' vuota o "No", LARGH_RIP deve essere vuota
                  nullWhen: { field: "TIP_RIP", values: ["", "No"] },
                  voiceKeys: ["larghezza ripristino", "largh ripristino", "largh rip", "larghezza e ripristino", "larghezza", "largezza", "larga", "ripristino largh", "ripristino largo"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1,  image: "images/TRATTE INTERRATE/ESISTENTE.png",       label: "Esistente",
                  values: { Stato:"Esistente" } },
                { id: 2,  image: "images/TRATTE INTERRATE/Trincea_P.png",       label: "Trincea progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea" } },
                { id: 3,  image: "images/TRATTE INTERRATE/Trincea_R.png",       label: "Trincea realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea" } },
                { id: 4,  image: "images/TRATTE INTERRATE/Sterrato_P.png",      label: "Sterrato progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea Sterrato" } },
                { id: 5,  image: "images/TRATTE INTERRATE/Sterrato_R.png",      label: "Sterrato realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea Sterrato" } },
                { id: 6,  image: "images/TRATTE INTERRATE/Minitrincea_P.png",   label: "Minitr progett",
                  values: { Stato:"Progetto", Tipologia:"Minitrincea" } },
                { id: 7,  image: "images/TRATTE INTERRATE/Minitrincea_R.png",   label: "Minitr realizz",
                  values: { Stato:"Realizzato", Tipologia:"Minitrincea" } },
                { id: 8,  image: "images/TRATTE INTERRATE/Microtrincea_P.png",  label: "Microtr progett",
                  values: { Stato:"Progetto", Tipologia:"Microtrincea" } },
                { id: 9,  image: "images/TRATTE INTERRATE/Microtrincea_R.png",  label: "Microtr realizz",
                  values: { Stato:"Realizzato", Tipologia:"Microtrincea" } },
                { id: 10, image: "images/TRATTE INTERRATE/No Dig_P.png",        label: "No-Dig progett",
                  values: { Stato:"Progetto", Tipologia:"No-Dig" } },
                { id: 11, image: "images/TRATTE INTERRATE/No Dig_R.png",        label: "No-Dig realizz",
                  values: { Stato:"Realizzato", Tipologia:"No-Dig" } }
            ]
        }
    ]



    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []

    // ── SEGNALAZIONE EVENTI VIA CREATEDIR ───────────────────────
    // QField QML espone solo createDir e renameFile per la scrittura.
    // renameFile distrugge la sorgente, quindi non e' praticabile per
    // eventi ripetuti. Usiamo createDir: per ogni evento creiamo una
    // sottocartella timestampata dentro una cartella-evento. MacroDroid
    // configura il trigger "Folder Modified" su ciascuna cartella-evento.
    property string signalsRoot: "/storage/emulated/0/Download/pte_signals"
    property bool signalsRootReady: false

    // Elenco eventi noti - per pre-creare le cartelle padre
    property var knownEvents: [
        "voice_input_ready", "layer_picker_ready", "form_ready",
        "radial_ready",                                            // v37.1.26
        "vertex_choice_ready", "line_first_vertex", "foto_scatta",
        "auto_shutter", "auto_confirm", "photo_done", "all_closed",
        "snap_popup_ready"
    ]

    function ensureSignalsRoot() {
        if (plugin.signalsRootReady) return
        try {
            platformUtilities.createDir("/storage/emulated/0/Download", "pte_signals")
            // Pre-crea le cartelle per ogni evento noto
            for (var i = 0; i < plugin.knownEvents.length; i++) {
                platformUtilities.createDir(plugin.signalsRoot, plugin.knownEvents[i])
            }
            plugin.signalsRootReady = true
        } catch(e) {
            // silent
        }
    }

    // v37.0.23: persistenza posizione finestre
    property bool winPosLoaded: false
    property var winPosCache: ({})

    // v37.1.9: ultima tubazione inserita dal plugin (per anteprima "Ultima Tubazione").
    // Persistita nel progetto cosi sopravvive alla chiusura dell'app.
    property string lastTubazione: ""
    // v37.1.11: valori grezzi dell'ultima tubazione, per la copia lato-plugin
    // (Tipo_Tub1, Num_Tubo1, Tipo_Min1, Num_Min1, Occ_Tub1).
    property var lastTubValues: ({})

    function loadLastTub() {
        try {
            var v = qgisProject.customProperty("vocalGps_lastTub")
            if (v !== undefined && v !== null) return "" + v
        } catch(e) {}
        return ""
    }

    // v37.1.11: carica i valori grezzi dell'ultima tubazione (JSON)
    function loadLastTubValues() {
        try {
            var v = qgisProject.customProperty("vocalGps_lastTubVals")
            if (v !== undefined && v !== null && ("" + v) !== "")
                return JSON.parse("" + v)
        } catch(e) {}
        return {}
    }

    function saveLastTub(txt) {
        plugin.lastTubazione = txt
        try { qgisProject.setCustomProperty("vocalGps_lastTub", txt) } catch(e) {}
    }

    // v37.1.11: memorizza i valori grezzi dei campi tubo per la copia lato-plugin
    function saveLastTubValues(d) {
        var keys = ["Tipo_Tub1", "Num_Tubo1", "Tipo_Min1", "Num_Min1", "Q.ta_Min_N", "Occ_Tub1"]
        var v = {}
        for (var i = 0; i < keys.length; i++) {
            var val = d[keys[i]]
            v[keys[i]] = (val === undefined || val === null) ? "" : ("" + val)
        }
        plugin.lastTubValues = v
        try { qgisProject.setCustomProperty("vocalGps_lastTubVals", JSON.stringify(v)) } catch(e) {}
    }

    // Formatta "Tipo_Tub1/Num_Tubo1-Tipo_Min1/Num_Min1" (es. "50/1-12/5").
    // Prima i tubi (se popolati), poi i minitubi. Quantita mancante -> 1.
    function formatTubazione(d) {
        function nz(x, def) {
            return (x === undefined || x === null || ("" + x) === "") ? def : ("" + x)
        }
        var parts = []
        var tt = d["Tipo_Tub1"]
        if (tt !== undefined && tt !== null && ("" + tt) !== "")
            parts.push(("" + tt) + "/" + nz(d["Num_Tubo1"], "1"))
        var tm = d["Tipo_Min1"]
        if (tm !== undefined && tm !== null && ("" + tm) !== "")
            parts.push(("" + tm) + "/" + nz(d["Num_Min1"], "1"))
        return parts.join("-")
    }

    // v37.1.9: popola l'anteprima "Ultima Tubazione" col valore dell'ultima
    // tubazione inserita (memorizzata al salvataggio). Agisce solo se il layer
    // corrente ha effettivamente il campo Ultima_Tub (TRATTE INTERRATE).
    function ensureUltimaTub() {
        var hasField = false
        for (var i = 0; i < plugin.currentFields.length; i++)
            if (plugin.currentFields[i].key === "Ultima_Tub") { hasField = true; break }
        if (!hasField) return
        var txt = plugin.lastTubazione
        if (txt === "" ) txt = loadLastTub()
        var d = JSON.parse(JSON.stringify(plugin.parsedData))
        d["Ultima_Tub"] = txt
        plugin.parsedData = d
        fieldsModel.refresh()
    }

    // v37.1.11: copia lato-plugin. Quando "Copia Ultima Tubazione" e' spuntata,
    // riempie Tipo_Tub1/Num_Tubo1/Tipo_Min1/Num_Min1/Occ_Tub1 con i valori
    // dell'ultima tubazione inserita. Indipendente dalla regola QGIS.
    // v37.1.13: ricostruisce i valori grezzi dalla stringa "63/1-12/5".
    // I tipi 12/14 sono minitubi, gli altri sono tubi.
    function parseTubazione(txt) {
        var out = {}
        if (!txt || ("" + txt) === "") return out
        var parts = ("" + txt).split("-")
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].trim()
            if (p === "") continue
            var s = p.indexOf("/")
            var tipo = (s >= 0) ? p.substring(0, s).trim() : p
            var num  = (s >= 0) ? p.substring(s + 1).trim() : ""
            if (tipo === "") continue
            if (tipo === "12" || tipo === "14") {
                out["Tipo_Min1"] = tipo
                if (num !== "") out["Num_Min1"] = num
            } else {
                out["Tipo_Tub1"] = tipo
                if (num !== "") out["Num_Tubo1"] = num
            }
        }
        return out
    }

    // v37.1.20: coda toast per evitare sovrascrittura quando partono in rapida sequenza
    property var toastQueue: []
    Timer {
        id: toastTimer
        interval: 1300; repeat: false
        onTriggered: {
            if (plugin.toastQueue.length === 0) return
            var msg = plugin.toastQueue.shift()
            try { mainWindow.displayToast(msg) } catch(e) {}
            if (plugin.toastQueue.length > 0) toastTimer.start()
        }
    }
    function notify(msg) {
        plugin.toastQueue.push("" + msg)
        if (!toastTimer.running) {
            // primo toast immediato
            var m = plugin.toastQueue.shift()
            try { mainWindow.displayToast(m) } catch(e) {}
            if (plugin.toastQueue.length > 0) toastTimer.start()
        }
    }

    // v37.1.21: esegue il toggle+copia FUORI dal delegate, cosi refresh()
    // non aborta lo script (il delegate corrente verrebbe distrutto).
    Timer {
        id: copiaTimer
        interval: 0; repeat: false
        onTriggered: {
            var dcc = JSON.parse(JSON.stringify(plugin.parsedData))
            dcc["Copia_Ulti"] = "Si"
            plugin.parsedData = dcc
            var ncc = 0
            for (var kcc in dcc) if (dcc[kcc] !== "") ncc++
            plugin.okCount = ncc
            fieldsModel.refresh()
            applyCopiaTubazione()
        }
    }

    function applyCopiaTubazione() {
        try {
            var vals = plugin.lastTubValues
            if (!vals || Object.keys(vals).length === 0) vals = loadLastTubValues()
            var hasRaw = vals && (vals["Tipo_Tub1"] || vals["Tipo_Min1"])
            if (!hasRaw) {
                var txt = (plugin.lastTubazione !== "") ? plugin.lastTubazione : loadLastTub()
                if (!txt || txt === "") txt = plugin.parsedData["Ultima_Tub"] || ""
                vals = parseTubazione(txt)
            }
            if (!vals || (!vals["Tipo_Tub1"] && !vals["Tipo_Min1"])) {
                notify("⚠ Nessuna tubazione precedente da copiare")
                return false
            }
            var keys = ["Tipo_Tub1", "Num_Tubo1", "Tipo_Min1", "Num_Min1", "Q.ta_Min_N", "Occ_Tub1"]
            var d = JSON.parse(JSON.stringify(plugin.parsedData))
            for (var i = 0; i < keys.length; i++) {
                var k = keys[i]
                if (vals[k] !== undefined && vals[k] !== null && ("" + vals[k]) !== "")
                    d[k] = "" + vals[k]
            }
            plugin.parsedData = d
            var n = 0
            for (var kk in d) if (d[kk] !== "") n++
            plugin.okCount = n
            fieldsModel.refresh()
            notify("✅ Tubazione copiata: " + formatTubazione(d))
            return true
        } catch(e) {
            return false
        }
    }

    // v37.1.11: svuota i campi tubo quando la checkbox viene tolta.
    function clearCopiaTubazione() {
        var keys = ["Tipo_Tub1", "Num_Tubo1", "Tipo_Min1", "Num_Min1", "Q.ta_Min_N", "Occ_Tub1"]
        var d = JSON.parse(JSON.stringify(plugin.parsedData))
        for (var i = 0; i < keys.length; i++) d[keys[i]] = ""
        plugin.parsedData = d
        var n = 0
        for (var kk in d) if (d[kk] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
        notify("↩ Tubazione tolta (campi tubo svuotati)")
    }

    function saveWinPos(winId, x, y) {
        plugin.winPosCache[winId] = { x: x, y: y }
        try {
            qgisProject.setCustomProperty("vocalGps_win_" + winId + "_x", x)
            qgisProject.setCustomProperty("vocalGps_win_" + winId + "_y", y)
        } catch(e) {}
    }

    function loadWinPos(winId, defX, defY) {
        if (plugin.winPosCache[winId]) return plugin.winPosCache[winId]
        try {
            var x = qgisProject.customProperty("vocalGps_win_" + winId + "_x")
            var y = qgisProject.customProperty("vocalGps_win_" + winId + "_y")
            if (x !== undefined && x !== null && y !== undefined && y !== null) {
                var pos = { x: parseInt(x), y: parseInt(y) }
                plugin.winPosCache[winId] = pos
                return pos
            }
        } catch(e) {}
        return { x: defX, y: defY }
    }

    Component {
        id: dragHandleComp
        Rectangle {
            id: dh
            property string winId: ""
            property var target: null
            width: parent ? parent.width : 0
            height: 28
            color: "#dbe2ed"
            radius: 4
            Text {
                anchors.centerIn: parent
                text: "⋮⋮  trascina  ⋮⋮"
                color: "#5a6378"; font.pixelSize: 11; font.bold: true
            }
            MouseArea {
                anchors.fill: parent
                drag.target: dh.target
                drag.axis: Drag.XAndYAxis
                drag.minimumX: 0
                drag.minimumY: 0
                drag.maximumX: dh.target && dh.target.parent ? dh.target.parent.width - dh.target.width : 9999
                drag.maximumY: dh.target && dh.target.parent ? dh.target.parent.height - dh.target.height : 9999
                onReleased: {
                    if (dh.target && dh.winId !== "") {
                        plugin.saveWinPos(dh.winId, dh.target.x, dh.target.y)
                    }
                }
            }
        }
    }

    // v37.0.27: ordina preset per stato (Realizzato, Esistente, Progettato, Non Realizzato)
    // poi per tipologia in ordine di prima apparizione
    function getSortedPresets(presets) {
        if (!presets || presets.length === 0) return []
        var statoOrder = {
            "realizzato": 0, "esistente": 1, "progettato": 2, "progetto": 2,
            "non realizzato": 3, "nonrealizzato": 3, "non realizz": 3, "": 4
        }
        var tipoOrder = {}
        var nextIdx = 0
        for (var i = 0; i < presets.length; i++) {
            var v = presets[i].values || {}
            var t = v.TIPOLOGIA || v.MATERIALE || v.Tipologia || v.MODELLO || v.Tipo_T || ""
            if (tipoOrder[t] === undefined) tipoOrder[t] = nextIdx++
        }
        function statoP(p) {
            var v2 = p.values || {}
            var s = ("" + (v2.STATO_1 || v2.STATO || v2.Stato || "")).toLowerCase().trim()
            return statoOrder[s] !== undefined ? statoOrder[s] : 5
        }
        function tipoP(p) {
            var v3 = p.values || {}
            var t2 = v3.TIPOLOGIA || v3.MATERIALE || v3.Tipologia || v3.MODELLO || v3.Tipo_T || ""
            return tipoOrder[t2] !== undefined ? tipoOrder[t2] : 99
        }
        var sorted = presets.slice()
        sorted.sort(function(a, b) {
            var sa = statoP(a), sb = statoP(b)
            if (sa !== sb) return sa - sb
            return tipoP(a) - tipoP(b)
        })
        return sorted
    }

    function broadcastEvent(eventName) {
        try {
            ensureSignalsRoot()
            var evDir = plugin.signalsRoot + "/" + eventName.toLowerCase()
            // v37.1.26: una sola creazione di sottocartella, pulita.
            // (Rimossa la cascata "_latest_" introdotta in v37.1.25 che
            // sporcava le cartelle e non serviva piu' con una macro per evento.)
            var subName = "t" + Date.now()
            platformUtilities.createDir(evDir, subName)
        } catch(e) {
            // silent
        }
    }

    // ── DIAGNOSTICO FILE WRITE ──────────────────────────────────
    // Prova vari metodi e accumula i risultati in diagLog, mostrato
    // in una dialog persistente cosi' i risultati sono leggibili con calma.
    property string diagLog: ""

    function diagAdd(line) {
        plugin.diagLog += line + "\n"
    }

    function probeMethods(objName, obj, methods) {
        diagAdd(objName + ":")
        if (!obj) { diagAdd("  (oggetto non esiste)"); return }
        for (var i = 0; i < methods.length; i++) {
            var m = methods[i]
            var t = "?"
            try { t = typeof obj[m] } catch(e) { t = "EXC:" + e }
            diagAdd("  " + m + " : " + t)
        }
    }

    function runFileDiagnostic() {
        plugin.diagLog = ""
        ensureSignalsRoot()

        diagAdd("=== TEST CREATEDIR APPROACH ===")
        diagAdd("Crea sottocartelle dentro /Download/pte_signals/<evento>/")
        diagAdd("")
        try {
            var testEvent = plugin.signalsRoot + "/auto_shutter"
            var subName = "diag_t" + Date.now()
            var ok = platformUtilities.createDir(testEvent, subName)
            diagAdd("createDir(\"" + testEvent + "\", \"" + subName + "\")")
            diagAdd("  -> " + ok)
            diagAdd("  esiste: " + FileUtils.fileExists(testEvent + "/" + subName))
        } catch(e) {
            diagAdd("EXC: " + e)
        }
        diagAdd("")
        diagAdd("=== PROBE METODI QFIELD ===")
        diagAdd("")

        // Probe FileUtils
        var fuObj = (typeof FileUtils !== "undefined") ? FileUtils : null
        probeMethods("FileUtils", fuObj, [
            "copyFile","copy","copyTo","clone",
            "moveFile","move","rename","renameFile",
            "deleteFile","remove","removeFile","unlink",
            "fileExists","exists","isFile","isDir",
            "writeFile","write","writeText","createFile","touch",
            "copyDir","deleteDir","makeDir","mkdir",
            "fileSuffix","fileName","absolutePath","addUniqueSuffix"
        ])
        diagAdd("")

        // Probe platformUtilities
        var puObj = (typeof platformUtilities !== "undefined") ? platformUtilities : null
        probeMethods("platformUtilities", puObj, [
            "copyFile","copy","copyTo",
            "moveFile","move","renameFile",
            "deleteFile","remove",
            "createDir","makeDir","mkdir",
            "createSymbolicLink","symlink","link",
            "openFile","openLink","openUrl",
            "writeFile","write","createFile","touch",
            "vibrate","getCameraPictureFilePath"
        ])
        diagAdd("")

        // Probe iface se ha sotto-oggetti utili
        var ifaceObj = (typeof iface !== "undefined") ? iface : null
        probeMethods("iface", ifaceObj, [
            "platformUtilities","fileUtils","writeFile",
            "mainWindow","findItemByObjectName","addItemToPluginsToolbar"
        ])
        diagAdd("")

        // Probe globals
        diagAdd("Globals:")
        try { diagAdd("  Qt.fileExists?: " + typeof Qt.fileExists) } catch(e) {}
        try { diagAdd("  qgisProject: " + typeof qgisProject) } catch(e) {}
        try { diagAdd("  qgisProject.homePath: " + qgisProject.homePath) } catch(e) {}
        diagAdd("")

        // Test pratico: createSymbolicLink (se esiste)
        diagAdd("=== TEST createSymbolicLink ===")
        var seedPath = "(non usato in v23)"
        var destPath = plugin.signalsDir + "/_diag_test.signal"
        diagAdd("SEED: " + seedPath)
        diagAdd("DEST: " + destPath)

        if (puObj && typeof puObj.createSymbolicLink === "function") {
            try {
                var ok = puObj.createSymbolicLink(seedPath, destPath)
                diagAdd("createSymbolicLink -> " + ok)
            } catch(e) {
                diagAdd("createSymbolicLink EXC: " + e)
            }
            try {
                diagAdd("file esiste dopo: " + FileUtils.fileExists(destPath))
            } catch(e) {}
        } else {
            diagAdd("createSymbolicLink NON disponibile")
        }
        diagAdd("")

        // Test pratico: scrittura in qgisProject.homePath (cartella sicuramente scrivibile)
        diagAdd("=== TEST homePath copy ===")
        try {
            var home = qgisProject.homePath
            diagAdd("homePath: " + home)
            var homeDest = home + "/_diag_in_project.signal"
            diagAdd("dest in project: " + homeDest)
            if (puObj && typeof puObj.renameFile === "function") {
                // First, prova a creare un seed temporaneo in homePath via openFile?
                // Saltiamo, useremo renameFile dopo un copy se possibile
            }
            diagAdd("(test homePath skipped — serve un metodo copy/write per riempirlo)")
        } catch(e) {
            diagAdd("homePath test EXC: " + e)
        }

        diagAdd("")
        diagAdd("=== FINE ===")
        diagAdd("Manda screenshot di questa schermata.")
        diagDialog.visible = true
    }

    // Evento "ombrello": emesso ogni volta che un input vocale e' pronto.
    // Configura UNA macro MacroDroid su pte.plugin.VOICE_INPUT_READY
    // che attivi il microfono della tastiera — copre tutti gli stati
    // (picker layer, form punto, modale vertice, form fine-tratta, ritorno dopo foto).
    function emitVoiceReady() {
        broadcastEvent("VOICE_INPUT_READY")
    }

    // v37.1.22: debounce reattivo. Il polling guarda velocemente (100ms),
    // ma processVoice parte solo quando il testo e' STABILE da 150ms.
    // Questo elimina il ritardo dopo la fine del dettato senza chiamare
    // il parser su testi parziali in corso di dettatura.
    property string lastSeenText: ""
    property double lastSeenAt: 0
    Timer {
        id: pollTimer
        interval: 100; repeat: true; running: overlay.visible
        onTriggered: {
            var t = inputArea.text
            if (t === plugin.lastParsedText) return
            if (t.length <= 2) return
            if (t !== plugin.lastSeenText) {
                // testo cambiato: aggiorna timestamp e attendi stabilita'
                plugin.lastSeenText = t
                plugin.lastSeenAt = Date.now()
                return
            }
            // testo invariato: se stabile da almeno 150ms, processa
            if (Date.now() - plugin.lastSeenAt >= 150) {
                plugin.lastParsedText = t
                processVoice(t)
            }
        }
    }

    // Polling per layer picker
    Timer {
        id: layerVoicePollTimer
        interval: 400; repeat: true; running: layerPicker.visible
        onTriggered: {
            if (layerVoiceInput.text !== plugin.lastLayerVoiceText
                    && layerVoiceInput.text.length > 1) {
                plugin.lastLayerVoiceText = layerVoiceInput.text
                tryMatchLayerVoice(layerVoiceInput.text)
            }
        }
    }

    // Polling per vertex choice
    Timer {
        id: vertexVoicePollTimer
        interval: 400; repeat: true; running: vertexChoice.visible
        onTriggered: {
            if (vertexVoiceInput.text !== plugin.lastVertexVoiceText
                    && vertexVoiceInput.text.length > 1) {
                plugin.lastVertexVoiceText = vertexVoiceInput.text
                processVertexVoice(vertexVoiceInput.text)
            }
        }
    }

    // Polling per radial menu
    Timer {
        id: radialVoicePollTimer
        interval: 400; repeat: true; running: radialMenu.visible
        onTriggered: {
            if (radialVoiceInput.text !== plugin.lastRadialVoiceText
                    && radialVoiceInput.text.length > 0) {
                plugin.lastRadialVoiceText = radialVoiceInput.text
                processRadialVoice(radialVoiceInput.text)
            }
        }
    }

    Component.onCompleted: {
        plugin.loadGpsThreshold()
        plugin.loadGpsDrift()
        plugin.loadPositionMode()
        plugin.loadOrCreateDeviceId()
        plugin.loadStoredLicense()
        plugin.lastTubazione = plugin.loadLastTub()
        plugin.lastTubValues = plugin.loadLastTubValues()
        plugin.licenseChecked = true
        iface.addItemToPluginsToolbar(micBtn)
        iface.addItemToPluginsToolbar(toolBtn)
        layerPicker.parent     = mainWindow.contentItem
        overlay.parent         = mainWindow.contentItem
        picker.parent          = mainWindow.contentItem
        freeTextEditor.parent  = mainWindow.contentItem
        vertexChoice.parent    = mainWindow.contentItem
        radialMenu.parent      = mainWindow.contentItem
        diagDialog.parent      = mainWindow.contentItem
        snapPopup.parent       = mainWindow.contentItem
        pinPopup.parent        = mainWindow.contentItem
        revalidatePopup.parent = mainWindow.contentItem
        gpsWaitModal.parent    = mainWindow.contentItem
        gpsWarnPopup.parent    = mainWindow.contentItem
        nativeBlockedPopup.parent = mainWindow.contentItem
        settingsPanel.parent   = mainWindow.contentItem
        dbgBar.parent          = mainWindow.contentItem
        pointerCrosshair.parent = mainWindow.contentItem              // v37.1.48
        pointerCrosshair.anchors.centerIn = mainWindow.contentItem
        // v37.1.50: riferimento al drawer nativo per l'inibizione
        try { plugin.nativeDrawer = iface.findItemByObjectName("overlayFeatureFormDrawer") } catch(eD) {}
        try { plugin.nativeFeatureListForm = iface.findItemByObjectName("featureListForm") } catch(eF) {}
        // v37.1.117 (Step 3c): forza subito lo stato "matita spenta" su tutti i layer
        // all'avvio - onNativeInhibitedChanged non scatta da solo per il valore
        // iniziale (true) della property, va applicato esplicitamente una volta qui.
        plugin.applyNativeLayerEditState(false)
        // v37.1.114 (Step 3): primo controllo sblocco nativo all'avvio (resta bloccato
        // finche' non arriva una risposta positiva dal foglio). Da qui in poi il polling
        // e' preso in carico da nativeCheckTimer (ogni 30 minuti).
        plugin.checkNativeUnlock()
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible || picker.visible || freeTextEditor.visible || vertexChoice.visible
                || radialMenu.visible || snapPopup.visible || settingsPanel.visible
                || pinPopup.visible) {
            return
        }
        // v37.1.69: un NUOVO inserimento non e' mai una modifica -> azzera lo stato modifica
        plugin.editMode = false
        plugin.editCand = null
        plugin.editFid = null
        plugin.editPendingDeleteFid = null
        plugin.editPendingDeleteLayer = null
        // v37.0.32: verifica licenza
        if (!isLicensed()) {
            showLicenseScreen()
            return
        }
        // v37.0.40: revalidazione giornaliera con popup interattivo
        if (needsRevalidation()) {
            revalidatePopup.visible = true
            return
        }
        if (layerPicker.visible) {
            closeAll(); return
        }

        capturePendingPosition()

        // v37.1.45: GPS sopra soglia -> BLOCCA SEMPRE (punti E vertici tratta),
        // subito al momento del +, prima di entrare/proseguire nella tratta.
        if (isGpsBlocked()) {
            showGpsBlocked()
            return
        }

        // v37.0.41: pre-wake MacroDroid PRIMA di aprire la UI.
        // MacroDroid inizia subito a cercare il mic; quando la tastiera apparira'
        // 300-500ms dopo, il click sara' istantaneo (~300ms di guadagno tipico).
        emitVoiceReady()


        if (plugin.lineMode) {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido")
                return
            }
            vertexCountText.text = "Vertici raccolti: " + plugin.lineVertices.length +
                                   " + 1 in attesa"
            plugin.lastVertexVoiceText = ""
            vertexVoiceInput.text = ""
            // v37.0.41: signal PRIMA di visible per dare head start a MacroDroid
            broadcastEvent("VERTEX_CHOICE_READY")
            emitVoiceReady()
            vertexChoice.visible = true
            vertexFocusTimer.start()
        } else {
            updateGPS()
            plugin.lastLayerVoiceText = ""
            layerVoiceInput.text = ""
            // v37.0.41: signal PRIMA di visible
            broadcastEvent("LAYER_PICKER_READY")
            emitVoiceReady()
            layerPicker.visible = true
            layerFocusTimer.start()
        }
    }

    // v37.1.0: campionamento posizione asincrono con mediana, stop anticipato
    // e guardia movimento. capturePendingPosition() resta l'entry point dei punti.
    Timer {
        id: gpsSampleTimer
        interval: 200; repeat: true; running: false   // 5 Hz
        onTriggered: {
            if (!plugin.gpsSampleActive) { stop(); return }
            gpsCollectOnce()
            if (!plugin.gpsSampleActive) return   // finalizzato dalla deriva
            var elapsed = Date.now() - plugin.gpsSampleStartMs
            if (elapsed >= plugin.gpsSampleMaxMs) finalizeGpsSampling()
        }
    }

    function readAccuracyM(info) {
        // v37.1.36: se info non fornito, leggi al volo dalla sorgente
        if (!info) {
            try { info = positionSource.positionInformation } catch(eN) {}
        }
        if (info) {
            // QField espone hacc (con haccValid): e' la via principale
            try {
                if (info.haccValid === undefined || info.haccValid === true) {
                    var h = info.hacc
                    if (typeof h === "number" && h > 0 && h < 10000) return h
                }
            } catch(eh) {}
            var cands = ["hacc","horizontalAccuracy","accuracy","hAccuracy",
                         "horizontalAccuracyMeters","hAcc","horizontal_accuracy"]
            for (var i = 0; i < cands.length; i++) {
                try { var v = info[cands[i]]
                    if (typeof v === "number" && v > 0 && v < 10000) return v } catch(e) {}
            }
        }
        try { var v2 = positionSource.projectedHorizontalAccuracy
            if (typeof v2 === "number" && v2 > 0 && v2 < 10000) return v2 } catch(e2) {}
        try { var v3 = positionSource.horizontalAccuracy
            if (typeof v3 === "number" && v3 > 0 && v3 < 10000) return v3 } catch(e3) {}
        return -1
    }

    function gpsMedian(arr) {
        if (arr.length === 0) return NaN
        var a = arr.slice().sort(function(p,q){ return p - q })
        var m = Math.floor(a.length / 2)
        return (a.length % 2) ? a[m] : (a[m-1] + a[m]) / 2
    }

    function gpsCollectOnce() {
        if (!positionSource || !positionSource.active) return
        var info = positionSource.positionInformation
        if (!info.latitudeValid || !info.longitudeValid) return
        var pos = positionSource.projectedPosition
        var acc = readAccuracyM(info)
        var thrM = plugin.gpsAccuracyThresholdCm / 100.0
        // scarta campioni oltre soglia (solo se l'accuratezza e' nota)
        if (acc >= 0 && acc > thrM) return

        plugin.gpsSamples.push({ x: pos.x, y: pos.y, acc: acc })
        var n = plugin.gpsSamples.length

        // primo campione -> riempi subito i pending (provvisori)
        if (n === 1) {
            plugin.pendingX = pos.x
            plugin.pendingY = pos.y
            plugin.pendingAccuracyM = acc
            plugin.pendingValid = true
        }

        // v37.1.38: baseline = mediana dei primi 3 campioni (centro del gruppo "fermo")
        if (n === 3) {
            var bxs = [], bys = []
            for (var i = 0; i < 3; i++) { bxs.push(plugin.gpsSamples[i].x); bys.push(plugin.gpsSamples[i].y) }
            plugin.gpsBaseline = { x: gpsMedian(bxs), y: gpsMedian(bys) }
            plugin.gpsDriftCount = 0
        }

        // v37.1.38: rileva DERIVA reale (movimento), non rumore GPS.
        // Il rumore oscilla attorno alla baseline; il movimento se ne allontana
        // in modo SOSTENUTO. Serve piu' di un campione consecutivo oltre soglia.
        if (plugin.gpsBaseline) {
            var driftM = plugin.gpsDriftGuardCm / 100.0
            var ddx = pos.x - plugin.gpsBaseline.x, ddy = pos.y - plugin.gpsBaseline.y
            var d = Math.sqrt(ddx*ddx + ddy*ddy)
            if (d > driftM) plugin.gpsDriftCount++
            else plugin.gpsDriftCount = 0
            // 2 campioni consecutivi oltre soglia = deriva vera (non un singolo salto)
            if (plugin.gpsDriftCount >= 2) {
                // scarta la coda in movimento, tieni solo i campioni "fermi" iniziali
                var keep = plugin.gpsSamples.length - plugin.gpsDriftCount
                if (keep < 1) keep = 1
                plugin.gpsSamples = plugin.gpsSamples.slice(0, keep)
                finalizeGpsSampling()
                return
            }
        }
    }

    function startGpsSampling(maxMs) {
        plugin.gpsSamples = []
        plugin.gpsBaseline = null          // v37.1.38: reset stato deriva
        plugin.gpsDriftCount = 0
        plugin.gpsSampleMaxMs = maxMs || plugin.gpsSampleMaxMsPoint
        plugin.gpsSampleStartMs = Date.now()
        plugin.gpsSampleActive = true
        plugin.pendingValid = false
        plugin.pendingAccuracyM = -1
        gpsCollectOnce()          // primo campione immediato
        gpsSampleTimer.restart()
    }

    function finalizeGpsSampling() {
        gpsSampleTimer.stop()
        plugin.gpsSampleActive = false
        var n = plugin.gpsSamples.length
        if (n === 0) {
            // fallback: scatto istantaneo
            if (positionSource && positionSource.active) {
                var info = positionSource.positionInformation
                if (info.latitudeValid && info.longitudeValid) {
                    var pos = positionSource.projectedPosition
                    plugin.pendingX = pos.x
                    plugin.pendingY = pos.y
                    plugin.pendingAccuracyM = readAccuracyM(info)
                    plugin.pendingValid = true
                }
            }
        } else {
            var xs = [], ys = [], accs = []
            for (var i = 0; i < n; i++) {
                xs.push(plugin.gpsSamples[i].x)
                ys.push(plugin.gpsSamples[i].y)
                if (plugin.gpsSamples[i].acc >= 0) accs.push(plugin.gpsSamples[i].acc)
            }
            plugin.pendingX = gpsMedian(xs)
            plugin.pendingY = gpsMedian(ys)
            plugin.pendingAccuracyM = accs.length ? gpsMedian(accs) : -1
            plugin.pendingValid = true
        }
        var cm = plugin.pendingAccuracyM >= 0 ? (plugin.pendingAccuracyM*100).toFixed(0) : "?"

        // v37.1.35: primo vertice della polilinea -> pubblicalo ORA che la media e' pronta
        // (prima veniva preso come singolo campione grezzo, causando errori sulle tratte)
        if (plugin.pendingLineFirstVertex) {
            plugin.pendingLineFirstVertex = false
            if (plugin.pendingValid) {
                plugin.lineVertices = [{ x: plugin.pendingX, y: plugin.pendingY }]
                plugin.pendingValid = false
                broadcastEvent("LINE_FIRST_VERTEX")
                mainWindow.displayToast("📍 Vertice 1 salvato. Spostati e ripremi.")
            } else {
                plugin.lineMode = false
                mainWindow.displayToast("⚠ Vertice 1 non valido, riprova")
            }
            return
        }

        // v37.1.37: nessun toast accuratezza (scrittura acc_gps_m in sordina)
    }

    // Forza la chiusura del campionamento se ancora attivo (mai bloccante)
    function flushGpsSampling() {
        if (plugin.gpsSampleActive) finalizeGpsSampling()
    }

    // ENTRY POINT compatibile: i PUNTI singoli continuano a chiamare questo
    function capturePendingPosition() {
        // v37.1.47: modalita' PUNTATORE -> posizione = centro mappa, istantanea, no campionamento
        if (plugin.positionMode === "pointer") {
            var c = mapCenterPoint()
            if (c) {
                plugin.pendingX = c.x
                plugin.pendingY = c.y
                plugin.pendingAccuracyM = -1   // manuale: nessuna accuratezza GPS
                plugin.pendingValid = true
            } else {
                plugin.pendingValid = false
                mainWindow.displayToast("⚠ Centro mappa non disponibile")
            }
            return
        }
        startGpsSampling(plugin.lineMode ? plugin.gpsSampleMaxMsVertex
                                         : plugin.gpsSampleMaxMsPoint)
    }

    function isGpsBlocked() {
        // v37.1.47: in modalita' puntatore la posizione e' manuale -> mai bloccare
        if (plugin.positionMode === "pointer") return false
        loadGpsThreshold()
        loadGpsDrift()
        // v37.1.45: accuratezza LIVE al momento del check (non il campione asincrono)
        var acc = readAccuracyM(null)
        if (acc < 0) acc = plugin.pendingAccuracyM   // fallback se live non disponibile
        if (acc < 0) return false                     // sconosciuta -> non bloccare
        plugin.pendingAccuracyM = acc                 // per il messaggio di blocco
        var thrM = plugin.gpsAccuracyThresholdCm / 100.0
        return acc > thrM
    }

    function showGpsBlocked() {
        var cm = plugin.pendingAccuracyM >= 0 ? (plugin.pendingAccuracyM * 100).toFixed(0) : "?"
        gpsWarnText.text = "Accuratezza GPS: " + cm + " cm\n" +
                           "Soglia plugin: " + plugin.gpsAccuracyThresholdCm + " cm\n\n" +
                           "INSERIMENTO BLOCCATO\n\n" +
                           "Il plugin non puo' funzionare con questa accuratezza GPS.\n" +
                           "Usa il + nativo di QField per inserire manualmente, " +
                           "oppure aspetta che il GPS migliori.\n\n" +
                           "(Soglia modificabile dalle impostazioni del plugin)"
        gpsWarnPopup.visible = true
    }

    function closeAll() {
        plugin.editMode = false   // v37.1.62: esci sempre dalla modalita' modifica
        plugin.editFid = null
        Qt.inputMethod.hide()
        // v37.0.30: ripristina activeLayer originale per non bloccare l'utente
        try {
            if (dashBoard) {
                plugin.settingLayerInternally = true   // v37.1.1: ripristino voluto dal plugin
                if (plugin.prevActiveLayer !== null) {
                    dashBoard.activeLayer = plugin.prevActiveLayer
                } else {
                    dashBoard.activeLayer = null
                }
                plugin.settingLayerInternally = false
            }
        } catch(eCA) {}
        plugin.prevActiveLayer = null
        // v37.1.1: rilascia lo stato appiccicoso del plugin
        plugin.selectedLayer = null
        plugin.selectedLayerName = ""
        plugin.selectedLayerDef = null
        layerPicker.visible = false
        overlay.visible = false
        picker.visible = false
        freeTextEditor.visible = false
        vertexChoice.visible = false
        radialMenu.visible = false
        snapPopup.visible = false
        plugin.lineMode = false
        plugin.lineVertices = []
        plugin.pendingValid = false
        plugin.lastLayerVoiceText = ""
        plugin.lastVertexVoiceText = ""
        plugin.lastRadialVoiceText = ""
        if (layerVoiceInput) layerVoiceInput.text = ""
        if (vertexVoiceInput) vertexVoiceInput.text = ""
        if (radialVoiceInput) radialVoiceInput.text = ""
        resetData()
        broadcastEvent("ALL_CLOSED")
    }

    // v37.1.1: chiude i pannelli del plugin SENZA ripristinare activeLayer
    // (usata quando l'utente passa al metodo nativo di QField)
    function hidePanelsOnly() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        picker.visible = false
        freeTextEditor.visible = false
        vertexChoice.visible = false
        if (typeof radialMenu !== "undefined") radialMenu.visible = false
        if (typeof snapPopup !== "undefined") snapPopup.visible = false
        if (typeof gpsWarnPopup !== "undefined") gpsWarnPopup.visible = false
    }

    // v37.1.1: se l'utente cambia layer attivo dal NATIVO, il plugin rilascia
    // la presa senza toccare il layer scelto da lui (fix blocco bidirezionale)
    Connections {
        target: plugin.dashBoard
        function onActiveLayerChanged() {
            if (plugin.settingLayerInternally) return   // cambio fatto dal plugin -> ignora
            plugin.selectedLayer = null
            plugin.selectedLayerName = ""
            plugin.selectedLayerDef = null
            plugin.prevActiveLayer = null
            hidePanelsOnly()
        }
    }

    // v37.1.2: CUSTODE a polling (indipendente dai segnali).
    // Se il plugin e' inattivo (nessun pannello aperto) ma tiene ancora la presa
    // sul layer, vuol dire che l'utente e' passato al nativo senza usare i pulsanti
    // del plugin -> rilascia il layer cosi' il metodo nativo torna libero.
    Timer {
        id: layerJanitorTimer
        interval: 700; repeat: true; running: true
        onTriggered: {
            // v37.1.50 (Step 2): rete di sicurezza. Se il drawer nativo e' aperto e
            // non e' stato il plugin ad aprirlo, con inibizione attiva -> chiudilo.
            try {
                if (plugin.nativeInhibited && !plugin.pluginDrawerOpen) {
                    var ddN = plugin.nativeDrawer || iface.findItemByObjectName("overlayFeatureFormDrawer")
                    if (ddN && ddN.opened) {
                        dismissNativeDrawer()
                        showNativeBlockedMsg("L'inserimento diretto da QField è disabilitato su questo dispositivo.\n\nUsa il pulsante ➕ del plugin Vocal GPS.")
                    }
                }
            } catch(eNat) {}
            // v37.1.3: diagnostica live dei tre layer rilevanti
            try {
                var alN = (dashBoard && dashBoard.activeLayer) ? dashBoard.activeLayer.name : "—"
                var selN = plugin.selectedLayer ? plugin.selectedLayer.name
                           : (plugin.selectedLayerName !== "" ? plugin.selectedLayerName : "—")
                var drwN = "—"
                try {
                    var dd = iface.findItemByObjectName("overlayFeatureFormDrawer")
                    if (dd && dd.featureModel && dd.featureModel.currentLayer)
                        drwN = dd.featureModel.currentLayer.name
                } catch(eD) {}
                plugin.dbgLayers = "AL=" + alN + "  SEL=" + selN + "  DRW=" + drwN
            } catch(eDbg) {}

            var pluginBusy = overlay.visible || layerPicker.visible || picker.visible
                           || freeTextEditor.visible || vertexChoice.visible
                           || (typeof radialMenu !== "undefined" && radialMenu.visible)
                           || (typeof snapPopup !== "undefined" && snapPopup.visible)
                           || (typeof gpsWarnPopup !== "undefined" && gpsWarnPopup.visible)
                           || (typeof gpsWaitModal !== "undefined" && gpsWaitModal.visible)
                           || (typeof cameraLoader !== "undefined" && cameraLoader.active)
                           || (typeof autoSaveTimer !== "undefined" && autoSaveTimer.running)
                           || plugin.lineMode
            if (pluginBusy) return
            // plugin inattivo: se tiene ancora un layer, era una presa non rilasciata
            if (plugin.selectedLayer !== null || plugin.selectedLayerName !== "") {
                try {
                    if (dashBoard) {
                        plugin.settingLayerInternally = true
                        dashBoard.activeLayer = (plugin.prevActiveLayer !== null)
                                              ? plugin.prevActiveLayer : null
                        plugin.settingLayerInternally = false
                    }
                } catch(eJ) {}
                plugin.selectedLayer = null
                plugin.selectedLayerName = ""
                plugin.selectedLayerDef = null
                plugin.prevActiveLayer = null
            }
            // v37.1.6: tieni il drawer nativo allineato al layer attivo, MA solo quando
            // e' chiuso e con un layer attivo valido (mai null -> niente crash).
            // Cosi' il "+" nativo non eredita il layer lasciato dal plugin.
            try {
                var dd2 = iface.findItemByObjectName("overlayFeatureFormDrawer")
                if (dd2 && dd2.featureModel && !dd2.opened
                    && dashBoard && dashBoard.activeLayer
                    && dd2.featureModel.currentLayer !== dashBoard.activeLayer) {
                    dd2.featureModel.currentLayer = dashBoard.activeLayer
                }
            } catch(eSync) {}
        }
    }

    // v37.1.3: indicatore diagnostico layer (toccalo per nasconderlo)
    Rectangle {
        id: dbgBar
        visible: plugin.dbgVisible
        z: 9999
        anchors.top: parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin: 6
        width: dbgTxt.implicitWidth + 20
        height: dbgTxt.implicitHeight + 12
        color: "#cc000000"; radius: 6
        border.color: "#f1c40f"; border.width: 1
        Text {
            id: dbgTxt
            anchors.centerIn: parent
            text: plugin.dbgLayers
            color: "#f1c40f"
            font.pixelSize: 12
            font.family: "monospace"
        }
        MouseArea { anchors.fill: parent; onClicked: plugin.dbgVisible = false }
    }

    QfToolButton {
        id: micBtn
        bgcolor: "#2980b9"
        iconSource: Theme.getThemeVectorIcon("ic_add_white_24dp")
        iconColor: "white"
        round: true
        onClicked: togglePanel()
        Text {
            anchors.centerIn: parent
            text: "+"
            color: "white"
            font.pixelSize: 28
            font.bold: true
            z: 2
        }
    }

    // v37.0.11: tasto ingranaggio (impostazioni snap) — solo testo, no doppia icona
    QfToolButton {
        id: gearBtn
        bgcolor: "#7f8c8d"
        iconColor: "white"
        round: true
        onClicked: openSettingsPanel()
        Text {
            anchors.centerIn: parent
            text: "⚙"
            color: "white"
            font.pixelSize: 24
            font.bold: true
            z: 2
        }
    }

    // v37.1.110: pulsante TOOL unico - apre un menu con GPS/puntatore, Matita, Impostazioni
    QfToolButton {
        id: toolBtn
        bgcolor: "#34495e"
        iconColor: "white"
        round: true
        onClicked: toolMenuPopup.visible = true
        Text {
            anchors.centerIn: parent
            text: "🛠"
            color: "white"; font.pixelSize: 20; z: 2
        }
    }

    // v37.1.55: cattura i cambi di stato di featureListForm/drawer per diagnosi
    // v37.1.114: aggiunto tracciamento di featureForm e mapCanvas.mapTool — servono
    // per capire quale oggetto/segnale usa QField per la MODIFICA nativa (attributi
    // e geometria) di una feature esistente, a differenza dell'INSERIMENTO
    // (overlayFeatureFormDrawer, gia' noto) — vedi showNativeStateLog().
    property string lastFfState: "?"
    property string lastMapToolState: "?"
    Timer {
        interval: 400; repeat: true; running: true
        onTriggered: {
            try {
                var flf = plugin.nativeFeatureListForm || iface.findItemByObjectName("featureListForm")
                var st = flf ? ("" + flf.state) : "NULL"
                if (st !== plugin.lastFlfState) {
                    plugin.lastFlfState = st
                    plugin.stateLog = ("flf=" + st + "  |  " + plugin.stateLog).substring(0, 1500)
                }
            } catch(e) {}
            try {
                var d = plugin.nativeDrawer || iface.findItemByObjectName("overlayFeatureFormDrawer")
                var ds = d ? ("open=" + d.opened + ",state=" + d.state) : "NULL"
                if (ds !== plugin.lastDrwState) {
                    plugin.lastDrwState = ds
                    plugin.stateLog = ("drw=" + ds + "  |  " + plugin.stateLog).substring(0, 1500)
                }
            } catch(e2) {}
            try {
                var ff = iface.findItemByObjectName("featureForm")
                // v37.1.116: aggiunto pdo (pluginDrawerOpen) alla riga - serve per capire se il
                // salvataggio del PLUGIN fa transitare anche questo oggetto per FeatureFormEdit
                // (nel qual caso la guardia pluginDrawerOpen gia' esistente ci protegge gratis),
                // o se il plugin non lo tocca mai (nel qual caso non serve nessuna guardia).
                var fs = ff ? ("state=" + ff.state + ",visible=" + ff.visible) : "NULL"
                fs += ",pdo=" + plugin.pluginDrawerOpen
                if (fs !== plugin.lastFfState) {
                    plugin.lastFfState = fs
                    plugin.stateLog = ("ff=" + fs + "  |  " + plugin.stateLog).substring(0, 1500)
                }
                // v37.1.118 (Step 3d): blocco modifica ATTRIBUTI nativa. featureForm e'
                // confermato un oggetto DIVERSO da drawer.featureForm (quello che usa il
                // plugin per salvare, v37.1.116) - forzarlo indietro a "Hidden" quindi non
                // tocca il salvataggio del plugin. Poll ogni 400ms (stesso Timer che gia'
                // traccia lo stato): non e' un blocco a livello dati come quello su
                // inserimento/geometria (v37.1.117, via sessione di editing), ma
                // un'interruzione della UI nativa appena entra in modifica - a differenza
                // dell'inserimento/geometria, qui l'edit attributi nativo NON richiede una
                // sessione di editing attiva sul layer (confermato dal test readOnly), quindi
                // non esiste un blocco "a livello dati" equivalente da usare al suo posto.
                if (ff && plugin.nativeInhibited && ff.state === "FeatureFormEdit") {
                    try { ff.state = "Hidden" } catch(eFF) {}
                    showNativeBlockedMsg("La modifica degli attributi da QField è disabilitata su questo dispositivo.\n\nUsa il pulsante ✏️ del plugin Vocal GPS.")
                }
            } catch(e3) {}
            try {
                var mc = iface.mapCanvas ? iface.mapCanvas() : (iface.findItemByObjectName ? iface.findItemByObjectName("mapCanvas") : null)
                var mt = (mc && mc.mapTool) ? ("" + mc.mapTool) : "NULL"
                if (mt !== plugin.lastMapToolState) {
                    plugin.lastMapToolState = mt
                    plugin.stateLog = ("mapTool=" + mt + "  |  " + plugin.stateLog).substring(0, 1500)
                }
            } catch(e4) {}
            // v37.1.119 (Step 3e): riafferma il blocco sessione-editing ad OGNI giro
            // (0.4s), non solo al cambio di nativeInhibited (v37.1.117). La modifica
            // geometria nativa (sposta punto/vertice linea) evidentemente riapre da
            // sola una sessione di editing sul layer quando l'operatore la avvia,
            // aggirando il rollBack() fatto una tantum. Richiamando rollBack() ad ogni
            // giro, se il nativo la riapre viene richiusa entro 0.4s - non tocca il
            // salvataggio del plugin (gia' verificato che non dipende da questa
            // sessione, v37.1.117 Test B).
            try {
                if (plugin.nativeInhibited) plugin.applyNativeLayerEditState(false)
            } catch(e5) {}
        }
    }

    // v37.1.58: RIMOSSO il tentativo di bloccare la modifica attributi via stato "Edit"
    // del drawer: non bloccava gli attributi e faceva sparire il tasto modifica geometrica.
    // La modifica attributi nativa passa da un altro meccanismo (da individuare per lo Step 2b).
    // Resta bloccato solo l'INSERIMENTO nativo (watcher su opened qui sotto).


    // v37.1.50 (Step 2): watcher istantaneo. Se il drawer nativo si apre e NON e'
    // stato il plugin ad aprirlo, e l'inibizione e' attiva -> chiudilo subito.
    Connections {
        target: plugin.nativeDrawer
        function onOpenedChanged() {
            try {
                if (plugin.nativeDrawer && plugin.nativeDrawer.opened
                    && plugin.nativeInhibited && !plugin.pluginDrawerOpen) {
                    dismissNativeDrawer()
                    showNativeBlockedMsg("L'inserimento diretto da QField è disabilitato su questo dispositivo.\n\nUsa il pulsante ➕ del plugin Vocal GPS.")
                }
            } catch(e) {}
        }
    }

    // v37.1.52: chiude il drawer nativo. NIENTE rollBack sul layer (rischiava di
    // annullare/corrompere l'inserimento del plugin, specie sulle tratte in modalita'
    // puntatore). L'eventuale log "leaveUpdateMode" e' cosmetico: l'elemento si salva.
    function dismissNativeDrawer() {
        var d = plugin.nativeDrawer || iface.findItemByObjectName("overlayFeatureFormDrawer")
        if (!d) return
        try { d.close() } catch(e) {}
    }

    // v37.1.119 (Step 3e): popup modale (non un toast, che si vede poco/passa
    // inosservato) per spiegare il blocco nativo - usato per inserimento,
    // modifica attributi e modifica geometria native. Idempotente: se e' gia'
    // visibile non lo riapre (evita che due controlli in sequenza sullo stesso
    // tentativo aprano il popup due volte).
    property string nativeBlockedMsg: ""
    function showNativeBlockedMsg(msg) {
        if (nativeBlockedPopup.visible) return
        plugin.nativeBlockedMsg = msg
        nativeBlockedPopup.visible = true
    }

    // v37.1.114 (Step 3): ricontrolla ogni 30 minuti lo stato "nativo" sul foglio,
    // sempre attivo dall'avvio del plugin (non solo quando si apre il pannello) —
    // cosi' anche un operatore che lavora tutto il giorno solo col nativo riceve
    // l'eventuale reset giornaliero entro 30 minuti dal cambio sul foglio.
    Timer {
        id: nativeCheckTimer
        interval: 30 * 60 * 1000
        repeat: true
        running: true
        onTriggered: plugin.checkNativeUnlock()
    }

    // v37.1.48: mirino disegnato dal plugin, visibile solo in modalita' puntatore.
    // Coincide col punto letto da screenToCoordinate(centro) -> zero scarto.
    Item {
        id: pointerCrosshair
        visible: plugin.positionMode === "pointer"
        z: 8000
        width: 70; height: 70
        Rectangle { anchors.centerIn: parent; width: 3; height: 46; radius: 1.5; color: "#e67e22"; border.color: "#ffffff"; border.width: 0.5 }
        Rectangle { anchors.centerIn: parent; width: 46; height: 3; radius: 1.5; color: "#e67e22"; border.color: "#ffffff"; border.width: 0.5 }
        Rectangle { anchors.centerIn: parent; width: 18; height: 18; radius: 9; color: "transparent"; border.color: "#e67e22"; border.width: 3 }
        Rectangle { anchors.centerIn: parent; width: 4; height: 4; radius: 2; color: "#c0392b" }
    }

    // v37.1.87: pulsante MODIFICA - modifica la feature viva selezionata nativamente (tocco + lista)
    QfToolButton {
        id: editBtn
        bgcolor: "#8e44ad"
        iconColor: "white"
        round: true
        onClicked: startEditDispatch()
        Text {
            anchors.centerIn: parent
            text: "✏️"
            color: "white"; font.pixelSize: 18; z: 2
        }
    }

    // v37.1.47: selettore fonte posizione (GPS / puntatore mappa) - globale
    QfToolButton {
        id: posModeBtn
        bgcolor: plugin.positionMode === "pointer" ? "#e67e22" : "#16a085"
        iconColor: "white"
        round: true
        onClicked: {
            savePositionMode(plugin.positionMode === "pointer" ? "gps" : "pointer")
            mainWindow.displayToast(plugin.positionMode === "pointer"
                ? "📍 Posizione: PUNTATORE mappa (centro schermo)"
                : "🛰 Posizione: GPS")
        }
        Text {
            anchors.centerIn: parent
            text: plugin.positionMode === "pointer" ? "📍" : "🛰"
            color: "white"; font.pixelSize: 20; z: 2
        }
    }

    function openSettingsPanel() {
        // v37.0.11: NON assegnare model — il binding declarative gia regge
        snapDistLabel.text = "Distanza max snap: " + plugin.snapMaxCm + " cm"
        settingsPanel.visible = true
    }

    function findLayerDef(name) {
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            if (plugin.layerDefs[i].name === name) return plugin.layerDefs[i]
        }
        return null
    }

    function tryMatchLayerVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.length < 2) return

        var best = null
        var bestScore = 0
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            var ld = plugin.layerDefs[i]
            var kws = ld.voiceKeywords || []
            for (var j = 0; j < kws.length; j++) {
                var kw = kws[j].toLowerCase()
                if (t.indexOf(kw) !== -1) {
                    if (kw.length > bestScore) { bestScore = kw.length; best = ld }
                }
            }
            if (t.indexOf(ld.name.toLowerCase()) !== -1 ||
                t.indexOf(ld.label.toLowerCase()) !== -1) {
                if (ld.name.length > bestScore) { bestScore = ld.name.length; best = ld }
            }
        }
        if (best) {
            mainWindow.displayToast("🎯 " + best.label + " selezionato")
            selectLayer(best)
        }
    }

    // ── VOICE PARSER PER MODALE VERTICE ─────────────────────────
    function processVertexVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.indexOf("fine") !== -1 || t.indexOf("chiudi") !== -1
                || t.indexOf("termina") !== -1 || t.indexOf("ultimo") !== -1) {
            endLineAndOpenForm()
        } else if (t.indexOf("vertice") !== -1 || t.indexOf("intermedio") !== -1
                   || t.indexOf("punto") !== -1) {
            addIntermediateVertex()
        } else if (t.indexOf("annulla") !== -1 || t.indexOf("cancella") !== -1
                   || t.indexOf("abort") !== -1) {
            vertexChoice.visible = false
            closeAll()
            mainWindow.displayToast("Tratta annullata")
        }
    }

    // Riconosce numero da digitazione o voce (italiano)
    function parseNumberFromText(text) {
        var t = text.toLowerCase().trim()
        var m = t.match(/\d+/)
        if (m) return parseInt(m[0])
        var words = ["zero","uno","due","tre","quattro","cinque","sei",
                     "sette","otto","nove","dieci","undici","dodici",
                     "tredici","quattordici","quindici","sedici"]
        for (var i = 0; i < words.length; i++) {
            if (t.indexOf(words[i]) !== -1) return i
        }
        return -1
    }

    function processRadialVoice(text) {
        var n = parseNumberFromText(text)
        if (n < 1) return
        // v37.0.28: usa posizione (1-based), non preset.id
        var pos0 = n - 1
        if (pos0 >= 0 && pos0 < plugin.currentPresets.length) {
            selectPreset(plugin.currentPresets[pos0])
            return
        }
        // fallback: cerca preset con id (compatibilita')
        for (var i = 0; i < plugin.currentPresets.length; i++) {
            if (plugin.currentPresets[i].id === n) {
                selectPreset(plugin.currentPresets[i])
                return
            }
        }
    }

    function selectPreset(preset) {
        // Pre-popola parsedData con i values del preset
        var d = plugin.parsedData
        if (preset.values) {
            for (var k in preset.values) {
                d[k] = preset.values[k]
            }
        }
        plugin.parsedData = d
        var n = 0
        for (var k2 in d) if (d[k2] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()

        mainWindow.displayToast("✓ Preset " + preset.id + ": " + preset.label)

        // Se layer e' linea, avvia lineMode con primo vertice; altrimenti apri form
        var def = plugin.selectedLayerDef
        if (def && def.geometryType === "line") {
            radialMenu.visible = false
            // v37.1.35: vertice 1 con media (come gli altri vertici), non campione grezzo
            plugin.lineMode = true
            plugin.lineVertices = []
            plugin.pendingLineFirstVertex = true
            Qt.inputMethod.hide()
            startFirstVertexCapture()
        } else {
            // v37.0.9: transizione fluida radial->form per non perdere la tastiera
            // 1) Apri overlay form, 2) sposta focus su inputArea, 3) chiudi radial
            // Cosi il keyboard non viene mai dismesso e Android non chiede di scegliere IME
            plugin.ensureUltimaTub()   // v37.1.9
            overlay.visible = true
            Qt.inputMethod.hide()      // v37.1.41: niente tastiera automatica
            radialMenu.visible = false
            broadcastEvent("FORM_READY")
        }
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.selectedLayerDef = layerDef
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            // v37.0.30: salva activeLayer originale (solo la prima volta in questa sessione)
            if (plugin.prevActiveLayer === null) {
                try { plugin.prevActiveLayer = dashBoard.activeLayer || null } catch(e) {}
            }
            plugin.selectedLayer = layer
            plugin.settingLayerInternally = true     // v37.1.1: cambio voluto dal plugin
            dashBoard.activeLayer = layer
            plugin.settingLayerInternally = false
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        resetData()
        layerPicker.visible = false



        if (layerDef.geometryType === "line" && layerDef.presets && layerDef.presets.length > 0) {
            // Linea CON preset: mostra radial PRIMA di avviare lineMode
            plugin.currentPresets = getSortedPresets(layerDef.presets)
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            // v37.0.41: signal PRIMA di visible
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
            radialMenu.visible = true
            radialFocusTimer.start()
        } else if (layerDef.geometryType === "line") {
            // v37.1.35: vertice 1 con media (come gli altri vertici), non campione grezzo
            plugin.lineMode = true
            plugin.lineVertices = []
            plugin.pendingLineFirstVertex = true
            Qt.inputMethod.hide()
            startFirstVertexCapture()
        } else if (layerDef.presets && layerDef.presets.length > 0) {
            // Layer con preset: mostra menu radial
            plugin.currentPresets = getSortedPresets(layerDef.presets)
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            // v37.0.41: signal PRIMA di visible
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
            radialMenu.visible = true
            radialFocusTimer.start()
        } else {
            // v37.0.41: signal PRIMA di visible
            broadcastEvent("FORM_READY")
            emitVoiceReady()
            plugin.ensureUltimaTub()   // v37.1.9
            overlay.visible = true
            focusTimer.start()
        }
    }

    function findLayer(name) {
        // 1) layer gia' memorizzato dal selectPreset
        if (plugin.selectedLayer) return plugin.selectedLayer
        // 2) layer attivo nel pannello
        if (dashBoard && dashBoard.activeLayer) {
            try { if (dashBoard.activeLayer.name === name) return dashBoard.activeLayer } catch(e) {}
        }
        // 3) v37.1.23: cerca per nome nel progetto. Necessario all'inizio rilevazione,
        //    quando i layer del progetto potrebbero non essere ancora stati registrati
        //    al momento di selectPreset (mapLayersByName tornava undefined e
        //    selectedLayer restava null -> "Seleziona X nel pannello" al salvataggio).
        try {
            var arr = qgisProject.mapLayersByName(name)
            if (arr && arr.length > 0 && arr[0]) {
                plugin.selectedLayer = arr[0]
                return arr[0]
            }
        } catch(e) {}
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fr = plugin.currentFields[i]
            // v37.1.9: le checkbox partono "spente" (valore 0) e hanno sempre
            // uno stato definito, mai vuoto.
            d[fr.key] = (fr.widget === "checkbox") ? (fr.offValue || "No") : ""
        }
        plugin.parsedData = d
        plugin.okCount = 0
        plugin.photo1Path = ""
        plugin.photo2Path = ""
        plugin.photoSlot = 1
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 100; repeat: false
        // v37.1.41: niente tastiera automatica all'apertura del form
        onTriggered: { Qt.inputMethod.hide() }
    }
    Timer {
        id: focusRetry
        interval: 700; repeat: false
        onTriggered: { }
    }
    Timer {
        id: layerFocusTimer
        interval: 100; repeat: false
        onTriggered: { Qt.inputMethod.hide() }
    }
    Timer {
        id: vertexFocusTimer
        interval: 100; repeat: false
        onTriggered: { Qt.inputMethod.hide() }
    }
    Timer {
        id: radialFocusTimer
        interval: 100; repeat: false
        onTriggered: { Qt.inputMethod.hide() }
    }

    function processVoice(text) {
        var t = text.toLowerCase()

        if (t.indexOf("scatta foto") !== -1
                || t.indexOf("fai foto") !== -1
                || t.indexOf("fai una foto") !== -1
                || t.indexOf("scatta una foto") !== -1) {
            inputArea.text = ""
            plugin.lastParsedText = ""
            triggerPhotoCapture()
            return
        }

        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    function triggerPhotoCapture() {
        platformUtilities.createDir(qgisProject.homePath, "DCIM")
        broadcastEvent("FOTO_SCATTA")
        cameraLoader.active = true
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#f5f6f8"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer (voce o tap)"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    visible: false   // v37.1.41: barra voce nascosta (selezione a tap)
                    width: parent.width; height: 44
                    color: "#ffffff"; radius: 8
                    border.color: layerVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: layerVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#1a1d27"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 Di' il nome del layer..."
                        placeholderTextColor: "#5a6378"
                    }
                }

                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#d5dde8" : "#e3eef8"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label +
                                      (modelData.geometryType === "line" ? "  ⟶" : "")
                                color: "#1a1d27"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#2980b9"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── MODALE VERTICE / FINE TRATTA con voice input ────────────
    Rectangle {
        id: vertexChoice
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 460)
            height: vcCol.implicitHeight + 32
            color: "#f5f6f8"; radius: 12

            Column {
                id: vcCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 12

                Text {
                    width: parent.width
                    text: "Disegno tratta"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    id: vertexCountText
                    width: parent.width
                    text: ""
                    color: "#1e8449"; font.pixelSize: 13
                    horizontalAlignment: Text.AlignHCenter
                }

                // Voice input per vertice
                Rectangle {
                    visible: false   // v37.1.41: barra voce nascosta (selezione a tap)
                    width: parent.width; height: 44
                    color: "#ffffff"; radius: 8
                    border.color: vertexVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: vertexVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#1a1d27"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 'vertice' o 'fine tratta'"
                        placeholderTextColor: "#5a6378"
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: vM.pressed ? "#d5dde8" : "#e3eef8"
                    border.color: "#2a5a8a"; border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "📍"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "VERTICE intermedio"
                               color: "#1a1d27"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: vM; anchors.fill: parent
                        onClicked: addIntermediateVertex()
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: fM.pressed ? "#178a3e" : "#1db954"
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "🏁"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "FINE TRATTA"
                               color: "white"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: fM; anchors.fill: parent
                        onClicked: endLineAndOpenForm()
                    }
                }

                Rectangle {
                    width: parent.width; height: 42; radius: 8
                    color: cancM.pressed ? "#2a2d40" : "#ffffff"; border.color: "#c0c5d0"
                    Text { anchors.centerIn: parent; text: "✕ Annulla tratta"
                           color: "#5a6378"; font.pixelSize: 14 }
                    MouseArea {
                        id: cancM; anchors.fill: parent
                        onClicked: {
                            vertexChoice.visible = false
                            closeAll()
                            mainWindow.displayToast("Tratta annullata")
                        }
                    }
                }
            }
        }
    }

    function addIntermediateVertex() {
        // v37.1.35: attendi che il vertice 1 (media) sia stato pubblicato
        if (plugin.pendingLineFirstVertex || plugin.lineVertices.length === 0) {
            mainWindow.displayToast("⏳ Attendi il vertice 1...")
            vertexChoice.visible = false
            return
        }
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            Qt.inputMethod.hide()
            return
        }
        flushGpsSampling()   // v37.1.0: chiude la media se ancora attiva
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        // Nascondi tastiera: torniamo alla mappa fra un vertice e l'altro
        Qt.inputMethod.hide()
        mainWindow.displayToast("📍 Vertice " + plugin.lineVertices.length + " salvato")
    }

    function endLineAndOpenForm() {
        // v37.1.35: attendi che il vertice 1 (media) sia stato pubblicato
        if (plugin.pendingLineFirstVertex || plugin.lineVertices.length === 0) {
            mainWindow.displayToast("⏳ Attendi il vertice 1...")
            vertexChoice.visible = false
            return
        }
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            return
        }
        flushGpsSampling()   // v37.1.0: chiude la media se ancora attiva
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        mainWindow.displayToast("🏁 Tratta chiusa con " +
                                plugin.lineVertices.length + " vertici")

        var def = plugin.selectedLayerDef
        if (def && def.lengthField) {
            var d = plugin.parsedData
            // v37.1.49: in modalita' puntatore (no GPS) la lunghezza resta vuota
            if (plugin.positionMode === "pointer") {
                d[def.lengthField] = ""
            } else {
                var lengthM = calculateLineLength()
                d[def.lengthField] = lengthM.toFixed(2)
            }
            plugin.parsedData = d
            var n = 0
            for (var k in d) if (d[k] !== "") n++
            plugin.okCount = n
            fieldsModel.refresh()
        }

        plugin.ensureUltimaTub()   // v37.1.9: anteprima Ultima Tubazione
        overlay.visible = true
        focusTimer.start()
        broadcastEvent("FORM_READY")
        emitVoiceReady()
    }

    function calculateLineLength() {
        if (plugin.lineVertices.length < 2) return 0
        var total = 0
        var isGeographic = false
        try {
            isGeographic = qgisProject.crs && qgisProject.crs.isGeographic
        } catch(e) {
            var v = plugin.lineVertices[0]
            isGeographic = (Math.abs(v.x) <= 180 && Math.abs(v.y) <= 90)
        }
        for (var i = 1; i < plugin.lineVertices.length; i++) {
            var v1 = plugin.lineVertices[i-1]
            var v2 = plugin.lineVertices[i]
            if (isGeographic) {
                total += haversineDistance(v1.y, v1.x, v2.y, v2.x)
            } else {
                var dx = v2.x - v1.x
                var dy = v2.y - v1.y
                total += Math.sqrt(dx*dx + dy*dy)
            }
        }
        return total
    }

    function haversineDistance(lat1, lon1, lat2, lon2) {
        var R = 6371000
        var toRad = Math.PI / 180
        var dLat = (lat2 - lat1) * toRad
        var dLon = (lon2 - lon1) * toRad
        var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            id: formInner
            property var _initPos: plugin.loadWinPos("form",
                                       Math.max(0, (overlay.width - width) / 2),
                                       2)
            x: _initPos.x
            y: _initPos.y
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.72, 720)
            color: "#f5f6f8"; radius: 12

            Loader {
                id: formDrag
                z: 100
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                sourceComponent: dragHandleComp
                onLoaded: { item.target = formInner; item.winId = "form" }
            }

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 14
                anchors.topMargin: 38
                spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = plugin.selectedLayerDef
                            if (!def) return "⚡ Voice Parser"
                            var suffix = (def.geometryType === "line")
                                ? "  (" + plugin.lineVertices.length + " vertici)"
                                : ""
                            return def.icon + " " + def.label + suffix
                        }
                        color: "#2980b9"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#d5dde8" : "#ffffff"
                        border.color: "#c0c5d0"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#5a6378"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#ffffff"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#5a6378"; font.pixelSize: 11
                }

                Rectangle {
                    visible: false   // v37.1.42: barra dettatura nascosta (si compila a tap sul campo)
                    Layout.fillWidth: true; height: 56
                    color: "#ffffff"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "🎤 Parla ora oppure digita..."
                            color: "#1a1d27"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            // v37.1.22: rimosso onTextChanged -> processVoice che
                            // invocava il parser ad ogni carattere del dettato.
                            // Ora pensa il pollTimer con debounce stabilita' 150ms.
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#5a6378"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                ScrollView {
                    id: fieldsScroll
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    contentWidth: availableWidth
                    ScrollBar.vertical.policy: ScrollBar.AsNeeded
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

                    GridLayout {
                        width: fieldsScroll.availableWidth
                        columns: 2; columnSpacing: 6; rowSpacing: 6
                        Repeater {
                            model: fieldsModel
                            delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            // Stati: VERDE = OK; ROSSO = obbligatorio mancante;
                            //        GIALLO/ARANCIONE = popolato in conflitto (deve essere null);
                            //        GRIGIO = opzionale non popolato
                            color: model.fieldMustNull && model.fieldOk ? "#fff3cd"
                                 : model.fieldOk ? "#d4edda"
                                 : model.fieldRequired ? "#ffd2d2"
                                 : "#f8f8fa"
                            border.color: model.fieldMustNull && model.fieldOk ? "#d68910"
                                        : model.fieldOk ? "#27ae60"
                                        : model.fieldRequired ? "#c0392b"
                                        : "#c0c5d0"
                            border.width: model.fieldRequired && !model.fieldOk ? 3 : 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel
                                              + (model.fieldRequired ? " *" : "")
                                              + (model.fieldMustNull && model.fieldOk ? " (da svuotare)" : "")
                                       font.pixelSize: 9; font.bold: true
                                       color: model.fieldMustNull && model.fieldOk ? "#f39c12"
                                            : model.fieldOk ? "#27ae60"
                                            : model.fieldRequired ? "#c0392b"
                                            : "#5a6378" }
                                Text { text: model.fieldWidget === "checkbox"
                                              ? (model.fieldChecked ? "☑  Sì (copia)" : "☐  No")
                                              : (model.fieldValue !== "" ? model.fieldValue : "—")
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldMustNull && model.fieldOk ? "#f1c40f"
                                            : model.fieldOk ? "#1e8449"
                                            : model.fieldRequired ? "#c0392b"
                                            : "#5a6378"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldReadOnly ? "🔒"
                                      : model.fieldWidget === "checkbox" ? (model.fieldChecked ? "☑" : "☐")
                                      : (model.fieldType === "picker" ? "▾" : "✎")
                                color: "#2980b9"; font.pixelSize: 14
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    // v37.1.8: campi readOnly (es. "Ultima Tubazione")
                                    // non sono modificabili: valore calcolato da QGIS.
                                    if (model.fieldReadOnly) {
                                        mainWindow.displayToast("🔒 " + model.fieldLabel + ": valore calcolato automaticamente")
                                        return
                                    }
                                    // v37.1.16: COPIA gestita ESPLICITAMENTE qui in cima,
                                    // a prescindere da come il modello classifica il widget.
                                    // (cattura tutto PRIMA di refresh(), che invalida 'model').
                                    if (model.fieldKey === "Copia_Ulti") {
                                        try { Qt.inputMethod.hide() } catch(eK) {}
                                        // v37.1.21: lavoro differito al frame successivo
                                        // (refresh() distrugge il delegate corrente).
                                        copiaTimer.start()
                                        return
                                    }
                                    // v37.1.9: altre checkbox -> commuta inline Si/No (1/0),
                                    // senza aprire la tendina.
                                    if (model.fieldWidget === "checkbox") {
                                        Qt.inputMethod.hide()   // v37.1.14: toast non coperto dalla tastiera
                                        // v37.1.15: cattura la chiave PRIMA di refresh(),
                                        // perche' refresh() azzera il modello e model.fieldKey
                                        // diventa undefined subito dopo.
                                        var fkey = model.fieldKey
                                        var fdc = null
                                        for (var ci = 0; ci < plugin.currentFields.length; ci++) {
                                            if (plugin.currentFields[ci].key === fkey) { fdc = plugin.currentFields[ci]; break }
                                        }
                                        var onVal  = fdc && fdc.impliedValue ? fdc.impliedValue : "Si"
                                        var offVal = fdc && fdc.offValue ? fdc.offValue : "No"
                                        var dc = JSON.parse(JSON.stringify(plugin.parsedData))
                                        var nowOn = (dc[fkey] !== onVal)
                                        dc[fkey] = nowOn ? onVal : offVal
                                        plugin.parsedData = dc
                                        var nc = 0
                                        for (var kc in dc) if (dc[kc] !== "") nc++
                                        plugin.okCount = nc
                                        fieldsModel.refresh()
                                        // v37.1.11: copia/svuota i campi tubo
                                        if (fkey === "Copia_Ulti") {
                                            if (nowOn) applyCopiaTubazione()
                                            else clearCopiaTubazione()
                                        }
                                        return
                                    }
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        // FIX v30: Recupera opzioni direttamente da currentFields
                                        // (ListModel non conserva bene gli array)
                                        var opts = []
                                        for (var ii = 0; ii < plugin.currentFields.length; ii++) {
                                            if (plugin.currentFields[ii].key === model.fieldKey) {
                                                opts = plugin.currentFields[ii].options || []
                                                break
                                            }
                                        }
                                        plugin.activeFieldOptions = opts
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }
                }

                // Foto 1
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 48
                    height: 48; radius: 8
                    color: fotoM.pressed ? "#d5dde8" : (plugin.photo1Path !== "" ? "#d4edda" : "#ffffff")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#c0c5d0"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text { text: plugin.photo1Path !== "" ? "✅" : "📷"; font.pixelSize: 18
                               anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: plugin.photo1Path !== ""
                                  ? "Foto 1 acquisita ✔"
                                  : "Foto 1"
                            color: plugin.photo1Path !== "" ? "#1e8449" : "#5a6378"
                            font.pixelSize: 13
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: { plugin.photoSlot = 1; triggerPhotoCapture() }
                    }
                }
                // Foto 2 (visibile solo se il layer la supporta)
                Rectangle {
                    Layout.fillWidth: true
                    // v37.1.33: coercizione a bool (photoField2 e' undefined
                    // sui layer linea -> evita "Unable to assign [undefined] to bool")
                    visible: !!(plugin.selectedLayerDef && plugin.selectedLayerDef.photoField2)
                    Layout.preferredHeight: visible ? 48 : 0
                    height: visible ? 48 : 0
                    radius: 8
                    color: foto2M.pressed ? "#d5dde8" : (plugin.photo2Path !== "" ? "#d4edda" : "#ffffff")
                    border.color: plugin.photo2Path !== "" ? "#27ae60" : "#c0c5d0"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text { text: plugin.photo2Path !== "" ? "✅" : "📷"; font.pixelSize: 18
                               anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: plugin.photo2Path !== ""
                                  ? "Foto 2 acquisita ✔"
                                  : "Foto 2"
                            color: plugin.photo2Path !== "" ? "#1e8449" : "#5a6378"
                            font.pixelSize: 13
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: foto2M; anchors.fill: parent
                        onClicked: { plugin.photoSlot = 2; triggerPhotoCapture() }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    visible: false
                    text: ""
                    color: "#2980b9"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    // v37.1.110: riga geometria/elimina SEPARATA (solo in modifica)
                    Layout.fillWidth: true; spacing: 8
                    visible: plugin.editMode
                    Rectangle {
                        height: 46; Layout.fillWidth: true; radius: 8
                        color: geoM.pressed ? "#1f6f8a" : "#2980b9"
                        Text { anchors.centerIn: parent; text: "📐 Modifica geometria"
                               color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: geoM; anchors.fill: parent
                            onClicked: {
                                // v37.1.111: per i PUNTI non serve il menu (solo spostamento) -> vai diretto
                                if (plugin.editLayerDef && plugin.editLayerDef.geometryType === "point") {
                                    plugin.editMoveMode = true
                                    overlay.visible = false
                                } else {
                                    geoMenuPopup.visible = true
                                }
                            }
                        }
                    }
                    Rectangle {
                        height: 46; Layout.preferredWidth: 110; radius: 8
                        color: delM.pressed ? "#8a1f1f" : "#c0392b"
                        Text { anchors.centerIn: parent; text: "🗑 Elimina"
                               color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: delM; anchors.fill: parent; onClicked: deleteConfirmPopup.visible = true }
                    }
                }
                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#ffffff"; border.color: "#c0c5d0"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#5a6378"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        property bool canSave: {
                            if (plugin.okCount === 0) return false
                            for (var ii = 0; ii < fieldsModel.count; ii++) {
                                var m = fieldsModel.get(ii)
                                if (m.fieldRequired && !m.fieldOk) return false
                                if (m.fieldMustNull && m.fieldOk) return false
                            }
                            var def = plugin.selectedLayerDef
                            if (def && def.photo1Required && plugin.photo1Path === "") return false
                            if (def && def.photo2Required && plugin.photo2Path === "") return false
                            return true
                        }
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: canSave ? (okM.pressed ? "#178a3e" : "#1db954") : "#3a2a2a"
                        Text { anchors.centerIn: parent
                               text: parent.canSave ? "✔ CONFERMA" : "⛔ Vincoli mancanti"
                               color: parent.canSave ? "white" : "#aa8888"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // v37.1.112: processa la coda del trascinamento, una feature per volta (1700ms tra una e l'altra
    // per lasciare il layer libero, come per il salvataggio normale)
    Timer {
        id: dragTimer
        interval: 1000; repeat: true; running: false
        onTriggered: {
            if (plugin.dragIdx >= plugin.dragQueue.length) {
                dragTimer.stop()
                plugin.dragActive = false
                var n = plugin.dragQueue.length
                plugin.dragQueue = []
                plugin.dragIdx = 0
                mainWindow.displayToast("🔗 " + n + " elemento/i agganciato/i aggiornato/i")
                try {
                    var cv = iface.mapCanvas(); if (cv && cv.refresh) cv.refresh()
                } catch(e) {}
                return
            }
            var item = plugin.dragQueue[plugin.dragIdx]
            plugin.dragIdx++
            try {
                var layer = qgisProject.mapLayersByName(item.layerName)[0]
                if (!layer) return
                var it = LayerUtils.createFeatureIteratorFromExpression(layer, "\"fid_1\" = " + item.fid1)
                var live = it && typeof it.next === "function" ? it.next() : null
                if (!live) return
                live.geometry = GeometryUtils.createGeometryFromWkt(item.wkt)
                var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
                drawer.featureModel.currentLayer = layer
                drawer.featureModel.feature = live
                // v37.1.121 (Step 3g): sblocca readOnly PRIMA di drawer.state, non dopo -
                // pluginDrawerOpen=true una riga sotto arrivava troppo tardi ("feature
                // addition disabled" comparso anche sui punti in v37.1.120).
                plugin.applyNativeLayerEditState(true)
                drawer.state = "Edit"
                plugin.pluginDrawerOpen = true
                plugin.editPendingDeleteFid = null
                plugin.editPendingDeleteLayer = null
                drawer.open()
                autoSaveTimer.start()
            } catch(e) {}
        }
    }

    // v37.1.107: timer che forza il ridisegno dei vertici mentre muovi/zoomi la mappa
    Timer {
        id: vtxRefreshTimer
        interval: 150; repeat: true; running: plugin.editVertexMode
        onTriggered: plugin.editVtxRefresh++
    }

    // v37.1.107: sessione EDITING VERTICI - disegno vertici + mirino + barra
    Item {
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.fill: parent
        visible: plugin.editVertexMode
        z: 9800

        // vertici disegnati sulla mappa
        Repeater {
            model: plugin.editVertexMode ? plugin.editVertices.length : 0
            delegate: Rectangle {
                property var scr: (plugin.editVtxRefresh, coordToScreen(plugin.editVertices[index][0], plugin.editVertices[index][1]))
                visible: scr !== null
                width: index === plugin.editActiveVertex ? 20 : 14
                height: width; radius: width/2
                color: index === plugin.editActiveVertex ? "#e67e22" : "#2980b9"
                border.color: "white"; border.width: 2
                x: scr ? scr.x - width/2 : -100
                y: scr ? scr.y - height/2 : -100
                Text {
                    anchors.centerIn: parent
                    text: index + 1
                    color: "white"; font.pixelSize: 8; font.bold: true
                    visible: index === plugin.editActiveVertex
                }
            }
        }

        // mirino centrale
        Rectangle { anchors.centerIn: parent; width: 2; height: 34; color: "#e67e22"; opacity: 0.9 }
        Rectangle { anchors.centerIn: parent; width: 34; height: 2; color: "#e67e22"; opacity: 0.9 }

        // barra pulsanti
        Rectangle {
            anchors.bottom: parent.bottom; anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottomMargin: 80
            width: Math.min(parent.width - 16, 500); height: 176
            color: "#f5f6f8"; radius: 12; border.color: "#2980b9"; border.width: 2
            Column {
                anchors.fill: parent; anchors.margins: 10; spacing: 8
                Text {
                    width: parent.width
                    text: plugin.editActiveVertex < 0
                          ? "Aggancia un vertice, oppure aggiungine uno nuovo sul segmento"
                          : "Vertice " + (plugin.editActiveVertex+1) + " agganciato — posiziona il mirino e premi Sposta (snap attivo)"
                    color: "#2980b9"; font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
                }
                Row {
                    width: parent.width; height: 40; spacing: 8
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 40; radius: 8
                        color: agM.pressed ? "#1f6f8a" : "#2980b9"
                        Text { anchors.centerIn: parent; text: "🎯 Aggancia"; color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: agM; anchors.fill: parent; onClicked: snapNearestVertex() }
                    }
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 40; radius: 8
                        color: plugin.editActiveVertex < 0 ? "#9aa3b0" : (spM.pressed ? "#178a3e" : "#1db954")
                        Text { anchors.centerIn: parent; text: "↦ Sposta qui"; color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: spM; anchors.fill: parent; onClicked: moveActiveVertex() }
                    }
                }
                Rectangle {
                    width: parent.width; height: 40; radius: 8
                    color: addM.pressed ? "#6c3483" : "#8e44ad"
                    Text { anchors.centerIn: parent; text: "➕ Aggiungi vertice (sul segmento vicino)"; color: "white"; font.pixelSize: 12; font.bold: true }
                    MouseArea { id: addM; anchors.fill: parent; onClicked: addVertexAtSegment() }
                }
                Row {
                    width: parent.width; height: 40; spacing: 8
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 40; radius: 8
                        color: faM.pressed ? "#d0d4da" : "#e0e3e8"
                        Text { anchors.centerIn: parent; text: "✕ Annulla"; color: "#5a6378"; font.pixelSize: 13 }
                        MouseArea { id: faM; anchors.fill: parent; onClicked: cancelVertexEdit(false) }
                    }
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 40; radius: 8
                        color: fiM.pressed ? "#178a3e" : "#16a085"
                        Text { anchors.centerIn: parent; text: "✓ Fine / Salva"; color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: fiM; anchors.fill: parent; onClicked: saveVertexEdits() }
                    }
                }
            }
        }
    }

    // v37.1.106: modalita' SPOSTAMENTO GEOMETRIA - mirino + barra conferma
    Item {
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.fill: parent
        visible: plugin.editMoveMode
        z: 9800
        // mirino a croce al centro
        Rectangle {
            anchors.centerIn: parent
            width: 2; height: 40; color: "#2980b9"; opacity: 0.9
        }
        Rectangle {
            anchors.centerIn: parent
            width: 40; height: 2; color: "#2980b9"; opacity: 0.9
        }
        Rectangle {
            anchors.centerIn: parent
            width: 14; height: 14; radius: 7; color: "transparent"
            border.color: "#2980b9"; border.width: 2
        }
        // barra in basso
        Rectangle {
            anchors.bottom: parent.bottom; anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottomMargin: 80
            width: Math.min(parent.width - 24, 460); height: 92
            color: "#f5f6f8"; radius: 12; border.color: "#2980b9"; border.width: 2
            Column {
                anchors.fill: parent; anchors.margins: 10; spacing: 8
                Text {
                    width: parent.width
                    text: "📐 Posiziona il mirino dove spostare l'elemento"
                    color: "#2980b9"; font.pixelSize: 13; font.bold: true
                    horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
                }
                Row {
                    width: parent.width; height: 44; spacing: 10
                    Rectangle {
                        width: (parent.width - 10) / 2; height: 44; radius: 8
                        color: mvAnn.pressed ? "#d0d4da" : "#e0e3e8"
                        Text { anchors.centerIn: parent; text: "✕ Annulla"; color: "#5a6378"; font.pixelSize: 14 }
                        MouseArea { id: mvAnn; anchors.fill: parent
                            onClicked: { plugin.editMoveMode = false; overlay.visible = true } }
                    }
                    Rectangle {
                        width: (parent.width - 10) / 2; height: 44; radius: 8
                        color: mvConf.pressed ? "#1f6f8a" : "#2980b9"
                        Text { anchors.centerIn: parent; text: "✓ Sposta qui"; color: "white"; font.pixelSize: 14; font.bold: true }
                        MouseArea { id: mvConf; anchors.fill: parent; onClicked: moveEditGeometry() }
                    }
                }
            }
        }
    }

    // v37.1.110: menu TOOL - GPS/puntatore, Matita (modifica), Impostazioni
    Rectangle {
        id: toolMenuPopup
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.fill: parent
        color: "#000000cc"
        visible: false
        z: 10000
        MouseArea { anchors.fill: parent; onClicked: toolMenuPopup.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent ? parent.width * 0.85 : 380, 420)
            height: 300
            color: "#f5f6f8"; radius: 14; border.color: "#34495e"; border.width: 2
            Column {
                anchors.fill: parent; anchors.margins: 18; spacing: 14
                Text {
                    width: parent.width; text: "🛠 Strumenti"
                    color: "#34495e"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                // GPS / puntatore (mostra lo stato attuale, e lo cambia)
                Rectangle {
                    width: parent.width; height: 56; radius: 8
                    color: tm1.pressed ? "#0f6e5a" : (plugin.positionMode === "pointer" ? "#e67e22" : "#16a085")
                    Text { anchors.centerIn: parent
                           text: plugin.positionMode === "pointer" ? "📍 Posizione: PUNTATORE  (tocca per GPS)" : "🛰 Posizione: GPS  (tocca per puntatore)"
                           color: "white"; font.pixelSize: 14; font.bold: true }
                    MouseArea { id: tm1; anchors.fill: parent
                        onClicked: {
                            savePositionMode(plugin.positionMode === "pointer" ? "gps" : "pointer")
                            mainWindow.displayToast(plugin.positionMode === "pointer"
                                ? "📍 Posizione: PUNTATORE mappa" : "🛰 Posizione: GPS")
                        }
                    }
                }
                // Matita (modifica)
                Rectangle {
                    width: parent.width; height: 56; radius: 8
                    color: tm2.pressed ? "#6c3483" : "#8e44ad"
                    Text { anchors.centerIn: parent; text: "✏️ Modifica elemento"; color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea { id: tm2; anchors.fill: parent
                        onClicked: { toolMenuPopup.visible = false; startEditDispatch() } }
                }
                // Impostazioni
                Rectangle {
                    width: parent.width; height: 56; radius: 8
                    color: tm3.pressed ? "#5d6d7e" : "#7f8c8d"
                    Text { anchors.centerIn: parent; text: "⚙ Impostazioni plugin"; color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea { id: tm3; anchors.fill: parent
                        onClicked: { toolMenuPopup.visible = false; openSettingsPanel() } }
                }
            }
        }
    }

    // v37.1.109: sotto-menu MODIFICA GEOMETRIA (Sposta elemento / Modifica vertici)
    Rectangle {
        id: geoMenuPopup
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.fill: parent
        color: "#000000cc"
        visible: false
        z: 10000
        MouseArea { anchors.fill: parent; onClicked: geoMenuPopup.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent ? parent.width * 0.85 : 380, 420)
            height: pointOnly ? 210 : 280
            // punto = solo spostamento (niente vertici)
            property bool pointOnly: plugin.editLayerDef && plugin.editLayerDef.geometryType === "point"
            color: "#f5f6f8"; radius: 14; border.color: "#2980b9"; border.width: 2
            Column {
                anchors.fill: parent; anchors.margins: 18; spacing: 14
                Text {
                    width: parent.width
                    text: "📐 Modifica geometria"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Rectangle {
                    width: parent.width; height: 52; radius: 8
                    color: gm1.pressed ? "#1f6f8a" : "#2980b9"
                    Text { anchors.centerIn: parent; text: "↦ Sposta elemento"; color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea { id: gm1; anchors.fill: parent
                        onClicked: { geoMenuPopup.visible = false; plugin.editMoveMode = true; overlay.visible = false } }
                }
                Rectangle {
                    visible: !parent.parent.pointOnly   // niente vertici sui punti
                    width: parent.width; height: 52; radius: 8
                    color: gm2.pressed ? "#6c3483" : "#8e44ad"
                    Text { anchors.centerIn: parent; text: "📍 Modifica vertici"; color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea { id: gm2; anchors.fill: parent
                        onClicked: { geoMenuPopup.visible = false; enterVertexEdit() } }
                }
                Rectangle {
                    width: parent.width; height: 48; radius: 8
                    color: gm3.pressed ? "#d0d4da" : "#e0e3e8"
                    Text { anchors.centerIn: parent; text: "Annulla"; color: "#5a6378"; font.pixelSize: 15 }
                    MouseArea { id: gm3; anchors.fill: parent; onClicked: geoMenuPopup.visible = false }
                }
            }
        }
    }

    // v37.1.104: popup di conferma ELIMINAZIONE (operazione irreversibile)
    Rectangle {
        id: deleteConfirmPopup
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.fill: parent
        color: "#000000cc"
        visible: false
        z: 10000
        MouseArea { anchors.fill: parent; onClicked: {} }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent ? parent.width * 0.85 : 380, 440)
            height: 220
            color: "#f5f6f8"; radius: 14
            border.color: "#c0392b"; border.width: 2
            Column {
                anchors.fill: parent; anchors.margins: 20; spacing: 16
                Text {
                    width: parent.width
                    text: "🗑 Eliminare l'elemento?"
                    color: "#c0392b"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: "L'operazione è irreversibile.\nL'elemento verrà rimosso definitivamente."
                    color: "#3a3f4b"; font.pixelSize: 13
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                }
                Row {
                    width: parent.width; height: 48; spacing: 10
                    Rectangle {
                        width: (parent.width - 10) / 2; height: 48; radius: 8
                        color: annM.pressed ? "#d0d4da" : "#e0e3e8"
                        Text { anchors.centerIn: parent; text: "Annulla"; color: "#5a6378"; font.pixelSize: 15 }
                        MouseArea { id: annM; anchors.fill: parent; onClicked: deleteConfirmPopup.visible = false }
                    }
                    Rectangle {
                        width: (parent.width - 10) / 2; height: 48; radius: 8
                        color: confM.pressed ? "#8a1f1f" : "#c0392b"
                        Text { anchors.centerIn: parent; text: "🗑 Elimina"; color: "white"; font.pixelSize: 15; font.bold: true }
                        MouseArea { id: confM; anchors.fill: parent; onClicked: { deleteConfirmPopup.visible = false; deleteEditFeature() } }
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#f5f6f8"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#2980b9"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                // Bottone "Nessuno" per cancellare il valore (non visibile se required)
                Rectangle {
                    id: nullBtn
                    visible: {
                        // Mostra se il field corrente NON e' required
                        for (var ci = 0; ci < plugin.currentFields.length; ci++) {
                            if (plugin.currentFields[ci].key === plugin.activeFieldKey) {
                                return !plugin.currentFields[ci].required
                            }
                        }
                        return true
                    }
                    width: parent.width; height: visible ? 40 : 0; radius: 6
                    color: nullMA.pressed ? "#fadbd8" : "#fafafa"
                    border.color: "#c0c5d0"; border.width: 1
                    Text { anchors.centerIn: parent; text: "✕ Nessuno (vuoto)"
                           color: "#c0392b"; font.pixelSize: 13; font.italic: true }
                    MouseArea {
                        id: nullMA; anchors.fill: parent
                        onClicked: {
                            var d = JSON.parse(JSON.stringify(plugin.parsedData))
                            d[plugin.activeFieldKey] = ""
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            picker.visible = false
                        }
                    }
                }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#ffffff" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#1e8449" : "#1a1d27"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                // FIX v31: deep copy per garantire reattivita' QML
                                var d = JSON.parse(JSON.stringify(plugin.parsedData))
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                applyAutoFills()   // v37.1.46: es. popola Q.ta_Min_N se Stato=Realizzato
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        // v37.1.42: quando apri un campo da compilare, mostra la tastiera (qui SI serve)
        onVisibleChanged: { if (visible) freeTextFocusTimer.restart() }
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#f5f6f8"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#2980b9"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#ffffff"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#1a1d27"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = JSON.parse(JSON.stringify(plugin.parsedData))
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            applyAutoFills()   // v37.1.46: es. popola Q.ta_Min_N subito dopo Num_Min1
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // v37.1.42: focus + tastiera SOLO quando si apre l'editor di un valore
    Timer {
        id: freeTextFocusTimer
        interval: 120; repeat: false
        onTriggered: { freeTextField.forceActiveFocus(); Qt.inputMethod.show() }
    }

    // ── CAMERA con auto-cattura via intent broadcast ────────────
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                id: cameraItem
                visible: false
                Component.onCompleted: {
                    open()
                    if (plugin.autoCaptureMs > 0) autoCapTimer.start()
                }

                Timer {
                    id: autoCapTimer
                    interval: plugin.autoCaptureMs
                    repeat: false
                    onTriggered: {
                        mainWindow.displayToast("📸 Scatto in corso...")
                        // Invia intent broadcast — MacroDroid intercetta e
                        // simula il tap sul tasto scatto via accessibility
                        broadcastEvent("AUTO_SHUTTER")
                        // Secondo intent dopo 1.5s per il tap di conferma
                        confirmCapTimer.start()
                    }
                }

                Timer {
                    id: confirmCapTimer
                    interval: 1500
                    repeat: false
                    onTriggered: broadcastEvent("AUTO_CONFIRM")
                }

                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    // Assegna allo slot corrente, poi avanza
                    if (plugin.photoSlot === 1) {
                        plugin.photo1Path = filename
                        plugin.photoSlot = 2
                        mainWindow.displayToast("📷 Foto 1 acquisita!")
                    } else {
                        plugin.photo2Path = filename
                        plugin.photoSlot = 1
                        mainWindow.displayToast("📷 Foto 2 acquisita!")
                    }
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onCanceled: {
                    close()
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onClosed: cameraLoader.active = false
            }
        }
    }

    // ── MENU RADIAL (preset per layer con presets) ──────────────
    Rectangle {
        id: radialMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        // Pannello centrale: ruota radiale con bottoni intorno
        Item {
            id: wheelArea
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 660)
            height: width

            // Titolo
            Text {
                anchors.top: parent.top
                anchors.horizontalCenter: parent.horizontalCenter
                text: {
                    var def = plugin.selectedLayerDef
                    return (def ? def.icon + " " + def.label : "") + " - Preset"
                }
                color: "#2980b9"; font.pixelSize: 18; font.bold: true
            }

            // Cerchio centrale con bottone X (annulla)
            Rectangle {
                anchors.centerIn: parent
                width: 100; height: 100; radius: 50
                color: cnclMA.pressed ? "#5a1a1a" : "#3a1a1a"
                border.color: "#8a3a3a"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 2
                    Text { text: "✕"; color: "white"; font.pixelSize: 24
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                    Text { text: "annulla"; color: "#bbb"; font.pixelSize: 10
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                }
                MouseArea {
                    id: cnclMA; anchors.fill: parent
                    onClicked: { radialMenu.visible = false; closeAll() }
                }
            }

            // Bottoni preset disposti in cerchio
            Repeater {
                model: plugin.currentPresets
                delegate: Rectangle {
                    // v37.1.27: doppio anello concentrico su smartphone se preset >= 8.
                    // Su tablet: layout originale invariato (single ring, cerchi 100x100).
                    readonly property int totalCount: plugin.currentPresets.length
                    readonly property bool dbl: plugin.radialDoubleRing
                    // Divisione preset: prima meta' (i piu' usati) sull'anello esterno,
                    // seconda meta' sull'anello interno.
                    readonly property int outerCount: dbl ? Math.ceil(totalCount / 2) : totalCount
                    readonly property int innerCount: dbl ? (totalCount - outerCount) : 0
                    readonly property bool onOuterRing: !dbl || index < outerCount
                    readonly property int posInRing: onOuterRing ? index : (index - outerCount)
                    readonly property int countInRing: onOuterRing ? outerCount : innerCount
                    readonly property real myAngle: (posInRing / Math.max(countInRing, 1)) * 2 * Math.PI - Math.PI / 2
                    // Raggi: esterno 0.44, interno 0.26.
                    // v37.1.31: esterno allargato a 0.44 (era 0.42) per evitare
                    // sovrapposizioni quando l'anello esterno ha 7 celle (es. POZZETTI
                    // con 13 preset totali). Cerchi rimpiccioliti da 70 a 64 per
                    // restare dentro wheelArea anche al raggio piu' largo.
                    readonly property real distance: dbl
                        ? (onOuterRing ? wheelArea.width * 0.44 : wheelArea.width * 0.26)
                        : wheelArea.width * 0.38
                    // Dimensione cerchi: piu' piccoli in doppio anello per non sovrapporsi.
                    // v37.1.31: ridotti da 70 a 64 per fare spazio all'anello esterno largo.
                    readonly property int cellSize: dbl ? 64 : 100
                    width: cellSize; height: cellSize; radius: cellSize / 2
                    x: wheelArea.width / 2 + Math.cos(myAngle) * distance - width / 2
                    y: wheelArea.height / 2 + Math.sin(myAngle) * distance - height / 2
                    color: presetMA.pressed ? "#2a5a8a" : "#e3eef8"
                    border.color: "#2980b9"; border.width: 2

                    Column {
                        anchors.centerIn: parent
                        // v37.1.29: spacing -4 per attaccare davvero numero al simbolo
                        spacing: dbl ? -4 : 1
                        // Immagine (se preset ha "image") oppure emoji "icon"
                        Item {
                            // v37.1.30: riquadro icona piu' grande per i preset con
                            // immagine PNG (POZZETTI) - rendering PreserveAspectFit le
                            // riduceva ulteriormente nel riquadro 26x26 facendole
                            // diventare illeggibili. Per le emoji (icon) il riquadro
                            // resta 26 perche' gia' ben visibile a font 18.
                            readonly property bool hasImage: modelData.image ? true : false
                            width: dbl ? (hasImage ? 36 : 26) : 56
                            height: dbl ? (hasImage ? 36 : 26) : 56
                            anchors.horizontalCenter: parent.horizontalCenter
                            Image {
                                anchors.fill: parent
                                source: modelData.image
                                       ? Qt.resolvedUrl(modelData.image)
                                       : ""
                                fillMode: Image.PreserveAspectFit
                                smooth: true
                                visible: modelData.image ? true : false
                                asynchronous: true
                            }
                            Text {
                                anchors.centerIn: parent
                                visible: !modelData.image
                                text: modelData.icon || "•"
                                font.pixelSize: dbl ? 18 : 28
                            }
                        }
                        Text {
                            text: "" + (index + 1)
                            color: "#2980b9"
                            font.pixelSize: dbl ? 12 : 13
                            font.bold: true
                            horizontalAlignment: Text.AlignHCenter
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                        Text {
                            text: modelData.label
                            color: "#5a6378"
                            // v37.1.29: label a 50px (era 60). Su 2 righe centrate.
                            font.pixelSize: dbl ? 7 : 8
                            width: dbl ? 50 : 90
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            anchors.horizontalCenter: parent.horizontalCenter
                            maximumLineCount: 2
                            elide: Text.ElideRight
                        }
                    }

                    MouseArea {
                        id: presetMA; anchors.fill: parent
                        onClicked: selectPreset(modelData)
                    }
                }
            }
        }

        // Input vocale in basso (numero)
        Rectangle {
            visible: false   // v37.1.41: barra voce nascosta (selezione a tap)
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 80
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(parent.width * 0.7, 360)
            height: 50
            color: "#ffffff"; radius: 8
            border.color: radialVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
            border.width: 2
            TextField {
                id: radialVoiceInput
                anchors.fill: parent
                anchors.leftMargin: 12; anchors.rightMargin: 12
                color: "#1a1d27"; background: null
                font.pixelSize: 16
                placeholderText: "🎤 di' il numero (uno, due, tre...)"
                placeholderTextColor: "#5a6378"
            }
        }
    }

    // ── DIALOG DIAGNOSTICA (persistente, leggibile con calma) ──
    Rectangle {
        id: diagDialog
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 11000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.95, 700)
            height: Math.min(parent.height * 0.85, 700)
            color: "#f5f6f8"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                Text {
                    width: parent.width
                    text: "🔧 Risultato diagnostica"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width
                    height: parent.height - 90
                    color: "#0a0d17"; radius: 8
                    border.color: "#c0c5d0"; border.width: 1
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        clip: true
                        TextArea {
                            id: diagLogArea
                            text: plugin.diagLog
                            color: "#1e8449"
                            font.family: "monospace"
                            font.pixelSize: 11
                            readOnly: true
                            wrapMode: TextArea.Wrap
                            background: null
                        }
                    }
                }

                Rectangle {
                    width: parent.width; height: 44; radius: 8
                    color: closeDiagMA.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ CHIUDI"
                           color: "white"; font.pixelSize: 14; font.bold: true }
                    MouseArea {
                        id: closeDiagMA; anchors.fill: parent
                        onClicked: diagDialog.visible = false
                    }
                }
            }
        }
    }

    // v37.1.72: rilascia la protezione del drawer dopo che il ciclo di salvataggio
    // (incluso l'eventuale passaggio in Edit post-save) si e' concluso.
    Timer {
        id: pluginDrawerReleaseTimer
        interval: 1200; repeat: false
        onTriggered: {
            // chiudi un eventuale drawer rimasto aperto in Edit dal post-save, senza committare
            try {
                var d = plugin.nativeDrawer || iface.findItemByObjectName("overlayFeatureFormDrawer")
                if (d && d.opened) d.close()
            } catch(e) {}
            plugin.pluginDrawerOpen = false
            // v37.1.74: ora che il salvataggio della NUOVA e' del tutto concluso e il layer
            // e' libero, cancella la vecchia (farlo prima, dentro l'autoSaveTimer, falliva con
            // "OGR error deleting feature" perche' il layer era ancora occupato dall'add).
            if (plugin.editPendingDeleteFid !== null && plugin.editPendingDeleteLayer) {
                var delOK = deleteOldFeatureNative(plugin.editPendingDeleteLayer, plugin.editPendingDeleteFid)
                plugin.editSaveDiag = "MODIFICA: " + delOK
                plugin.editPendingDeleteFid = null
                plugin.editPendingDeleteLayer = null
                plugin.editMode = false
                plugin.editCand = null
                plugin.editFid = null
                plugin.editLayer = null
                try {
                    var lyR = findLayer("TRATTE INTERRATE")
                    if (lyR && typeof lyR.triggerRepaint === "function") lyR.triggerRepaint()
                    var cvR = iface.mapCanvas(); if (cvR && cvR.refresh) cvR.refresh()
                } catch(e) {}
            }
        }
    }

    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            plugin.saveOpCount = plugin.saveOpCount + 1   // v37.1.70: conta i salvataggi reali
            if (!plugin.editPendingDeleteFid && plugin.editSaveDiag.indexOf("EDIT save") < 0)
                plugin.editSaveDiag = "saveOp #" + plugin.saveOpCount + " layer=" + plugin.selectedLayerName
                                      + " edit=" + plugin.editMode
            drawer.featureForm.save()
            drawer.close()
            // v37.1.72: NON rilasciare subito la protezione. Dopo il save QField fa
            // transitare il drawer in "Edit" sulla feature nuova; se il watcher interviene
            // in quell'istante, chiude il drawer e provoca un secondo commit (doppione).
            // Tengo pluginDrawerOpen=true e lo rilascio con ritardo, cosi' i watcher
            // restano inerti per tutta la finestra di salvataggio.
            pluginDrawerReleaseTimer.restart()
            // v37.1.74: la cancellazione della vecchia (in modifica) NON avviene piu' qui:
            // e' spostata nel pluginDrawerReleaseTimer, a salvataggio del tutto concluso e
            // layer libero (qui falliva con "OGR error deleting feature", layer occupato).
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            // v37.0.22: invalida cache snap del layer appena modificato
            invalidateSnapCache(plugin.selectedLayerName)
            // v37.1.23: forza il refresh visivo del layer e del canvas. Senza questo
            // la feature finiva nei dati ma non veniva disegnata fino al riavvio
            // (succedeva soprattutto a inizio rilevazione, con il render non ancora
            // completamente inizializzato).
            try {
                var lyr = findLayer(plugin.selectedLayerName)
                if (lyr && typeof lyr.triggerRepaint === "function") lyr.triggerRepaint()
            } catch(eR) {}
            try {
                var canvas = iface.mapCanvas()
                if (canvas && typeof canvas.refresh === "function") canvas.refresh()
            } catch(eC) {}
            closeAll()
        }
    }

    // Dopo chiusura camera, riporta focus al form ed emette VOICE_INPUT_READY
    Timer {
        id: photoReturnTimer
        interval: 350
        repeat: false
        onTriggered: {
            if (overlay.visible) {
                Qt.inputMethod.hide()
                emitVoiceReady()
            }
        }
    }

    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            var d = plugin.parsedData
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                if (fd.key === "OBJECTID") continue
                var val = d[fd.key] || ""
                var lbl = fd.alias || fd.label || fd.key
                var isReq = isRequired(fd, d)
                var mustNull = isMustBeNull(fd, d)
                var isCheck = (fd.widget === "checkbox")
                var isChecked = isCheck && (val === (fd.impliedValue || "Si"))
                append({
                    fieldLabel:    lbl,
                    fieldKey:      fd.key,
                    fieldValue:    val,
                    fieldOk:       isCheck ? isChecked : (val !== ""),
                    fieldType:     fd.type,
                    fieldWidget:   fd.widget || "",
                    fieldChecked:  isChecked,
                    fieldOptions:  fd.options || [],
                    fieldRequired: isReq,
                    fieldMustNull: mustNull,
                    fieldReadOnly: fd.readOnly === true
                })
            }
        }
        Component.onCompleted: refresh()
    }

    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    // v37.0.3: normalizeItalian usata da parseNumericCombine
    function normalizeItalian(text) {
        if (!text) return ""
        var t = ("" + text).toLowerCase()
        t = t.replace(/[àáâ]/g, "a")
        t = t.replace(/[èéê]/g, "e")
        t = t.replace(/[ìíî]/g, "i")
        t = t.replace(/[òóô]/g, "o")
        t = t.replace(/[ùúû]/g, "u")
        // v37.0.7: numeri-parola italiani -> cifre
        var nums = ["zero","uno","due","tre","quattro","cinque","sei","sette","otto","nove","dieci","undici","dodici"]
        for (var ni = 0; ni < nums.length; ni++) {
            var rN = new RegExp("\\b" + nums[ni] + "\\b", "g")
            t = t.replace(rN, ni)
        }
        return t
    }

    // ── PARSER VOCE evoluto con voiceKeys + propagation ─────────
    function parseText(raw) {
        var t = normalizeItalian(raw)
        var d = {}

        // Inizializza d copiando i valori esistenti
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""
        }

        // Per ogni field, prova a matchare
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            var matched = false
            var matchedValue = ""

            if (fd.type === "picker" && fd.options) {
                // v37: GUARD voice-key-first — se il field ha voiceKeys e NESSUNA
                // è nel testo, salta. Stop propagazione cieca.
                var vkPresent = false
                if (fd.voiceKeys) {
                    for (var vki = 0; vki < fd.voiceKeys.length; vki++) {
                        if (t.indexOf(fd.voiceKeys[vki]) !== -1) { vkPresent = true; break }
                    }
                } else {
                    vkPresent = true
                }
                if (vkPresent) {
                    // v37.0.6: calcola FINESTRA dal trigger di QUESTO field
                    // al prossimo trigger di un ALTRO field — i match di opzione
                    // (e Si/No) vengono cercati SOLO in questa finestra
                    var myTrigPosP = -1
                    var myTrigLenP = 0
                    if (fd.voiceKeys) {
                        for (var pv = 0; pv < fd.voiceKeys.length; pv++) {
                            var pp = t.indexOf(fd.voiceKeys[pv])
                            if (pp !== -1 && (myTrigPosP === -1 || pp < myTrigPosP)) {
                                myTrigPosP = pp
                                myTrigLenP = fd.voiceKeys[pv].length
                            }
                        }
                    }
                    var winStartP = (myTrigPosP === -1) ? 0 : myTrigPosP + myTrigLenP
                    var winEndP = t.length
                    if (myTrigPosP !== -1) {
                        for (var ofp = 0; ofp < plugin.currentFields.length; ofp++) {
                            var ofdp = plugin.currentFields[ofp]
                            if (ofdp.key === fd.key) continue
                            if (!ofdp.voiceKeys) continue
                            for (var ovkp = 0; ovkp < ofdp.voiceKeys.length; ovkp++) {
                                var opp = t.indexOf(ofdp.voiceKeys[ovkp], winStartP)
                                if (opp !== -1 && opp < winEndP) winEndP = opp
                            }
                        }
                    }
                    var winP = t.substring(winStartP, winEndP)

                    // Match diretto opzione DENTRO la finestra
                    for (var j = 0; j < fd.options.length; j++) {
                        var opt = fd.options[j].toLowerCase()
                        var hit = false
                        if (opt.length <= 3) {
                            var rex = new RegExp("\\b" + opt + "\\b")
                            hit = rex.test(winP)
                        } else {
                            hit = (winP.indexOf(opt) !== -1)
                        }
                        if (hit) { matchedValue = fd.options[j]; matched = true; break }
                    }
                    // v37.0.28: fallback - cerca opzione nel testo INTERO se voiceKey trovato
                    // Per opzioni lunghe (>=5) match per indexOf
                    // Per "No" e "Si" corte, match SOLO dopo la posizione del trigger del field
                    if (!matched) {
                        // 1) opzioni lunghe
                        for (var jf = 0; jf < fd.options.length; jf++) {
                            var optF = fd.options[jf].toLowerCase()
                            if (optF.length >= 5 && t.indexOf(optF) !== -1) {
                                matchedValue = fd.options[jf]; matched = true; break
                            }
                        }
                        // 2) opzioni corte "No"/"Si" cercate solo dopo myTrigPosP
                        if (!matched && myTrigPosP !== -1) {
                            var afterTrig = t.substring(myTrigPosP + myTrigLenP)
                            for (var jn = 0; jn < fd.options.length; jn++) {
                                var optN = fd.options[jn].toLowerCase()
                                if (optN === "no" && /\bno\b/.test(afterTrig)) {
                                    matchedValue = fd.options[jn]; matched = true; break
                                }
                                if (optN === "si" && /\bsi\b/.test(afterTrig)) {
                                    matchedValue = fd.options[jn]; matched = true; break
                                }
                            }
                        }
                    }
                    if (!matched && fd.voiceKeys) {
                        for (var k = 0; k < fd.voiceKeys.length; k++) {
                            var vk = fd.voiceKeys[k]
                            if (t.indexOf(vk) !== -1) {
                                if (fd.key === "STATO" || fd.key === "STATO_1" || fd.key === "Stato") {
                                    if (vk === "nuovo") { matchedValue = "Realizzato"; matched = true; break }
                                    if (vk === "presente") { matchedValue = "Esistente"; matched = true; break }
                                }
                                // v37.0.6: Si/No cercati SOLO nella finestra del field
                                if (fd.options.length === 2 &&
                                    fd.options.indexOf("Si") !== -1 && fd.options.indexOf("No") !== -1) {
                                    if (winP.search(/\bsi\b/) !== -1) { matchedValue = "Si"; matched = true; break }
                                    if (winP.search(/\bno\b/) !== -1) { matchedValue = "No"; matched = true; break }
                                }
                            }
                        }
                    }
                    // v37.1.8: valore implicito — se il trigger del field e'
                    // presente ma non e' stata pronunciata un'opzione esplicita,
                    // usa fd.impliedValue (es. checkbox "Copia Ultima Tubazione"
                    // -> dire l'alias equivale a "Si").
                    if (!matched && fd.impliedValue !== undefined) {
                        matchedValue = fd.impliedValue; matched = true
                    }
                    if (matched) {
                        d[fd.key] = matchedValue
                        propagateValue(fd, matchedValue, d)
                    }
                }
            } else if (fd.type === "text") {
                if (fd.auto === "length") {
                    var lm = t.match(/lunghezza\s+(\d+(?:[,.]\d+)?)/)
                    if (lm) d[fd.key] = lm[1].replace(",", ".")
                } else if (fd.numericCombine) {
                    // v37.0.5: finestra dal trigger di QUESTO field al primo trigger di un ALTRO
                    var myTrigPos = -1
                    var myTrigLen = 0
                    if (fd.voiceKeys) {
                        for (var kk = 0; kk < fd.voiceKeys.length; kk++) {
                            var pp = t.indexOf(fd.voiceKeys[kk])
                            if (pp !== -1 && (myTrigPos === -1 || pp < myTrigPos)) {
                                myTrigPos = pp
                                myTrigLen = fd.voiceKeys[kk].length
                            }
                        }
                    }
                    if (myTrigPos !== -1) {
                        var winStart = myTrigPos + myTrigLen
                        var winEnd = t.length
                        for (var ofi = 0; ofi < plugin.currentFields.length; ofi++) {
                            var ofd = plugin.currentFields[ofi]
                            if (ofd.key === fd.key) continue
                            if (!ofd.voiceKeys) continue
                            for (var ovk = 0; ovk < ofd.voiceKeys.length; ovk++) {
                                var op2 = t.indexOf(ofd.voiceKeys[ovk], winStart)
                                if (op2 !== -1 && op2 < winEnd) winEnd = op2
                            }
                        }
                        var winNc = t.substring(winStart, winEnd)
                        var combined = parseNumericCombine(winNc)
                        if (combined !== "") d[fd.key] = combined
                    }
                } else if (fd.metricUnits) {
                    // v37.0.10: window-based metric parsing
                    // 1) Trova il PRIMO trigger di QUESTO field
                    // 2) Limita la finestra al primo trigger di un ALTRO field
                    // 3) Cerca il numero (parseMetricValue) DENTRO la finestra
                    if (fd.voiceKeys) {
                        var myMTrigPos = -1
                        var myMTrigLen = 0
                        for (var kk3 = 0; kk3 < fd.voiceKeys.length; kk3++) {
                            var pp3 = t.indexOf(fd.voiceKeys[kk3])
                            if (pp3 !== -1 && (myMTrigPos === -1 || pp3 < myMTrigPos)) {
                                myMTrigPos = pp3
                                myMTrigLen = fd.voiceKeys[kk3].length
                            }
                        }
                        if (myMTrigPos !== -1) {
                            var wmStart = myMTrigPos + myMTrigLen
                            var wmEnd = t.length
                            for (var ofm = 0; ofm < plugin.currentFields.length; ofm++) {
                                var ofdm = plugin.currentFields[ofm]
                                if (ofdm.key === fd.key) continue
                                if (!ofdm.voiceKeys) continue
                                for (var ovkm = 0; ovkm < ofdm.voiceKeys.length; ovkm++) {
                                    var opm = t.indexOf(ofdm.voiceKeys[ovkm], wmStart)
                                    if (opm !== -1 && opm < wmEnd) wmEnd = opm
                                }
                            }
                            var winM = t.substring(wmStart, wmEnd).trim()
                            var vM = parseMetricValue(winM)
                            if (vM !== "") d[fd.key] = vM
                        }
                    }
                } else {
                    // Text field con voiceKeys: cattura numero o testo dopo trigger
                    // v37.0.7: LIMITA la finestra fino al prossimo trigger di un altro field
                    // (cosi tubiera_co non risucchia "tipologia trincea" del field successivo)
                    if (fd.voiceKeys) {
                        for (var kk2 = 0; kk2 < fd.voiceKeys.length; kk2++) {
                            var trig = fd.voiceKeys[kk2]
                            var idx = t.indexOf(trig)
                            if (idx !== -1) {
                                var afterStart = idx + trig.length
                                var afterEnd = t.length
                                for (var ofat = 0; ofat < plugin.currentFields.length; ofat++) {
                                    var ofdt = plugin.currentFields[ofat]
                                    if (ofdt.key === fd.key) continue
                                    if (!ofdt.voiceKeys) continue
                                    for (var ovkt = 0; ovkt < ofdt.voiceKeys.length; ovkt++) {
                                        var opt2 = t.indexOf(ofdt.voiceKeys[ovkt], afterStart)
                                        if (opt2 !== -1 && opt2 < afterEnd) afterEnd = opt2
                                    }
                                }
                                var after = t.substring(afterStart, afterEnd).trim()
                                // v37.0.9: per captureRest NON estrarre solo il numero,
                                // cattura SEMPRE tutto il testo della finestra
                                if (!fd.captureRest) {
                                    var nm = after.match(/^[:\s]*(\d+(?:[.,]\d+)?)/)
                                    if (nm) { d[fd.key] = nm[1].replace(",", "."); break }
                                }
                                // Cattura testo libero — stop a comandi/scatta foto
                                // v37.0.10: cleaning permissivo (maxLen 500, stop solo a comandi azione)
                                var clean = after.replace(/\s*(?:\bconferma\b|\bcancella tutto\b|\bscatta\s+foto\b|\bscatta\s+una\s+foto\b|\bfai\s+foto\b|\bfai\s+una\s+foto\b).*$/, "").trim()
                                clean = clean.substring(0, 500).trim()
                                if (clean.length > 0) { d[fd.key] = clean; break }
                            }
                        }
                    }
                }
            }
        }

        // v37.1.11: rileva transizione della checkbox "Copia Ultima Tubazione"
        // PRIMA di sovrascrivere parsedData, per copiare/svuotare i campi tubo.
        var prevCopia = plugin.parsedData["Copia_Ulti"]
        var newCopia = d["Copia_Ulti"]

        // Deep copy per garantire reattivita' QML
        plugin.parsedData = JSON.parse(JSON.stringify(d))
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()

        // v37.1.11: copia/svuota solo sulla TRANSIZIONE (no ad ogni battuta)
        if (newCopia === "Si" && prevCopia !== "Si") applyCopiaTubazione()
        else if (newCopia !== "Si" && prevCopia === "Si") clearCopiaTubazione()
    }

    // Propaga il valore agli altri campi indicati in field.propagate
    function propagateValue(field, value, dataObj) {
        if (!field.propagate) return
        for (var i = 0; i < field.propagate.length; i++) {
            var targetKey = field.propagate[i]
            var targetField = null
            for (var j = 0; j < plugin.currentFields.length; j++) {
                if (plugin.currentFields[j].key === targetKey) {
                    targetField = plugin.currentFields[j]; break
                }
            }
            if (!targetField) continue
            if (dataObj[targetKey] && dataObj[targetKey] !== "") continue
            if (targetField.options && targetField.options.indexOf("Si") !== -1
                && targetField.options.indexOf("No") !== -1) {
                if (value === "Si" || value === "No") dataObj[targetKey] = value
                else dataObj[targetKey] = "No"
            }
        }
    }

    // ── VINCOLI: required condizionale e null-when ──────────────
    function evalCondition(cond, dataObj) {
        // cond = { field: "X", values: [...] } o { field: "X", notValues: [...] }
        // v37.1.22: oppure { allOf: [cond1, cond2, ...] } per combinazione AND
        if (!cond) return false
        // v37.1.53: condizione sulla modalita' posizione ({ pointerMode: true/false })
        if (cond.pointerMode !== undefined) {
            return (plugin.positionMode === "pointer") === (cond.pointerMode === true)
        }
        if (cond.allOf) {
            for (var a = 0; a < cond.allOf.length; a++) {
                if (!evalCondition(cond.allOf[a], dataObj)) return false
            }
            return true
        }
        if (!cond.field) return false
        var v = dataObj[cond.field] || ""
        if (cond.values) {
            for (var i = 0; i < cond.values.length; i++) {
                if (v === cond.values[i]) return true
            }
            return false
        }
        if (cond.notValues) {
            if (v === "") return false  // se l'altro campo e' vuoto, condizione neutra
            for (var j = 0; j < cond.notValues.length; j++) {
                if (v === cond.notValues[j]) return false
            }
            return true
        }
        // v37.1.22: { field: "X", notEmpty: true } => vero se X e' valorizzato
        if (cond.notEmpty === true) return v !== ""
        if (cond.empty === true) return v === ""
        return false
    }

    // v37.1.44: auto-popolamento di un campo dal valore di un altro, quando la
    // condizione e' soddisfatta. Es. Q.ta_Min_N = Num_Min1 se Stato=Realizzato.
    function applyAutoFills() {
        var d = JSON.parse(JSON.stringify(plugin.parsedData))
        var changed = false
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var f = plugin.currentFields[i]
            if (!f.autoFill || !f.autoFill.fromField) continue
            if (f.autoFill.when && !evalCondition(f.autoFill.when, d)) continue
            var src = d[f.autoFill.fromField]
            if (src === undefined || src === null) src = ""
            if (("" + (d[f.key] === undefined ? "" : d[f.key])) !== ("" + src)) {
                d[f.key] = "" + src
                changed = true
            }
        }
        if (changed) {
            plugin.parsedData = d
            var n = 0
            for (var kk in d) if (d[kk] !== "") n++
            plugin.okCount = n
            try { fieldsModel.refresh() } catch(e) {}
        }
    }

    // v37.1.47: modalita' posizione (globale, persistente)
    function loadPositionMode() {
        if (plugin.positionModeLoaded) return
        try {
            var v = qgisProject.customProperty("vocalGps_positionMode")
            if (v === "pointer" || v === "gps") plugin.positionMode = "" + v
        } catch(e) {}
        plugin.positionModeLoaded = true
    }
    function savePositionMode(m) {
        plugin.positionMode = m
        try { qgisProject.setCustomProperty("vocalGps_positionMode", m) } catch(e) {}
    }
    // Coordinata mappa nel punto centrale dello schermo (dove il plugin disegna
    // il proprio mirino). Usa screenToCoordinate -> nessuno scarto col centro reale.
    function mapCenterPoint() {
        try {
            var mc = iface.mapCanvas()
            if (mc && mc.mapSettings) {
                var ms = mc.mapSettings
                if (ms.screenToCoordinate) {
                    var sp = Qt.point(mc.width / 2, mc.height / 2)
                    var c = ms.screenToCoordinate(sp)
                    var cx = (typeof c.x === "function") ? c.x() : c.x
                    var cy = (typeof c.y === "function") ? c.y() : c.y
                    if (typeof cx === "number" && typeof cy === "number")
                        return { x: cx, y: cy }
                }
                if (ms.center) {   // fallback
                    var c2 = ms.center
                    var cx2 = (typeof c2.x === "function") ? c2.x() : c2.x
                    var cy2 = (typeof c2.y === "function") ? c2.y() : c2.y
                    if (typeof cx2 === "number" && typeof cy2 === "number")
                        return { x: cx2, y: cy2 }
                }
            }
        } catch(e) {}
        return null
    }

    // v37.1.47: avvio cattura primo vertice tratta (dopo lineMode=true, lineVertices=[], pendingLineFirstVertex=true)
    function startFirstVertexCapture() {
        if (plugin.positionMode === "pointer") {
            plugin.pendingLineFirstVertex = false
            var c = mapCenterPoint()
            if (c) {
                plugin.lineVertices = [{ x: c.x, y: c.y }]
                broadcastEvent("LINE_FIRST_VERTEX")
                mainWindow.displayToast("📍 Vertice 1 (mappa). Sposta la mappa e ripremi.")
            } else {
                plugin.lineMode = false
                mainWindow.displayToast("⚠ Centro mappa non disponibile")
            }
        } else {
            mainWindow.displayToast("📍 Rilevo vertice 1... resta fermo")
            startGpsSampling(plugin.gpsSampleMaxMsVertex)
        }
    }

    function isRequired(field, dataObj) {
        if (field.required === true) return true
        if (field.requiredWhen) return evalCondition(field.requiredWhen, dataObj)
        return false
    }

    function isMustBeNull(field, dataObj) {
        if (field.nullWhen) return evalCondition(field.nullWhen, dataObj)
        return false
    }

    function getConstraintViolations() {
        var d = plugin.parsedData
        var missing = []
        var conflict = []
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var f = plugin.currentFields[i]
            if (f.key === "OBJECTID") continue
            var v = d[f.key] || ""
            if (isRequired(f, d) && v === "") {
                missing.push(f.alias || f.label || f.key)
            }
            if (isMustBeNull(f, d) && v !== "") {
                conflict.push(f.alias || f.label || f.key)
            }
        }
        var def = plugin.selectedLayerDef
        if (def) {
            if (def.photo1Required === true && plugin.photo1Path === "") missing.push("Foto 1")
            if (def.photo2Required === true && plugin.photo2Path === "") missing.push("Foto 2")
        }
        return { missing: missing, conflict: conflict }
    }

    // Parser numerico per GIUNTI/PTE naming (con accenti italiani)
    function parseNumericCombine(text) {
        var t = normalizeItalian(text)
        var parts = []
        var consumed = []

        function isConsumed(pos) {
            for (var c = 0; c < consumed.length; c++) {
                if (pos >= consumed[c][0] && pos < consumed[c][1]) return true
            }
            return false
        }

        var re1 = /(?:da\s+)?(\d+)\s+a\s+(\d+)/g
        var m
        while ((m = re1.exec(t)) !== null) {
            parts.push({pos: m.index, val: m[1] + ":" + m[2]})
            consumed.push([m.index, m.index + m[0].length])
        }
        // v37.0.7: regex semplificata — dopo normalize è/é diventano "e"
        // Costruita con new RegExp per evitare problemi del parser QML con char class Unicode
        var re2 = new RegExp("(\\d+)\\s*e\\s*(\\d+)", "g")
        while ((m = re2.exec(t)) !== null) {
            if (isConsumed(m.index)) continue
            // "e" -> SEMPRE "-"
            parts.push({pos: m.index, val: m[1] + "-" + m[2]})
            consumed.push([m.index, m.index + m[0].length])
        }
        var re3 = /\b(\d+)\b/g
        while ((m = re3.exec(t)) !== null) {
            if (isConsumed(m.index)) continue
            parts.push({pos: m.index, val: m[1]})
        }
        if (parts.length === 0) return ""
        parts.sort(function(x, y) { return x.pos - y.pos })
        var vals = []
        for (var p = 0; p < parts.length; p++) vals.push(parts[p].val)
        // v37.0.8: separator "-" per i naming (es "2-14:28" invece di "2,14:28")
        return vals.join("-")
    }

    // Converte espressioni metriche in numero decimale (in metri)
    //   "75 centimetri" -> "0.75"
    //   "1 metro e 20"  -> "1.20"
    //   "0.75"          -> "0.75"
    //   "2 metri"       -> "2"
    //   "1,5 m"         -> "1.5"
    function parseMetricValue(text) {
        var t = text.toLowerCase().trim()
        // FIX v35: leading-zero "035" → "0.35", "012" → "0.12"
        var lz = t.match(/^0(\d+)(?!\.)(?!,)/)
        if (lz) {
            return "0." + lz[1]
        }
        // 1) "X metro/metri e Y" (centimetri impliciti)
        var m1 = t.match(/(\d+(?:[.,]\d+)?)\s*metr[oi]\s+e\s+(\d+(?:[.,]\d+)?)/)
        if (m1) {
            var meters = parseFloat(m1[1].replace(",", "."))
            var cm     = parseFloat(m1[2].replace(",", "."))
            return (meters + cm/100).toFixed(2)
        }
        // 2) "X centimetri" / "X cm"
        var m2 = t.match(/(\d+(?:[.,]\d+)?)\s*(?:centimetr[oi]|cm)/)
        if (m2) {
            var cm2 = parseFloat(m2[1].replace(",", "."))
            return (cm2/100).toFixed(2)
        }
        // 3) "X metri" / "X m"
        var m3 = t.match(/(\d+(?:[.,]\d+)?)\s*(?:metr[oi]\b|m\b)/)
        if (m3) {
            var meters3 = parseFloat(m3[1].replace(",", "."))
            return meters3.toString()
        }
        // 3b) v37.0.11: "X virgola Y" (es "zero virgola settantacinque" -> "0,75" dopo normalize)
        var m3v = t.match(/(\d+)\s+virgola\s+(\d+)/)
        if (m3v) {
            return m3v[1] + "." + m3v[2]
        }
        // 4) v37.0.9: Numero puro ovunque nella finestra
        // (cosi "larghezza e ripristino 0.75" estrae 0.75 anche se ci sono parole spurie)
        var m4 = t.match(/(\d+(?:[.,]\d+)?)/)
        if (m4) {
            return m4[1].replace(",", ".")
        }
        return ""
    }

    function buildLineWkt() {
        var coords = []
        for (var i = 0; i < plugin.lineVertices.length; i++) {
            var v = plugin.lineVertices[i]
            coords.push(v.x + " " + v.y)
        }
        var coordStr = coords.join(", ")
        // v37.0.11: detection robusta (gestisce LineStringZ=1002, MultiLineStringZ=1005, ecc.)
        var useMulti = true
        try {
            var lyr = plugin.selectedLayer
            if (lyr && lyr.wkbType !== undefined) {
                var typeStr = "" + lyr.wkbType
                var num = parseInt(typeStr.replace(/[^\d-]/g, ""))
                if (!isNaN(num) && num !== 0) {
                    // Estrai tipo base: mod 1000 (gestisce Z=+1000, M=+2000, ZM=+3000)
                    var base = ((num % 1000) + 1000) % 1000
                    if (base === 2) useMulti = false       // LineString
                    else if (base === 5) useMulti = true   // MultiLineString
                    else useMulti = true                   // default safer
                } else {
                    // string form
                    var ls = typeStr.toLowerCase()
                    if (ls.indexOf("multi") !== -1) useMulti = true
                    else if (ls.indexOf("line") !== -1) useMulti = false
                }
            }
        } catch(e) { useMulti = true }
        if (useMulti) return "MULTILINESTRING((" + coordStr + "))"
        return "LINESTRING(" + coordStr + ")"
    }

    // ── v37.0.10: SNAP HELPERS ────────────────────────────────
    // v37.0.15: probe multiple API strategies + enumerate layer methods
    // v37.0.21: scopri perche GeoJSON e vuoto + tutti i layer
    function probeGathererAPI() {
        var lines = []
        lines.push("=== PROBE ===")
        lines.push("EDIT SAVE diag: " + plugin.editSaveDiag)
        lines.push("EDIT PREFILL diag: " + plugin.editPrefillDiag)
        lines.push("NATIVE UNLOCK diag: " + plugin.nativeUnlockDiag)
        plugin.diagLog = lines.join("\n")
        diagDialog.visible = true
    }

    // v37.1.114 (indagine Step 3b — blocco modifica nativa): mostra il log stati
    // gia' raccolto in background dal Timer sopra (flf/drw/ff/mapTool) — prima
    // veniva registrato ma non era mai visibile in nessuna UI. Riproduci sul
    // tablet una modifica attributi nativa e una modifica geometria nativa,
    // POI apri questo log: le righe piu' recenti sono in cima.
    function showNativeStateLog() {
        plugin.diagLog = "=== LOG STATI NATIVI (aggiornato in background ogni 0.4s) ===\n" +
            "Riproduci ORA sul tablet, in quest'ordine, POI riapri questo log:\n" +
            "1) tocca un elemento ESISTENTE e modifica un attributo dal form nativo\n" +
            "2) avvia una modifica GEOMETRIA nativa (sposta un vertice)\n" +
            "Le righe piu' recenti sono in cima.\n\n" +
            plugin.stateLog
        diagDialog.visible = true
    }

    // v37.1.114 (indagine Step 3b): prova una lista di NOMI CANDIDATI (ipotesi
    // da verificare sul campo, NON conferme) per gli oggetti che QField usa per
    // la modifica nativa di attributi/geometria — a differenza dell'inserimento
    // (overlayFeatureFormDrawer, gia' noto e bloccato), questo percorso non e'
    // ancora stato identificato. Nessuno di questi nomi viene usato per bloccare
    // nulla: e' solo diagnostica, in linea con la regola "si verifica col probe,
    // non si indovina".
    function probeNativeEditObjects() {
        plugin.diagLog = ""
        // v37.1.116: confronto diretto - featureForm trovato globalmente e' lo STESSO
        // oggetto usato dal plugin per salvare (drawer.featureForm.save())? Se si', la
        // guardia pluginDrawerOpen gia' esistente potrebbe bastare anche per questo.
        diagAdd("=== CONFRONTO OGGETTO featureForm (plugin vs nativo) ===")
        try {
            var drwCmp = iface.findItemByObjectName("overlayFeatureFormDrawer")
            var ffGlobal = iface.findItemByObjectName("featureForm")
            var ffFromDrawer = (drwCmp && drwCmp.featureForm) ? drwCmp.featureForm : null
            diagAdd("drawer trovato: " + (drwCmp ? "si" : "no"))
            diagAdd("featureForm globale trovato: " + (ffGlobal ? "si" : "no"))
            diagAdd("drawer.featureForm trovato: " + (ffFromDrawer ? "si" : "no"))
            diagAdd("sono lo STESSO oggetto? " + (ffGlobal && ffFromDrawer && ffGlobal === ffFromDrawer))
        } catch(eCmp) { diagAdd("EXC: " + eCmp) }
        diagAdd("")
        diagAdd("=== PROBE OGGETTI MODIFICA NATIVA (candidati, da verificare) ===")
        diagAdd("")
        var candidates = [
            "mapCanvas", "identifyTool", "featureForm", "vertexModel",
            "digitizingToolbar", "vertexTool", "mapToolDigitizing",
            "attributeFormEditorsPage", "identifyPanel", "featureListForm",
            "geometryEditorsToolbar", "coordinateLocator"
        ]
        for (var i = 0; i < candidates.length; i++) {
            var name = candidates[i]
            var obj = null
            try { obj = iface.findItemByObjectName(name) } catch(e) { obj = null }
            if (obj) {
                probeMethods(name, obj, [
                    "state", "opened", "visible", "active", "editMode",
                    "currentLayer", "mode", "toolMode", "mapTool"
                ])
            } else {
                diagAdd(name + ": (non trovato)")
            }
            diagAdd("")
        }
        diagDialog.visible = true
    }

    // v37.1.116: probe sull'API per pilotare via codice il toggle "matita"
    // (editing on/off) del layer attivo - confermato che blocca inserimento E
    // modifica geometria native, senza rompere il salvataggio del plugin (Test
    // A/B sul campo). Prova una lista di nomi candidati per il metodo/proprieta'
    // giusta sul layer attivo e su iface - selezionare prima il layer su cui si
    // e' fatto il test A/B, poi lanciare questo probe.
    function probeLayerEditingAPI() {
        plugin.diagLog = ""
        diagAdd("=== PROBE API TOGGLE EDITING LAYER (\"matita\") ===")
        diagAdd("Seleziona lo stesso layer usato nel test A/B prima di leggere questo probe.")
        diagAdd("")
        try {
            var lyr = (dashBoard && dashBoard.activeLayer) ? dashBoard.activeLayer : null
            diagAdd("activeLayer: " + (lyr ? ("" + lyr.name) : "NULL"))
            diagAdd("")
            probeMethods("activeLayer", lyr, [
                "isEditable", "editingAllowed", "readOnly", "isReadOnly",
                "startEditing", "stopEditing", "commitChanges", "rollBack",
                "toggleEditing", "editBuffer", "isValid"
            ])
        } catch(eL) { diagAdd("activeLayer EXC: " + eL) }
        diagAdd("")
        try {
            probeMethods("iface", iface, [
                "toggleEditing", "startEditing", "stopEditing", "isEditable",
                "switchToLayer"
            ])
        } catch(eI) { diagAdd("iface EXC: " + eI) }
        diagDialog.visible = true
    }

    // v37.1.117 (indagine Step 3d — blocco modifica attributi): TEST manuale,
    // inverte layer.readOnly sul layer attivo. E' un flag diverso dalla sessione
    // di editing usata da applyNativeLayerEditState (quella blocca solo
    // inserimento+geometria, confermato). Se readOnly=true blocca ANCHE la
    // modifica attributi nativa senza rompere il salvataggio del plugin, un
    // solo flag risolverebbe tutti e tre i casi invece di due meccanismi
    // separati. Da testare a mano: dopo il tap, su questo stesso layer provare
    // (1) modifica attributi nativa, (2) inserimento/geometria nativa,
    // (3) inserimento/modifica dal PLUGIN - poi ritoccare per tornare com'era.
    function toggleActiveLayerReadOnly() {
        try {
            var lyr = (dashBoard && dashBoard.activeLayer) ? dashBoard.activeLayer : null
            if (!lyr) { mainWindow.displayToast("⚠ Nessun layer attivo selezionato"); return }
            var cur = !!lyr.readOnly
            lyr.readOnly = !cur
            mainWindow.displayToast("🧪 " + lyr.name + ".readOnly = " + (!cur))
        } catch (e) {
            mainWindow.displayToast("⚠ Errore toggle readOnly: " + e)
        }
    }

    function enumerateLayerKeys(layer, label) {
        if (!layer) return "[" + label + ":null]"
        var keys = []
        try {
            for (var k in layer) {
                keys.push(k + ":" + (typeof layer[k]))
            }
        } catch(e) { return "[" + label + ":enumErr " + e + "]" }
        return "[" + label + " keys=" + keys.join(",") + "]"
    }

    function tryGetCandidatePoints(layer) {
        // Returns array of {x,y, fid} from a layer using whatever API works
        var pts = []
        var diag = ""
        // Strategy A: layer.selectedFeatures (if features were pre-selected, irrelevant here)
        // Strategy B: layer.dataProvider then iter
        try {
            var dp = layer.dataProvider
            if (typeof dp === "function") dp = dp()
            if (dp) {
                diag += " dp=" + (typeof dp)
                try {
                    if (typeof dp.getFeatures === "function") {
                        var it = dp.getFeatures()
                        diag += " dp.gf=ok"
                        var f = {}
                        var n = 0
                        while (it && it.nextFeature && it.nextFeature(f) && n < 50000) {
                            n++
                            extractGeomPoints(f.geometry, f.id, pts)
                        }
                        diag += " n=" + n
                        if (pts.length > 0) return { pts: pts, diag: diag, method: "dp.getFeatures" }
                    } else { diag += " dp.gf=" + typeof dp.getFeatures }
                } catch(eDp) { diag += " dpErr=" + eDp }
            } else { diag += " dp=null" }
        } catch(e1) { diag += " strE=" + e1 }

        // Strategy C: enumerate keys
        try {
            var keys = []
            for (var k in layer) keys.push(k)
            diag += " keys=" + keys.slice(0, 80).join(",")
        } catch(e3) { diag += " enumErr=" + e3 }

        return { pts: pts, diag: diag, method: "none" }
    }

    function extractGeomPoints(g, fid, out) {
        if (!g) return
        try {
            var pt = g.asPoint()
            if (pt && pt.x !== undefined && pt.x !== null) { out.push({x:pt.x, y:pt.y, fid:fid}); return }
        } catch(e) {}
        try {
            var pl = g.asPolyline()
            if (pl && pl.length > 0) {
                for (var i = 0; i < pl.length; i++) {
                    var p = pl[i]
                    if (p && p.x !== undefined) out.push({x:p.x, y:p.y, fid:fid})
                }
                if (out.length > 0) return
            }
        } catch(e2) {}
        try {
            var mpl = g.asMultiPolyline()
            if (mpl && mpl.length > 0) {
                for (var mi = 0; mi < mpl.length; mi++) {
                    var ln = mpl[mi]
                    if (!ln) continue
                    for (var vi = 0; vi < ln.length; vi++) {
                        var v = ln[vi]
                        if (v && v.x !== undefined) out.push({x:v.x, y:v.y, fid:fid})
                    }
                }
            }
        } catch(e3) {}
    }

    // v37.1.62 (Step 2b): lista delle feature identificate vicino al mirino
    Rectangle {
        id: editListPopup
        parent: mainWindow ? mainWindow.contentItem : undefined
        anchors.centerIn: parent
        width: Math.min(parent ? parent.width * 0.9 : 400, 520)
        height: Math.min(parent ? parent.height * 0.7 : 500, 560)
        color: "#f5f6f8"; radius: 12
        border.color: "#8e44ad"; border.width: 2
        visible: false
        z: 9500

        Column {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 10

            Text {
                width: parent.width
                text: "✏️ Elementi vicino al mirino"
                color: "#8e44ad"; font.pixelSize: 17; font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }
            Text {
                width: parent.width
                text: "Tocca l'elemento da modificare"
                color: "#5a6378"; font.pixelSize: 12
                horizontalAlignment: Text.AlignHCenter
            }

            ListView {
                width: parent.width
                height: parent.height - 110
                clip: true
                model: plugin.editCandidates
                spacing: 8
                delegate: Rectangle {
                    width: ListView.view.width
                    height: 56
                    color: "#ffffff"; radius: 8
                    border.color: "#c0c5d0"; border.width: 1
                    Column {
                        anchors.left: parent.left; anchors.leftMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 2
                        Text {
                            text: modelData.layerName + (modelData.label !== "" ? ("  ·  " + modelData.label) : "")
                            color: "#1a1d27"; font.pixelSize: 15; font.bold: true
                        }
                        Text {
                            text: "fid " + modelData.fid + "  ·  " + modelData.dist + " m"
                            color: "#5a6378"; font.pixelSize: 11
                        }
                    }
                    MouseArea {
                        anchors.fill: parent
                        onClicked: loadFeatureForEdit(modelData)
                    }
                }
            }

            Rectangle {
                width: parent.width; height: 44
                color: "#e0e3e8"; radius: 8
                Text { anchors.centerIn: parent; text: "Annulla"; color: "#5a6378"; font.pixelSize: 15 }
                MouseArea { anchors.fill: parent; onClicked: editListPopup.visible = false }
            }
        }
    }

    // v37.1.62 (Step 2b): lettura difensiva di un attributo di una feature
    function readFeatureAttr(f, name) {
        try { if (typeof f.attribute === "function") { var v = f.attribute(name); if (v !== undefined) return v } } catch(e1) {}
        try {
            var a = (typeof f.attributes === "function") ? f.attributes() : f.attributes
            if (a && a[name] !== undefined) return a[name]
        } catch(e2) {}
        return undefined
    }

    // v37.1.62 (Step 2b): identifica le feature vicino al mirino (centro mappa)
    // v37.1.63: carica feature complete (geometria + properties) via GeoJSON (metodo affidabile in QField)
    function loadLayerFeaturesGeoJSON(layerName) {
        var L = null
        try { L = qgisProject.mapLayersByName(layerName)[0] } catch(e) {}
        if (!L) return []
        var safeName = layerName.replace(/[^a-zA-Z0-9]/g, "_")
        var path = qgisProject.homePath + "/.edit_ident_" + safeName + ".geojson"
        try {
            LayerUtils.saveVectorLayerAs(L, path, "GeoJSON")
            var content = "" + FileUtils.readFileContent(path)
            if (!content || content.length < 30) return []
            var data = JSON.parse(content)
            if (data && data.features) return data.features
        } catch(e2) {}
        return []
    }

    // v37.1.64: distanza minima (m) dal punto c ai SEGMENTI di una geometria GeoJSON
    // (non solo ai vertici: cosi' rileva anche se il mirino e' in mezzo a una tratta)
    function distPointToSeg(px, py, ax, ay, bx, by) {
        var dx = bx - ax, dy = by - ay
        var len2 = dx*dx + dy*dy
        if (len2 === 0) { var ex = px - ax, ey = py - ay; return Math.sqrt(ex*ex + ey*ey) }
        var t = ((px - ax)*dx + (py - ay)*dy) / len2
        if (t < 0) t = 0; else if (t > 1) t = 1
        var cx = ax + t*dx, cy = ay + t*dy
        var qx = px - cx, qy = py - cy
        return Math.sqrt(qx*qx + qy*qy)
    }
    function minDistGeoJSON(g, c) {
        var best = 1e12
        function updPt(x, y) { var dx = x - c.x, dy = y - c.y; var d = Math.sqrt(dx*dx + dy*dy); if (d < best) best = d }
        function updLine(arr) {
            if (!arr || arr.length === 0) return
            if (arr.length === 1) { updPt(arr[0][0], arr[0][1]); return }
            for (var i = 0; i < arr.length - 1; i++) {
                var d = distPointToSeg(c.x, c.y, arr[i][0], arr[i][1], arr[i+1][0], arr[i+1][1])
                if (d < best) best = d
            }
        }
        try {
            var t = g.type, co = g.coordinates
            if (t === "Point") updPt(co[0], co[1])
            else if (t === "MultiPoint") { for (var i = 0; i < co.length; i++) updPt(co[i][0], co[i][1]) }
            else if (t === "LineString") updLine(co)
            else if (t === "MultiLineString" || t === "Polygon") { for (var k = 0; k < co.length; k++) updLine(co[k]) }
            else if (t === "MultiPolygon") { for (var m = 0; m < co.length; m++) { var poly = co[m]; for (var r = 0; r < poly.length; r++) updLine(poly[r]) } }
        } catch(e) {}
        return best
    }

    // v37.1.63 (Step 2b): identifica le feature vicino al mirino via GeoJSON
    function identifyNearCenter() {
        var c = mapCenterPoint()
        if (!c) { mainWindow.displayToast("⚠ Centro mappa non disponibile"); return }
        var tolM = 8.0
        var results = []
        plugin.editAttrDiag = ""
        for (var li = 0; li < plugin.layerDefs.length; li++) {
            var ld = plugin.layerDefs[li]
            var feats = loadLayerFeaturesGeoJSON(ld.name)
            for (var fi = 0; fi < feats.length; fi++) {
                var f = feats[fi]
                if (!f || !f.geometry) continue
                var best = minDistGeoJSON(f.geometry, c)
                if (best <= tolM) {
                    if (plugin.editAttrDiag === "" && f.properties) {
                        var ak = []
                        for (var kk in f.properties) ak.push(kk)
                        plugin.editAttrDiag = "props=" + ak.slice(0, 30).join(",")
                    }
                    var vals = {}
                    var label = ""
                    if (ld.fields && f.properties) {
                        for (var fj = 0; fj < ld.fields.length; fj++) {
                            var key = ld.fields[fj].key
                            var vv = f.properties[key]
                            if (vv !== undefined && vv !== null && ("" + vv) !== "" && ("" + vv) !== "null") {
                                vals[key] = "" + vv
                                if (label === "") label = "" + vv
                            }
                        }
                    }
                    // v37.1.73: chiave = colonna "fid" del GeoPackage (QgsFeatureId corretto per la cancellazione)
                    // v37.1.102: l'id vero e' in fid_1 (fid e' null nel GeoJSON di QField)
                    var pr = f.properties || {}
                    var fidv = (pr.fid_1 !== undefined && pr.fid_1 !== null) ? pr.fid_1
                               : ((pr.fid !== undefined && pr.fid !== null) ? pr.fid
                               : ((f.id !== undefined && f.id !== null) ? f.id
                               : ((pr.OBJECTID !== undefined) ? pr.OBJECTID : fi)))
                    results.push({ layerName: ld.name, layerDefIndex: li, fid: fidv,
                                   dist: Math.round(best*100)/100, label: label, vals: vals,
                                   props: f.properties, geom: f.geometry })
                }
            }
        }
        results.sort(function(a, b) { return a.dist - b.dist })
        plugin.editCandidates = results.slice(0, 12)
        if (plugin.editCandidates.length === 0) {
            mainWindow.displayToast("Nessun elemento entro " + tolM + " m dal mirino")
        } else {
            editListPopup.visible = true
        }
    }

    // v37.1.66: geometria GeoJSON -> WKT (per ricreare la feature con la stessa geometria)
    function geoJSONToWkt(g) {
        function ring(a) { var s = []; for (var i = 0; i < a.length; i++) s.push(a[i][0] + " " + a[i][1]); return s.join(", ") }
        try {
            var t = g.type, co = g.coordinates
            if (t === "Point") return "POINT(" + co[0] + " " + co[1] + ")"
            if (t === "MultiPoint") { var mp = []; for (var i = 0; i < co.length; i++) mp.push("(" + co[i][0] + " " + co[i][1] + ")"); return "MULTIPOINT(" + mp.join(", ") + ")" }
            if (t === "LineString") return "LINESTRING(" + ring(co) + ")"
            if (t === "MultiLineString") { var ml = []; for (var k = 0; k < co.length; k++) ml.push("(" + ring(co[k]) + ")"); return "MULTILINESTRING(" + ml.join(", ") + ")" }
            if (t === "Polygon") { var pg = []; for (var p = 0; p < co.length; p++) pg.push("(" + ring(co[p]) + ")"); return "POLYGON(" + pg.join(", ") + ")" }
            if (t === "MultiPolygon") { var mpg = []; for (var m = 0; m < co.length; m++) { var rr = []; for (var r = 0; r < co[m].length; r++) rr.push("(" + ring(co[m][r]) + ")"); mpg.push("(" + rr.join(", ") + ")") } return "MULTIPOLYGON(" + mpg.join(", ") + ")" }
        } catch(e) {}
        return ""
    }

    // campi chiave da NON copiare (auto-generati; copiarli darebbe conflitto UNIQUE)
    function isKeyField(name) {
        var n = ("" + name).toLowerCase()
        return (n === "fid" || n === "fid_1" || n === "objectid" || n === "id" || n === "ogc_fid")
    }

    // v37.1.68 (Step 2b): SALVA la modifica ricreando la feature con i valori originali
    // preservati (data_ins, acc_gps_m, operatore...), solo i campi modificati sovrascritti,
    // stessa geometria. Usa il DRAWER (stesso percorso dell'inserimento, collaudato) e poi
    // cancella la vecchia feature. I campi chiave (fid/OBJECTID) NON vengono copiati.
    // v37.1.104: cancella la feature attualmente in modifica (usa l'id corretto = fid_1 / live.id)
    // v37.1.106: raccoglie ricorsivamente tutte le coppie [x,y] di una geometria GeoJSON
    function collectCoordsRec(coords, out) {
        if (!coords || coords.length === 0) return
        if (typeof coords[0] === "number") { out.push(coords); return }
        for (var i = 0; i < coords.length; i++) collectCoordsRec(coords[i], out)
    }
    // trasla ricorsivamente tutte le coordinate di (dx,dy) restituendo nuovi array
    function translateCoordsRec(coords, dx, dy) {
        if (typeof coords[0] === "number") return [coords[0] + dx, coords[1] + dy]
        var out = []
        for (var i = 0; i < coords.length; i++) out.push(translateCoordsRec(coords[i], dx, dy))
        return out
    }

    // v37.1.106: sposta l'INTERA geometria della feature in modifica: il centroide va sul mirino
    function moveEditGeometry() {
        var live = plugin.editLiveFeature
        var lyr = plugin.editLiveLayer
        var ld = plugin.editLayerDef
        if (!live || !lyr || !ld) { mainWindow.displayToast("⚠ Nessun elemento in modifica"); return }
        // geometria attuale (GeoJSON): da cand.geom o da export
        var geom = null
        if (plugin.editCand && plugin.editCand.geom) geom = plugin.editCand.geom
        if (!geom) {
            try {
                var feats = loadLayerFeaturesGeoJSON(ld.name)
                for (var i = 0; i < feats.length; i++) {
                    var pr = feats[i].properties || {}
                    var pf = (pr.fid_1 !== undefined && pr.fid_1 !== null) ? pr.fid_1 : -1
                    if (pf === plugin.editFid || ("" + pf) === ("" + plugin.editFid)) { geom = feats[i].geometry; break }
                }
            } catch(e) {}
        }
        if (!geom || !geom.coordinates) { mainWindow.displayToast("⚠ Geometria non trovata"); return }
        // centroide (media dei vertici)
        var pts = []; collectCoordsRec(geom.coordinates, pts)
        if (pts.length === 0) { mainWindow.displayToast("⚠ Nessun vertice"); return }
        var cx = 0, cy = 0
        for (var p = 0; p < pts.length; p++) { cx += pts[p][0]; cy += pts[p][1] }
        cx /= pts.length; cy /= pts.length
        // offset verso il mirino
        var c = mapCenterPoint()
        if (!c) { mainWindow.displayToast("⚠ Mirino non disponibile"); return }
        var dx = c.x - cx, dy = c.y - cy
        // v37.1.112: trascinamento topologico - SOLO per i punti (vecchia pos = punto, nuova = mirino)
        plugin.dragQueue = []
        if (geom.type === "Point" || geom.type === "MultiPoint") {
            queueAttachedMoves(cx, cy, c.x, c.y, ld.name, plugin.editFid)
        }
        // nuova geometria traslata
        var newGeom = { type: geom.type, coordinates: translateCoordsRec(geom.coordinates, dx, dy) }
        var wkt = geoJSONToWkt(newGeom)
        var applied = false
        try {
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            live.geometry = geometry
            applied = true
        } catch(eA) { plugin.editSaveDiag = "MOVEGEOM EXC:" + eA }
        plugin.editSaveDiag = "MOVEGEOM applied=" + applied + " dx=" + Math.round(dx) + " dy=" + Math.round(dy) + " wktlen=" + wkt.length
        if (!applied) { mainWindow.displayToast("⚠ Impossibile applicare la geometria"); return }
        // salva in Edit (come per gli attributi)
        var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
        drawer.featureModel.currentLayer = lyr
        drawer.featureModel.feature = live
        // v37.1.121 (Step 3g): sblocca readOnly PRIMA di drawer.state, non dopo
        plugin.applyNativeLayerEditState(true)
        drawer.state = "Edit"
        plugin.pluginDrawerOpen = true
        plugin.editPendingDeleteFid = null
        plugin.editPendingDeleteLayer = null
        drawer.open()
        autoSaveTimer.start()
        // esci dalla modalita' spostamento e chiudi
        plugin.editMoveMode = false
        plugin.editMode = false
        plugin.editCand = null
        plugin.editFid = null
        plugin.editLiveFeature = null
        plugin.editLiveLayer = null
        overlay.visible = false
        resetData()
        try {
            if (lyr && typeof lyr.triggerRepaint === "function") lyr.triggerRepaint()
            var cv = iface.mapCanvas(); if (cv && cv.refresh) cv.refresh()
        } catch(e) {}
        mainWindow.displayToast("📐 Geometria spostata")
        // v37.1.112: dopo il salvataggio del punto, aggiorna gli elementi agganciati
        if (plugin.dragQueue.length > 0) startDragProcessing()
    }

    // v37.1.107: ricostruisce la struttura geometrica originale con i vertici modificati (in ordine)
    function rebuildCoordsRec(coords, flat, ctr) {
        if (typeof coords[0] === "number") { var v = flat[ctr.i]; ctr.i++; return [v[0], v[1]] }
        var out = []
        for (var i = 0; i < coords.length; i++) out.push(rebuildCoordsRec(coords[i], flat, ctr))
        return out
    }

    // ottieni la geometria GeoJSON dell'elemento in modifica (da cand.geom o export)
    function getEditGeometry() {
        var ld = plugin.editLayerDef
        if (plugin.editCand && plugin.editCand.geom) return plugin.editCand.geom
        try {
            var feats = loadLayerFeaturesGeoJSON(ld.name)
            for (var i = 0; i < feats.length; i++) {
                var pr = feats[i].properties || {}
                var pf = (pr.fid_1 !== undefined && pr.fid_1 !== null) ? pr.fid_1 : -1
                if (pf === plugin.editFid || ("" + pf) === ("" + plugin.editFid)) return feats[i].geometry
            }
        } catch(e) {}
        return null
    }

    // converte una coordinata (32632) in posizione schermo (px)
    function coordToScreen(x, y) {
        try {
            var ms = iface.mapCanvas().mapSettings
            var pt = GeometryUtils.point(x, y)
            var sp = ms.coordinateToScreen(pt)
            return { x: sp.x, y: sp.y }
        } catch(e) { return null }
    }

    // v37.1.107: entra nella sessione di editing vertici
    function enterVertexEdit() {
        var geom = getEditGeometry()
        if (!geom || !geom.coordinates) { mainWindow.displayToast("⚠ Geometria non trovata"); return }
        var pts = []; collectCoordsRec(geom.coordinates, pts)
        if (pts.length === 0) { mainWindow.displayToast("⚠ Nessun vertice"); return }
        // copia dei vertici (per non modificare l'originale finche' non salvi)
        var copy = []
        for (var i = 0; i < pts.length; i++) copy.push([pts[i][0], pts[i][1]])
        plugin.editVertices = copy
        // v37.1.113: copia delle posizioni originali (per il trascinamento degli agganciati)
        var copyOrig = []
        for (var j = 0; j < pts.length; j++) copyOrig.push([pts[j][0], pts[j][1]])
        plugin.editVerticesOrig = copyOrig
        plugin.editGeomTemplate = geom
        plugin.editActiveVertex = -1
        plugin.editVertexMode = true
        overlay.visible = false
        vtxRefreshTimer.start()
        mainWindow.displayToast("📐 " + copy.length + " vertici — aggancia il piu' vicino al mirino")
    }

    // aggancia il vertice piu' vicino al mirino
    function snapNearestVertex() {
        var c = mapCenterPoint()
        if (!c) return
        var best = -1, bestD = 1e12
        for (var i = 0; i < plugin.editVertices.length; i++) {
            var dx = plugin.editVertices[i][0] - c.x, dy = plugin.editVertices[i][1] - c.y
            var d = dx*dx + dy*dy
            if (d < bestD) { bestD = d; best = i }
        }
        plugin.editActiveVertex = best
        plugin.editVtxRefresh++
        mainWindow.displayToast("Vertice " + (best+1) + " agganciato — posiziona il mirino e premi Sposta")
    }

    // v37.1.108: aggiunge un vertice al PUNTO MEDIO del segmento piu' vicino al mirino (tipo a)
    function addVertexAtSegment() {
        var vv = plugin.editVertices
        if (!vv || vv.length < 2) { mainWindow.displayToast("⚠ Servono almeno 2 vertici"); return }
        var c = mapCenterPoint(); if (!c) return
        // segmento piu' vicino
        var best = -1, bestD = 1e18
        for (var i = 0; i < vv.length - 1; i++) {
            var d = distPointToSeg(c.x, c.y, vv[i][0], vv[i][1], vv[i+1][0], vv[i+1][1])
            if (d < bestD) { bestD = d; best = i }
        }
        if (best < 0) return
        var mid = [(vv[best][0] + vv[best+1][0]) / 2, (vv[best][1] + vv[best+1][1]) / 2]
        // aggiorna il template (solo linee semplici: LineString o MultiLineString a linea singola)
        var tmpl = plugin.editGeomTemplate
        var okIns = false
        try {
            if (tmpl.type === "LineString") { tmpl.coordinates.splice(best+1, 0, [mid[0], mid[1]]); okIns = true }
            else if (tmpl.type === "MultiLineString" && tmpl.coordinates.length === 1) { tmpl.coordinates[0].splice(best+1, 0, [mid[0], mid[1]]); okIns = true }
        } catch(e) {}
        if (!okIns) { mainWindow.displayToast("⚠ Aggiunta vertice non supportata su questa geometria"); return }
        vv.splice(best+1, 0, mid)
        plugin.editVertices = vv
        // v37.1.113: mantieni allineato l'array delle posizioni originali (il nuovo vertice non ha agganci)
        var vo = plugin.editVerticesOrig
        vo.splice(best+1, 0, [mid[0], mid[1]])
        plugin.editVerticesOrig = vo
        plugin.editGeomTemplate = tmpl
        plugin.editActiveVertex = best + 1
        plugin.editVtxRefresh++
        mainWindow.displayToast("➕ Vertice aggiunto sul segmento — ora puoi spostarlo (aggancia + sposta)")
    }

    // v37.1.108: cerca il vertice piu' vicino a c tra TUTTI gli elementi di TUTTI i layer,
    // entro la tolleranza di snap. Restituisce [x,y] o null.
    function findSnapPoint(c) {
        var tolM = (plugin.snapMaxCm > 0 ? plugin.snapMaxCm : 150) / 100.0
        var best = null, bestD = tolM * tolM
        for (var li = 0; li < plugin.layerDefs.length; li++) {
            var feats = []
            try { feats = loadLayerFeaturesGeoJSON(plugin.layerDefs[li].name) } catch(e) { continue }
            for (var fi = 0; fi < feats.length; fi++) {
                if (!feats[fi] || !feats[fi].geometry) continue
                var pts = []
                collectCoordsRec(feats[fi].geometry.coordinates, pts)
                for (var pi = 0; pi < pts.length; pi++) {
                    var dx = pts[pi][0] - c.x, dy = pts[pi][1] - c.y
                    var d = dx*dx + dy*dy
                    if (d < bestD) { bestD = d; best = [pts[pi][0], pts[pi][1]] }
                }
            }
        }
        return best
    }

    // sposta il vertice agganciato sul mirino
    function moveActiveVertex() {
        if (plugin.editActiveVertex < 0) { mainWindow.displayToast("⚠ Aggancia prima un vertice"); return }
        var c = mapCenterPoint()
        if (!c) return
        // v37.1.108: snap ai vertici di altri elementi (se entro tolleranza)
        var snap = findSnapPoint(c)
        var target = snap ? snap : [c.x, c.y]
        var vv = plugin.editVertices
        vv[plugin.editActiveVertex] = target
        plugin.editVertices = vv
        plugin.editVtxRefresh++
        if (snap) mainWindow.displayToast("Vertice " + (plugin.editActiveVertex+1) + " agganciato a un elemento vicino ✓")
        else mainWindow.displayToast("Vertice " + (plugin.editActiveVertex+1) + " spostato")
    }

    // salva tutte le modifiche ai vertici
    function saveVertexEdits() {
        var live = plugin.editLiveFeature
        var lyr = plugin.editLiveLayer
        var tmpl = plugin.editGeomTemplate
        if (!live || !lyr || !tmpl) { mainWindow.displayToast("⚠ Sessione non valida"); cancelVertexEdit(); return }
        var newCoords = rebuildCoordsRec(tmpl.coordinates, plugin.editVertices, { i: 0 })
        var newGeom = { type: tmpl.type, coordinates: newCoords }
        var wkt = geoJSONToWkt(newGeom)
        var applied = false
        try {
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            live.geometry = geometry
            applied = true
        } catch(eA) { plugin.editSaveDiag = "VTXSAVE EXC:" + eA }
        plugin.editSaveDiag = "VTXSAVE applied=" + applied + " nVertici=" + plugin.editVertices.length + " wktlen=" + wkt.length
        if (!applied) { mainWindow.displayToast("⚠ Impossibile applicare la geometria"); return }
        var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
        drawer.featureModel.currentLayer = lyr
        drawer.featureModel.feature = live
        // v37.1.121 (Step 3g): sblocca readOnly PRIMA di drawer.state, non dopo
        plugin.applyNativeLayerEditState(true)
        drawer.state = "Edit"
        plugin.pluginDrawerOpen = true
        plugin.editPendingDeleteFid = null
        plugin.editPendingDeleteLayer = null
        drawer.open()
        autoSaveTimer.start()
        // v37.1.113: trascinamento agganciati per ogni vertice EFFETTIVAMENTE spostato
        plugin.dragQueue = []
        var origV = plugin.editVerticesOrig, finV = plugin.editVertices
        var exclLayer = lyr.name, exclFid1 = plugin.editFid
        for (var vi = 0; vi < origV.length && vi < finV.length; vi++) {
            var od = Math.abs(origV[vi][0] - finV[vi][0]) + Math.abs(origV[vi][1] - finV[vi][1])
            if (od > 0.01) queueAttachedMoves(origV[vi][0], origV[vi][1], finV[vi][0], finV[vi][1], exclLayer, exclFid1)
        }
        cancelVertexEdit(true)
        try {
            if (lyr && typeof lyr.triggerRepaint === "function") lyr.triggerRepaint()
            var cv = iface.mapCanvas(); if (cv && cv.refresh) cv.refresh()
        } catch(e) {}
        mainWindow.displayToast("📐 Vertici salvati")
        if (plugin.dragQueue.length > 0) startDragProcessing()
    }

    // esci dalla sessione vertici (saved=true se abbiamo gia' salvato)
    function cancelVertexEdit(saved) {
        plugin.editVertexMode = false
        plugin.editActiveVertex = -1
        plugin.editVertices = []
        plugin.editVerticesOrig = []
        plugin.editGeomTemplate = null
        vtxRefreshTimer.stop()
        if (saved) {
            plugin.editMode = false
            plugin.editCand = null
            plugin.editFid = null
            plugin.editLiveFeature = null
            plugin.editLiveLayer = null
            resetData()
        } else {
            overlay.visible = true   // torna al form
        }
    }

    // v37.1.112: sposta ricorsivamente i vertici entro tol2 da (ox,oy) verso (nx,ny)
    function moveMatchingCoords(coords, ox, oy, nx, ny, tol2, cnt) {
        if (typeof coords[0] === "number") {
            var dx = coords[0] - ox, dy = coords[1] - oy
            if (dx*dx + dy*dy <= tol2) { cnt.n++; return [nx, ny] }
            return [coords[0], coords[1]]
        }
        var out = []
        for (var i = 0; i < coords.length; i++) out.push(moveMatchingCoords(coords[i], ox, oy, nx, ny, tol2, cnt))
        return out
    }

    // v37.1.112: trova gli elementi (tutti i layer) con un vertice a <=30cm da (ox,oy)
    // e accoda la loro geometria aggiornata (quel vertice spostato su (nx,ny)).
    // Esclude la feature in modifica (exclLayer/exclFid1).
    function queueAttachedMoves(ox, oy, nx, ny, exclLayer, exclFid1) {
        var tol2 = 0.30 * 0.30   // 30 cm, stretta
        for (var li = 0; li < plugin.layerDefs.length; li++) {
            var lname = plugin.layerDefs[li].name
            var feats = []
            try { feats = loadLayerFeaturesGeoJSON(lname) } catch(e) { continue }
            for (var fi = 0; fi < feats.length; fi++) {
                if (!feats[fi] || !feats[fi].geometry) continue
                var pr = feats[fi].properties || {}
                var f1 = (pr.fid_1 !== undefined && pr.fid_1 !== null) ? pr.fid_1 : -1
                if (lname === exclLayer && ("" + f1) === ("" + exclFid1)) continue   // salta l'elemento che sposti
                var cnt = { n: 0 }
                var newCoords = moveMatchingCoords(feats[fi].geometry.coordinates, ox, oy, nx, ny, tol2, cnt)
                if (cnt.n > 0) {
                    var wkt = geoJSONToWkt({ type: feats[fi].geometry.type, coordinates: newCoords })
                    if (wkt !== "") plugin.dragQueue.push({ layerName: lname, fid1: f1, wkt: wkt })
                }
            }
        }
    }

    // v37.1.112: avvia il processamento della coda (una feature alla volta, layer libero tra una e l'altra)
    function startDragProcessing() {
        if (plugin.dragQueue.length === 0) return
        plugin.dragIdx = 0
        plugin.dragActive = true
        mainWindow.displayToast("🔗 Aggiorno " + plugin.dragQueue.length + " elemento/i agganciato/i…")
        dragTimer.restart()
    }

    function deleteEditFeature() {
        var lyr = plugin.editLiveLayer
        var live = plugin.editLiveFeature
        if (!lyr) { mainWindow.displayToast("⚠ Nessun elemento da eliminare"); return }
        // id corretto: quello della feature viva se disponibile, altrimenti editFid (fid_1)
        var delId = plugin.editFid
        try { if (live && live.id !== undefined && live.id >= 0) delId = live.id } catch(e) {}
        var diag = "delId=" + delId
        var ok = false
        // via 1: LayerUtils.deleteFeature(qgisProject, layer, id) con l'id GIUSTO
        try {
            var r1 = LayerUtils.deleteFeature(qgisProject, lyr, delId)
            diag += " LU=" + r1
            if (r1 === true) ok = true
        } catch(e1) { diag += " LU_EXC:" + e1 }
        // via 2 (se la 1 non basta): featureModel con la feature viva caricata
        if (!ok && live) {
            try {
                var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
                var fm = drawer ? drawer.featureModel : null
                if (fm) {
                    fm.currentLayer = lyr
                    fm.feature = live
                    var r2 = fm.deleteFeature()
                    diag += " FM=" + r2
                    if (r2 === true || r2 === undefined) ok = true
                }
            } catch(e2) { diag += " FM_EXC:" + e2 }
        }
        plugin.editSaveDiag = "DELETE " + diag + " -> ok=" + ok
        // chiudi il form e ripulisci lo stato modifica
        plugin.editMode = false
        plugin.editCand = null
        plugin.editFid = null
        plugin.editLiveFeature = null
        plugin.editLiveLayer = null
        overlay.visible = false
        resetData()
        // refresh visivo
        try {
            if (lyr && typeof lyr.triggerRepaint === "function") lyr.triggerRepaint()
            var cv = iface.mapCanvas(); if (cv && cv.refresh) cv.refresh()
        } catch(e) {}
        if (ok) mainWindow.displayToast("🗑 Elemento eliminato")
        else mainWindow.displayToast("⚠ Eliminazione non riuscita — vedi PROBE")
    }

    function saveEditedFeature() {
        // v37.1.87: modifica la feature VIVA (focusedFeature, id interno valido).
        var live = plugin.editLiveFeature
        var lyr = plugin.editLiveLayer
        var ld = plugin.editLayerDef
        if (!live || !lyr || !ld) { mainWindow.displayToast("⚠ Elemento non modificabile: riprova selezionandolo dalla lista"); return false }
        try {
            // v37.1.95: applica SOLO i campi effettivamente cambiati (i NULL non toccati restano NULL)
            var d = plugin.parsedData
            var orig = plugin.editOriginalData || {}
            var nChanged = 0
            var changedList = ""
            for (var fk in d) {
                if (isKeyField(fk)) continue
                if (d[fk] === orig[fk]) continue   // non cambiato -> non toccare
                try { live.setAttribute(fk, d[fk]); nChanged++; changedList += fk + "(" + orig[fk] + "->" + d[fk] + ") " } catch(e1) {}
            }
            // campi svuotati (c'erano, ora vuoti)
            for (var ok in orig) {
                if (isKeyField(ok)) continue
                if ((d[ok] === undefined || d[ok] === "") && orig[ok] !== "" && orig[ok] !== undefined) {
                    try { live.setAttribute(ok, null); nChanged++ } catch(e){}
                }
            }
            // foto (eventualmente ri-scattate), per nome
            try {
                if (ld.photoField && plugin.photo1Path !== "") live.setAttribute(ld.photoField, plugin.photo1Path)
                if (ld.photoField2 && plugin.photo2Path !== "") live.setAttribute(ld.photoField2, plugin.photo2Path)
            } catch(e3) {}

            // v37.1.97: featureForm.update() NON salva sul database (aggiorna solo la vista) ->
            // scartato. Uso il drawer Edit con la feature viva, che salva davvero.
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = lyr
            drawer.featureModel.feature = live
            // v37.1.121 (Step 3g): sblocca readOnly PRIMA di drawer.state, non dopo
            plugin.applyNativeLayerEditState(true)
            drawer.state = "Edit"
            plugin.pluginDrawerOpen = true
            plugin.editPendingDeleteFid = null
            plugin.editPendingDeleteLayer = null
            plugin.editSaveDiag = "SAVE drawer Edit nChanged=" + nChanged + " [" + changedList + "]"
            drawer.open()
            autoSaveTimer.start()
            return true
        } catch(eMain) {
            plugin.editSaveDiag = "EXC: " + eMain
            mainWindow.displayToast("⚠ Errore modifica: " + eMain)
            return false
        }
    }

    // v37.1.87: avvia la modifica dalla feature VIVA selezionata nativamente (tocco + lista)
    // v37.1.102: sceglie il flusso di modifica: se c'e' gia' una feature selezionata
    // nativamente la usa (editFocusedFeature); altrimenti apre la lista del plugin (mirino).
    function startEditDispatch() {
        var hasNative = false
        try {
            var ff = iface.findItemByObjectName("featureForm")
            if (ff && ff.selection && ff.selection.focusedFeature) {
                var id = -1; try { id = ff.selection.focusedFeature.id } catch(e){}
                if (id !== undefined && id >= 0) hasNative = true
            }
        } catch(e){}
        if (hasNative) editFocusedFeature()
        else identifyNearCenter()
    }

    function editFocusedFeature() {
        var ff = iface.findItemByObjectName("featureForm")
        if (!ff || !ff.selection) { mainWindow.displayToast("⚠ Seleziona prima l'elemento dalla lista nativa di QField"); return }
        var live = null, lyr = null, fid = -1
        try { live = ff.selection.focusedFeature } catch(e) {}
        try { lyr = ff.selection.focusedLayer } catch(e) {}
        try { fid = live.id } catch(e) {}
        if (!live || !lyr || fid < 0 || fid === undefined) {
            mainWindow.displayToast("⚠ Seleziona prima l'elemento dalla lista nativa di QField, poi premi ✏️")
            return
        }
        // trova la definizione plugin del layer
        var ld = null, ldi = -1
        for (var li = 0; li < plugin.layerDefs.length; li++) {
            if (plugin.layerDefs[li].name === lyr.name) { ld = plugin.layerDefs[li]; ldi = li; break }
        }
        if (!ld) { mainWindow.displayToast("⚠ Layer non gestito dal plugin: " + lyr.name); return }

        plugin.editLiveFeature = live
        plugin.editLiveLayer = lyr
        plugin.editLayerDef = ld
        plugin.editFid = fid
        plugin.editMode = true
        plugin.selectedLayerDef = ld
        plugin.selectedLayerName = ld.name
        plugin.currentFields = ld.fields
        // precompila il form: leggo dal GeoJSON del layer (che distingue i NULL veri, mentre la
        // feature viva converte NULL->0). La feature viva resta per il SALVATAGGIO.
        var d = {}
        var pfDiag = "fid=" + fid
        try {
            var feats = loadLayerFeaturesGeoJSON(ld.name)
            pfDiag += " geojsonN=" + feats.length
            // v37.1.99: capisci DOVE sta il fid nel GeoJSON (fid/id/properties)
            if (feats.length > 0) {
                var f0 = feats[0]
                try { pfDiag += " f0.id=" + f0.id } catch(e){}
                try {
                    var pk = []
                    for (var k0 in f0.properties) pk.push(k0)
                    pfDiag += " propKeys=" + pk.slice(0, 12).join(",")
                    // valori dei possibili campi id
                    pfDiag += " p.fid=" + f0.properties.fid + " p.OBJECTID=" + f0.properties.OBJECTID + " p.fid_1=" + f0.properties.fid_1
                } catch(e){}
            }
            var props = null
            var firstFids = ""
            for (var gi = 0; gi < feats.length; gi++) {
                var pr = feats[gi].properties || {}
                // v37.1.100: QField mette l'id reale in fid_1 (fid e' null nel GeoJSON)
                var pfid = (pr.fid_1 !== undefined && pr.fid_1 !== null) ? pr.fid_1
                           : ((pr.fid !== undefined && pr.fid !== null) ? pr.fid
                           : ((feats[gi].id !== undefined && feats[gi].id !== null) ? feats[gi].id
                           : ((pr.OBJECTID !== undefined) ? pr.OBJECTID : -1)))
                if (gi < 5) firstFids += pfid + ","
                if (pfid === fid || ("" + pfid) === ("" + fid)) { props = pr; break }
            }
            pfDiag += " primiFid=" + firstFids + " match=" + (props !== null)
            if (props) {
                for (var fi = 0; fi < ld.fields.length; fi++) {
                    var key = ld.fields[fi].key
                    var v = props[key]
                    if (v === undefined || v === null) continue
                    var vs = "" + v
                    if (vs === "" || vs === "null" || vs === "NULL") continue
                    d[key] = vs
                }
            }
        } catch(eG) { pfDiag += " EXC:" + eG }
        // v37.1.96: se il GeoJSON non ha trovato la feature, ripiega sulla feature VIVA
        // (valori garantiti; i NULL potrebbero apparire come 0, ma meglio che vuoto)
        if (Object.keys(d).length === 0) {
            pfDiag += " FALLBACK-viva"
            for (var fj = 0; fj < ld.fields.length; fj++) {
                var k2 = ld.fields[fj].key
                var v2 = null; try { v2 = live.attribute(k2) } catch(e) {}
                if (v2 === undefined || v2 === null) continue
                var vs2 = "" + v2
                if (vs2 === "" || vs2 === "null" || vs2 === "NULL") continue
                d[k2] = vs2
            }
        }
        plugin.editSaveDiag = "PREFILL " + pfDiag + " campi=" + Object.keys(d).length
        plugin.editPrefillDiag = "PREFILL " + pfDiag + " campi=" + Object.keys(d).length
        plugin.parsedData = d
        // v37.1.95: memorizza i valori iniziali, per salvare SOLO i campi che l'operatore cambia
        // (cosi' i campi NULL non toccati NON vengono riscritti come 0)
        var snap = {}
        for (var sk in d) snap[sk] = d[sk]
        plugin.editOriginalData = snap
        plugin.photo1Path = ""; plugin.photo2Path = ""
        try {
            if (ld.photoField) { var pv1 = live.attribute(ld.photoField); if (pv1) plugin.photo1Path = "" + pv1 }
            if (ld.photoField2) { var pv2 = live.attribute(ld.photoField2); if (pv2) plugin.photo2Path = "" + pv2 }
        } catch(ep) {}
        var nn = 0; for (var kk in d) if (d[kk] !== "") nn++
        plugin.okCount = nn
        try { fieldsModel.refresh() } catch(e2) {}
        overlay.visible = true
        Qt.inputMethod.hide()
        mainWindow.displayToast("✏️ Modifica " + ld.name + " (fid " + fid + ")")
    }

    // v37.1.80: cancella la vecchia feature col metodo NATIVO del featureModel.
    // Prova piu' firme e cattura cosa funziona.
    function deleteOldFeatureNative(layer, fid) {
        var diag = "delfid=" + fid
        var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
        var fm = drawer ? drawer.featureModel : null
        if (!fm) return "no featureModel"
        // v37.1.81: carica prima la vecchia feature nel model (currentLayer + feature reale),
        // poi cancella. deleteFeature(fid) tornava false perche' il model non aveva contesto.
        try { fm.currentLayer = layer } catch(eL) { diag += " setLayerEXC:" + eL }

        // ottieni la feature reale (per caricarla nel model prima di cancellare)
        var realFeat = null
        try {
            var it = LayerUtils.createFeatureIteratorFromExpression(layer, "\"fid\" = " + fid)
            if (it && typeof it.next === "function") { realFeat = it.next() }
            else if (it && typeof it.nextFeature === "function") {
                var tmp = FeatureUtils.createBlankFeature(layer.fields, layer)
                if (it.nextFeature(tmp)) realFeat = tmp
            }
        } catch(eIt) { diag += " itEXC:" + eIt }
        diag += " realFeat=" + (realFeat !== null && realFeat !== undefined)

        // Tentativo 1: carica la feature nel model e chiama deleteFeature()
        if (realFeat) {
            try {
                fm.feature = realFeat
                var r1 = fm.deleteFeature()
                if (r1 === true) return diag + " OK via feature+deleteFeature()"
                diag += " t1=" + r1
            } catch(e1) { diag += " t1EXC:" + e1 }
        }
        // Tentativo 2: deleteFeature(fid) di nuovo, ora che currentLayer e' impostato
        try {
            var r2 = fm.deleteFeature(fid)
            if (r2 === true) return diag + " OK via deleteFeature(fid)"
            diag += " t2=" + r2
        } catch(e2) { diag += " t2EXC:" + e2 }
        // Tentativo 3: seleziona la feature sul layer e usa LayerUtils.deleteFeature col progetto
        try {
            LayerUtils.selectFeaturesInLayer(layer, [fid], "select")
            var r3 = LayerUtils.deleteFeature(qgisProject, layer, fid)
            if (r3 === true) return diag + " OK via select+LayerUtils"
            diag += " t3=" + r3
        } catch(e3) { diag += " t3EXC:" + e3 }
        return diag + " TUTTI FALLITI"
    }

    // v37.1.62 (Step 2b): carica una feature esistente nel form per modificarla
    function loadFeatureForEdit(cand) {
        var ld = plugin.layerDefs[cand.layerDefIndex]
        var layer = null
        try { layer = qgisProject.mapLayersByName(ld.name)[0] } catch(e) {}

        // v37.1.92: ottieni la feature VIVA in modo SICURO. NON forzo focusedItem/toggleSelectedItem
        // (causavano crash nativo su model vuoto/indice non valido). Leggo solo se gia' disponibile.
        var live = null
        var sdiag = "fid=" + cand.fid
        // v37.1.102: prova a ottenere la feature VIVA via iteratore usando fid_1 (il campo GIUSTO;
        // prima usavo "fid" che e' null -> l'espressione non trovava nulla -> id interno nullo).
        try {
            var it = LayerUtils.createFeatureIteratorFromExpression(layer, "\"fid_1\" = " + cand.fid)
            var got = null
            if (it && typeof it.next === "function") got = it.next()
            else if (it && typeof it.nextFeature === "function") {
                var tmp = FeatureUtils.createBlankFeature(layer.fields, layer)
                if (it.nextFeature(tmp)) got = tmp
            }
            if (got) {
                var gid = -1; try { gid = got.id } catch(e){}
                sdiag += " itFid1Id=" + gid
                if (gid !== undefined && gid >= 0) live = got
            } else { sdiag += " itNoFeat" }
        } catch(eIt) { sdiag += " itEXC:" + eIt }
        // se l'iteratore non basta, prova la selezione del form (se gia' presente)
        if (!live) {
            try {
                var ff = iface.findItemByObjectName("featureForm")
                if (ff && ff.selection && ff.selection.focusedFeature) {
                    var cf = ff.selection.focusedFeature
                    var cfid = -1; try { cfid = cf.id } catch(e){}
                    sdiag += " curFocId=" + cfid
                    if (cfid !== undefined && cfid >= 0) live = cf
                }
            } catch(eFF) { sdiag += " ffEXC:" + eFF }
        }
        plugin.editSaveDiag = "loadEdit " + sdiag + " -> live=" + (live !== null)

        plugin.editMode = true
        plugin.editCand = cand
        plugin.editLayerDef = ld
        plugin.editFid = cand.fid
        plugin.editLayer = layer
        plugin.editLiveFeature = live
        plugin.editLiveLayer = layer
        plugin.selectedLayerDef = ld
        plugin.selectedLayerName = ld.name
        plugin.currentFields = ld.fields

        // v37.1.103: precompila SEMPRE dai valori GeoJSON (cand.vals, che saltano i NULL);
        // la feature viva serve solo per il SALVATAGGIO, non per leggere (converte NULL->0).
        var d = {}
        for (var k in cand.vals) d[k] = cand.vals[k]
        plugin.parsedData = d
        // v37.1.103: snapshot per salvare solo i campi cambiati
        var snapL = {}
        for (var skl in d) snapL[skl] = d[skl]
        plugin.editOriginalData = snapL

        // foto esistenti (dal GeoJSON cand.props)
        plugin.photo1Path = ""; plugin.photo2Path = ""
        try {
            if (ld.photoField && cand.props && cand.props[ld.photoField]) plugin.photo1Path = "" + cand.props[ld.photoField]
            if (ld.photoField2 && cand.props && cand.props[ld.photoField2]) plugin.photo2Path = "" + cand.props[ld.photoField2]
        } catch(ep) {}

        var nn = 0
        for (var kk in d) if (d[kk] !== "") nn++
        plugin.okCount = nn
        try { fieldsModel.refresh() } catch(e3) {}
        editListPopup.visible = false
        overlay.visible = true
        Qt.inputMethod.hide()
        mainWindow.displayToast("✏️ Modifica " + ld.name + " (fid " + cand.fid + (live ? "" : " ⚠") + ")")
    }

    // v37.0.22: snap via GeoJSON export (unico modo affidabile in QField QML)
    function ensureLayerFeaturesLoaded(layerName) {
        // Cache check
        var c = plugin.snapFeatureCache[layerName]
        if (c && (Date.now() - c.timestamp) < plugin.snapCacheTTLms) {
            return c.features
        }
        var L = null
        try { L = qgisProject.mapLayersByName(layerName)[0] } catch(e) {}
        if (!L) {
            plugin.snapFeatureCache[layerName] = { features: [], timestamp: Date.now() }
            return []
        }
        // Skip empty layers via extent check (saves I/O)
        try {
            var ext = L.extent()
            if (ext && (ext.width === 0 && ext.height === 0)) {
                plugin.snapFeatureCache[layerName] = { features: [], timestamp: Date.now() }
                return []
            }
        } catch(eX) {}

        var safeName = layerName.replace(/[^a-zA-Z0-9]/g, "_")
        var path = qgisProject.homePath + "/.snap_cache_" + safeName + ".geojson"
        var feats = []
        try {
            LayerUtils.saveVectorLayerAs(L, path, "GeoJSON")
            var content = "" + FileUtils.readFileContent(path)
            if (!content || content.length < 30) {
                plugin.snapFeatureCache[layerName] = { features: [], timestamp: Date.now() }
                return []
            }
            var data = JSON.parse(content)
            if (data && data.features) {
                for (var i = 0; i < data.features.length; i++) {
                    var f = data.features[i]
                    if (!f || !f.geometry) continue
                    var g = f.geometry
                    var fid = (f.properties && f.properties.OBJECTID) || i
                    if (g.type === "Point") {
                        feats.push({ x: g.coordinates[0], y: g.coordinates[1], fid: fid })
                    } else if (g.type === "MultiPoint") {
                        for (var mp = 0; mp < g.coordinates.length; mp++) {
                            feats.push({ x: g.coordinates[mp][0], y: g.coordinates[mp][1], fid: fid })
                        }
                    } else if (g.type === "LineString") {
                        for (var j = 0; j < g.coordinates.length; j++) {
                            feats.push({ x: g.coordinates[j][0], y: g.coordinates[j][1], fid: fid })
                        }
                    } else if (g.type === "MultiLineString") {
                        for (var k = 0; k < g.coordinates.length; k++) {
                            var line = g.coordinates[k]
                            if (!line) continue
                            for (var l = 0; l < line.length; l++) {
                                feats.push({ x: line[l][0], y: line[l][1], fid: fid })
                            }
                        }
                    } else if (g.type === "Polygon") {
                        for (var pl = 0; pl < g.coordinates.length; pl++) {
                            var ring = g.coordinates[pl]
                            if (!ring) continue
                            for (var pv = 0; pv < ring.length; pv++) {
                                feats.push({ x: ring[pv][0], y: ring[pv][1], fid: fid })
                            }
                        }
                    }
                }
            }
        } catch(eExp) {
            plugin.snapLastDiag += "[" + layerName + ":exportExc " + eExp + "]"
        }
        plugin.snapFeatureCache[layerName] = { features: feats, timestamp: Date.now() }
        return feats
    }

    function invalidateSnapCache(layerName) {
        if (layerName && plugin.snapFeatureCache[layerName]) {
            delete plugin.snapFeatureCache[layerName]
        }
    }

    function findNearestFeatureInLayer(targetLayer, x, y, maxDistMeters) {
        var lname = (targetLayer && targetLayer.name) ? targetLayer.name : "?"
        if (!targetLayer) { plugin.snapLastDiag += "[" + lname + ":noLayer] "; return null }

        var feats = ensureLayerFeaturesLoaded(lname)
        var best = null
        var bestDist = maxDistMeters + 0.001
        var nIn = 0
        for (var i = 0; i < feats.length; i++) {
            var f = feats[i]
            var dx = f.x - x
            var dy = f.y - y
            var dist = Math.sqrt(dx*dx + dy*dy)
            if (dist <= maxDistMeters) nIn++
            if (dist <= maxDistMeters && dist < bestDist) {
                bestDist = dist
                best = { x: f.x, y: f.y, dist: dist, fid: f.fid }
            }
        }
        plugin.snapLastDiag += "[" + lname + " loaded=" + feats.length + " inRange=" + nIn +
                               (best ? " HIT@" + (best.dist*100).toFixed(0) + "cm" : "") + "] "
        return best
    }

    function computeOriginalLineLength() {
        var total = 0
        for (var i = 1; i < plugin.lineVertices.length; i++) {
            var v0 = plugin.lineVertices[i-1]
            var v1 = plugin.lineVertices[i]
            var dx = v1.x - v0.x
            var dy = v1.y - v0.y
            total += Math.sqrt(dx*dx + dy*dy)
        }
        return total
    }

    function collectSnapCandidates() {
        var cands = []
        plugin.snapLastDiag = ""   // v37.0.13: reset diagnostica
        if (!plugin.snapEnabled) { plugin.snapLastDiag = "snapOFF"; return cands }
        var srcName = plugin.selectedLayerName
        var targets = plugin.snapMatrix[srcName] || []
        if (targets.length === 0) { plugin.snapLastDiag = "noTargets(" + srcName + ")"; return cands }
        var maxM = plugin.snapMaxCm / 100.0
        var def = plugin.selectedLayerDef
        plugin.snapLastDiag = "src=" + srcName + " max=" + plugin.snapMaxCm + "cm "

        if (def && def.geometryType === "line") {
            if (plugin.lineVertices.length < 2) return cands
            var first = plugin.lineVertices[0]
            var last = plugin.lineVertices[plugin.lineVertices.length - 1]
            for (var ti = 0; ti < targets.length; ti++) {
                var tn = targets[ti]
                var tl = null
                try { tl = qgisProject.mapLayersByName(tn)[0] } catch(eL) {}
                if (!tl) continue
                var nF = findNearestFeatureInLayer(tl, first.x, first.y, maxM)
                if (nF) {
                    cands.push({ which: "start", origX: first.x, origY: first.y,
                                 snapX: nF.x, snapY: nF.y, dist: nF.dist, targetLayer: tn })
                }
                var nL = findNearestFeatureInLayer(tl, last.x, last.y, maxM)
                if (nL) {
                    cands.push({ which: "end", origX: last.x, origY: last.y,
                                 snapX: nL.x, snapY: nL.y, dist: nL.dist, targetLayer: tn })
                }
            }
        } else {
            if (!positionSource || !positionSource.active) return cands
            var pos0 = positionSource.projectedPosition
            for (var ti2 = 0; ti2 < targets.length; ti2++) {
                var tn2 = targets[ti2]
                var tl2 = null
                try { tl2 = qgisProject.mapLayersByName(tn2)[0] } catch(eL2) {}
                if (!tl2) continue
                var nP = findNearestFeatureInLayer(tl2, pos0.x, pos0.y, maxM)
                if (nP) {
                    cands.push({ which: "point", origX: pos0.x, origY: pos0.y,
                                 snapX: nP.x, snapY: nP.y, dist: nP.dist, targetLayer: tn2 })
                }
            }
        }
        var byWhich = {}
        for (var c = 0; c < cands.length; c++) {
            var ck = cands[c].which
            if (!byWhich[ck] || cands[c].dist < byWhich[ck].dist) byWhich[ck] = cands[c]
        }
        var unique = []
        for (var kk in byWhich) unique.push(byWhich[kk])
        return unique
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        var def = plugin.selectedLayerDef
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }

        applyAutoFills()   // v37.1.44: es. Q.ta_Min_N = Num_Min1 se Stato=Realizzato
        var v = getConstraintViolations()
        if (v.missing.length > 0 || v.conflict.length > 0) {
            var msg = ""
            if (v.missing.length > 0) msg += "⛔ Obbligatori vuoti: " + v.missing.join(", ")
            if (v.conflict.length > 0) {
                if (msg !== "") msg += " | "
                msg += "⚠ Da svuotare: " + v.conflict.join(", ")
            }
            mainWindow.displayToast(msg)
            return
        }

        if (def && def.geometryType !== "line") {
            if (!positionSource || !positionSource.active) {
                mainWindow.displayToast("⚠ GPS non attivo!"); return
            }
        }

        // v37.0.10: lunghezza ORIGINALE pre-snap
        plugin.snapPendingResult = {}
        if (def && def.geometryType === "line" && plugin.lineVertices.length >= 2) {
            plugin.snapPendingResult["origLength"] = computeOriginalLineLength()
        }

        plugin.snapPendingCandidates = collectSnapCandidates()
        plugin.snapPendingIndex = 0
        // v37.0.14: dialog persistente con diag snap (toast spariva troppo veloce)
        try {
            // v37.0.25: dialog snap rimosso (rumoroso)
            plugin.diagLog = ""
        } catch(eD) {}
        if (plugin.snapPendingCandidates.length > 0) {
            showNextSnapPopup()
            return
        }
        commitSave()
    }

    function showNextSnapPopup() {
        if (plugin.snapPendingIndex >= plugin.snapPendingCandidates.length) {
            commitSave()
            return
        }
        var c = plugin.snapPendingCandidates[plugin.snapPendingIndex]
        var distCm = (c.dist * 100).toFixed(0)
        var whichLabel = ""
        if (c.which === "start") whichLabel = "vertice iniziale"
        else if (c.which === "end") whichLabel = "vertice finale"
        else whichLabel = "punto"
        snapPopupTitle.text = "🔗 Snap a " + c.targetLayer + "?"
        snapPopupBody.text = "Il " + whichLabel + " e a " + distCm + " cm da un elemento " +
                             c.targetLayer + ". Snappare?"
        plugin.lastSnapVoiceText = ""
        snapVoiceInput.text = ""
        // v37.0.41: signal PRIMA di visible
        broadcastEvent("SNAP_POPUP_READY")
        broadcastEvent("VOICE_INPUT_READY")
        snapPopup.visible = true
        snapFocusTimer.start()
    }

    function snapPopupAnswer(yes) {
        snapPopup.visible = false
        var c = plugin.snapPendingCandidates[plugin.snapPendingIndex]
        if (yes) {
            if (c.which === "point") {
                plugin.snapPendingResult["point"] = { x: c.snapX, y: c.snapY }
            } else if (c.which === "start") {
                plugin.lineVertices[0] = { x: c.snapX, y: c.snapY }
            } else if (c.which === "end") {
                plugin.lineVertices[plugin.lineVertices.length - 1] = { x: c.snapX, y: c.snapY }
            }
            mainWindow.displayToast("🔗 Snap applicato a " + c.targetLayer)
        }
        plugin.snapPendingIndex++
        showNextSnapPopup()
    }

    function commitSave() {
        // v37.1.66 (Step 2b): salvataggio MODIFICA su feature esistente
        if (plugin.editMode) {
            // valida i vincoli come per l'inserimento (obbligatori, foto, ecc.)
            applyAutoFills()
            var vE = getConstraintViolations()
            if (vE.missing.length > 0 || vE.conflict.length > 0) {
                var mE = ""
                if (vE.missing.length > 0) mE += "⛔ Obbligatori vuoti: " + vE.missing.join(", ")
                if (vE.conflict.length > 0) { if (mE !== "") mE += " | "; mE += "⚠ Da svuotare: " + vE.conflict.join(", ") }
                mainWindow.displayToast(mE)
                return
            }
            var okE = saveEditedFeature()
            // il salvataggio prosegue in autoSaveTimer (che cancella la vecchia e pulisce)
            return
        }
        var layer = findLayer(plugin.selectedLayerName)
        var def = plugin.selectedLayerDef
        try {
            var wkt
            var origLineLength = 0
            if (def && def.geometryType === "line") {
                if (plugin.lineVertices.length < 2) {
                    mainWindow.displayToast("⚠ Servono almeno 2 vertici per la tratta")
                    return
                }
                // v37.1.33: guardia anti-collasso. Se tutti i vertici
                // coincidono (stesso punto ripetuto), la tratta sarebbe una
                // linea di lunghezza zero -> invisibile a schermo. Meglio
                // avvisare e non salvare una geometria degenere.
                var distinctV = []
                for (var dv = 0; dv < plugin.lineVertices.length; dv++) {
                    var vv = plugin.lineVertices[dv]
                    var dup = false
                    for (var dq = 0; dq < distinctV.length; dq++) {
                        if (Math.abs(distinctV[dq].x - vv.x) < 0.05
                            && Math.abs(distinctV[dq].y - vv.y) < 0.05) { dup = true; break }
                    }
                    if (!dup) distinctV.push(vv)
                }
                if (distinctV.length < 2) {
                    mainWindow.displayToast("⚠ Tratta collassata: i vertici coincidono. Spostati e ricattura almeno 2 punti distinti.")
                    return
                }
                origLineLength = plugin.snapPendingResult["origLength"] || computeOriginalLineLength()
                wkt = buildLineWkt()
            } else {
                flushGpsSampling()   // v37.1.0: chiude la media se ancora attiva
                var pX, pY
                if (plugin.pendingValid) {
                    pX = plugin.pendingX; pY = plugin.pendingY
                } else {
                    var pos = positionSource.projectedPosition
                    pX = pos.x; pY = pos.y
                }
                if (plugin.snapPendingResult["point"]) {
                    pX = plugin.snapPendingResult["point"].x
                    pY = plugin.snapPendingResult["point"].y
                }
                wkt = "POINT(" + pX + " " + pY + ")"
            }

            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names

            // v37.1.49: in modalita' puntatore la lunghezza resta vuota (no GPS)
            if (def && def.geometryType === "line" && origLineLength > 0
                && plugin.positionMode !== "pointer") {
                for (var iL = 0; iL < plugin.currentFields.length; iL++) {
                    var fL = plugin.currentFields[iL]
                    if (fL.auto === "length" && (!d[fL.key] || d[fL.key] === "")) {
                        d[fL.key] = origLineLength.toFixed(2)
                        break
                    }
                }
            }

            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fdS = plugin.currentFields[i]
                // v37.1.9: i campi readOnly (es. Ultima_Tub) sono solo anteprima:
                // il valore salvato lo calcola QGIS col valore predefinito.
                if (fdS.readOnly === true) continue
                var val = d[fdS.key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(fdS.key)
                    if (idx2 >= 0) {
                        var storeVal = (fdS.valueMap && fdS.valueMap[val] !== undefined)
                                       ? fdS.valueMap[val] : val
                        feature.setAttribute(idx2, storeVal)
                    }
                }
            }
            if (plugin.photo1Path !== "") {
                var photoFieldName = (def && def.photoField) ? def.photoField : "Foto_1"
                var fi = fieldNames.indexOf(photoFieldName)
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            if (plugin.photo2Path !== "" && def && def.photoField2) {
                var fi2 = fieldNames.indexOf(def.photoField2)
                if (fi2 >= 0) feature.setAttribute(fi2, plugin.photo2Path)
            }

            // v37.1.33: timbra data/ora e modalita' di inserimento (se il layer
            // ha i campi data_ins / modo_ins). Sovrascrive i default di QGIS
            // cosi' un elemento inserito col plugin risulta sempre distinguibile
            // da uno inserito con lo strumento nativo di QField (che invece
            // eredita il default 'QField nativo' impostato nel progetto).
            var idxDataIns = fieldNames.indexOf("data_ins")
            if (idxDataIns >= 0) {
                var nowD = new Date()
                var dstr = Qt.formatDateTime(nowD, "yyyy-MM-dd HH:mm:ss")
                feature.setAttribute(idxDataIns, dstr)
            }
            var idxModoIns = fieldNames.indexOf("modo_ins")
            if (idxModoIns >= 0) {
                feature.setAttribute(idxModoIns, "Plugin Vocale GPS")
            }
            // v37.1.34: accuratezza orizzontale GPS (metri) al momento del
            // campionamento usato per salvare il punto/vertice. -1 = sconosciuta,
            // in tal caso si lascia il default di progetto (se presente).
            var idxAccIns = fieldNames.indexOf("acc_gps_m")
            if (idxAccIns >= 0) {
                // v37.1.37: scrittura in sordina, mai bloccante (nessun errore all'operatore)
                try {
                    var accVal = plugin.pendingAccuracyM
                    if (accVal < 0) accVal = readAccuracyM(null)
                    if (accVal >= 0) feature.setAttribute(idxAccIns, accVal)
                } catch(eAcc) {}
            }
            // v37.1.34: OPERATORE = nome registrato con la licenza del plugin
            // su questo tablet (licenseNome). Per l'inserimento nativo di
            // QField lo stesso valore va impostato una volta come variabile
            // globale @operatore in Impostazioni > Variabili di QField.
            var idxOperatore = fieldNames.indexOf("OPERATORE")
            if (idxOperatore >= 0 && plugin.licenseNome && plugin.licenseNome !== "") {
                feature.setAttribute(idxOperatore, plugin.licenseNome)
            }

            // v37.1.9: memorizza l'ultima tubazione inserita per popolare
            // l'anteprima "Ultima Tubazione" al prossimo inserimento.
            if (def && def.name === "TRATTE INTERRATE") {
                var tubTxt = formatTubazione(d)
                if (tubTxt !== "") {
                    saveLastTub(tubTxt)
                    saveLastTubValues(d)
                }
            }

            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            // v37.1.40: NON chiamare piu' applyGeometry(). Quel metodo applica la
            // posizione del MIRINO (centro mappa / GPS live) AL MOMENTO DEL COMMIT,
            // sovrascrivendo la geometria gia' costruita dalla mediana congelata al +.
            // Era la causa dei punti/pozzetti presi nella posizione di "completa"
            // invece che in quella del +. La feature ha gia' la geometria corretta
            // dal WKT (vale per punti E linee), quindi applyGeometry non serve.
            // v37.1.121 (Step 3g): sblocca readOnly PRIMA di drawer.state, non dopo -
            // era la causa di "feature addition disabled" (pluginDrawerOpen=true una
            // riga sotto arrivava un istante troppo tardi).
            plugin.applyNativeLayerEditState(true)
            drawer.state = "Add"
            plugin.pluginDrawerOpen = true   // v37.1.50: e' il plugin a usarlo -> non inibire
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }

    // ── v37.0.10: SNAP POPUP & SETTINGS UI ────────────────────
    Timer {
        id: snapFocusTimer
        interval: 100; repeat: false
        onTriggered: { Qt.inputMethod.hide() }
    }
    Timer {
        id: snapVoicePollTimer
        interval: 400; repeat: true; running: snapPopup.visible
        onTriggered: {
            if (snapVoiceInput.text === plugin.lastSnapVoiceText) return
            if (snapVoiceInput.text.length === 0) return
            plugin.lastSnapVoiceText = snapVoiceInput.text
            // v37.0.25: matching robusto con normalizzazione accenti
            var raw = ("" + snapVoiceInput.text).toLowerCase()
            raw = raw.replace(/[ìíî]/g, "i")
            raw = raw.replace(/[àáâ]/g, "a")
            raw = raw.replace(/[èéê]/g, "e")
            raw = raw.replace(/[òóô]/g, "o")
            raw = raw.replace(/[ùúû]/g, "u")
            raw = raw.replace(/[.,!?;:]/g, " ")
            var ws = raw.split(/\s+/)
            for (var i = 0; i < ws.length; i++) {
                var w = ws[i]
                if (w === "si" || w === "sii" || w === "ok" || w === "okay"
                    || w === "snap" || w === "conferma" || w === "confermo"
                    || w === "certo") {
                    snapPopupAnswer(true)
                    return
                }
                if (w === "no" || w === "ignora" || w === "salta"
                    || w === "nessuno" || w === "negativo") {
                    snapPopupAnswer(false)
                    return
                }
            }
        }
    }

    // v37.0.40: popup verifica giornaliera con posticipi
    Rectangle {
        id: revalidatePopup
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 11250; color: "#cc000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 460)
            height: revalCol.implicitHeight + 32
            color: "#ffffff"; radius: 12
            border.color: "#2980b9"; border.width: 2
            Column {
                id: revalCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 18
                spacing: 12
                Text {
                    width: parent.width
                    text: "✍ Verifica licenza"
                    color: "#2980b9"; font.pixelSize: 21; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: plugin.licenseBlockedOffline
                          ? "I posticipi sono esauriti. Per usare il plugin è necessario verificare la licenza online."
                          : "Sono passate più di 24 ore dall'ultima verifica della tua licenza. Vuoi verificarla adesso?"
                    color: "#1a1d27"; font.pixelSize: 13; wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: "Licenza: " + plugin.licenseNome +
                          (plugin.licenseScadenza ? "  |  Scad: " + plugin.licenseScadenza : "")
                    color: "#5a667a"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }
                Rectangle {
                    width: parent.width
                    height: revalErr.implicitHeight + 12
                    visible: plugin.licenseNetError !== ""
                    color: "#fff0f0"; radius: 6
                    border.color: "#e0b0b0"; border.width: 1
                    Text {
                        id: revalErr
                        anchors.fill: parent
                        anchors.margins: 6
                        text: "⚠ " + plugin.licenseNetError
                        color: "#c0392b"; font.pixelSize: 11; wrapMode: Text.WordWrap
                    }
                }
                Row {
                    width: parent.width
                    spacing: 8
                    // Annulla (chiude e torna alla mappa)
                    Rectangle {
                        width: (parent.width - 16) / 3; height: 48
                        color: revalCancelMA.pressed ? "#7b8794" : "#a8b0c8"
                        radius: 8
                        visible: !plugin.licenseBlockedOffline
                        Text { anchors.centerIn: parent
                               text: "Annulla"
                               color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: revalCancelMA; anchors.fill: parent
                            onClicked: {
                                revalidatePopup.visible = false
                                plugin.licenseNetError = ""
                            }
                        }
                    }
                    // Posticipa (max 2 volte)
                    Rectangle {
                        width: (parent.width - 16) / 3; height: 48
                        color: revalPostMA.pressed ? "#b8862e" : "#e8a23a"
                        radius: 8
                        visible: !plugin.licenseBlockedOffline && plugin.licensePostponeCount < 2
                        Text { anchors.centerIn: parent
                               text: "Posticipa
(" + (2 - plugin.licensePostponeCount) + " rim.)"
                               color: "white"; font.pixelSize: 12; font.bold: true
                               horizontalAlignment: Text.AlignHCenter }
                        MouseArea { id: revalPostMA; anchors.fill: parent
                            onClicked: {
                                plugin.savePostpone(6)  // posticipa di 6h
                                revalidatePopup.visible = false
                                plugin.licenseNetError = ""
                            }
                        }
                    }
                    // Verifica ora
                    Rectangle {
                        width: plugin.licenseBlockedOffline
                               ? parent.width
                               : (plugin.licensePostponeCount < 2
                                  ? (parent.width - 16) / 3
                                  : (parent.width - 8) / 2)
                        height: 48
                        color: plugin.licenseRevalidating ? "#a8b0c8"
                               : (revalNowMA.pressed ? "#1f6391" : "#2980b9")
                        radius: 8
                        enabled: !plugin.licenseRevalidating
                        Text { anchors.centerIn: parent
                               text: plugin.licenseRevalidating ? "Verifica..." : "✓ Verifica ora"
                               color: "white"; font.pixelSize: 13; font.bold: true }
                        MouseArea { id: revalNowMA; anchors.fill: parent
                            enabled: !plugin.licenseRevalidating
                            onClicked: {
                                plugin.licenseNetError = ""
                                plugin.licenseRevalidating = true
                                var url = plugin.licenseUrl +
                                          "?pin=" + encodeURIComponent(plugin.licensePin) +
                                          "&deviceId=" + encodeURIComponent(plugin.licenseDeviceId) +
                                          "&deviceName=" + encodeURIComponent(Qt.platform.os + "-daily") +
                                          "&action=check"
                                var xhr = new XMLHttpRequest()
                                xhr.open("GET", url)
                                xhr.onreadystatechange = function() {
                                    if (xhr.readyState !== XMLHttpRequest.DONE) return
                                    plugin.licenseRevalidating = false
                                    if (xhr.status !== 200) {
                                        plugin.licenseNetError = "Server non raggiungibile (status=" + xhr.status + ")"
                                        if (plugin.licensePostponeCount >= 2) plugin.licenseBlockedOffline = true
                                        return
                                    }
                                    var raw = "" + (xhr.responseText || "")
                                    var fb = raw.indexOf("{"), lb = raw.lastIndexOf("}")
                                    if (fb === -1 || lb === -1) {
                                        plugin.licenseNetError = "Risposta server non valida"
                                        if (plugin.licensePostponeCount >= 2) plugin.licenseBlockedOffline = true
                                        return
                                    }
                                    try {
                                        var resp = JSON.parse(raw.substring(fb, lb + 1))
                                        if (resp.ok === true) {
                                            saveSuccessfulCheck()
                                            if (resp.nome) plugin.licenseNome = "" + resp.nome
                                            if (resp.scadenza) plugin.licenseScadenza = "" + resp.scadenza
                                            revalidatePopup.visible = false
                                            try { mainWindow.displayToast("✓ Licenza verificata") } catch(eT) {}
                                        } else if (resp.code === "DISABLED" || resp.code === "NOT_FOUND" || resp.code === "WRONG_DEVICE") {
                                            clearStoredLicense()
                                            plugin.licenseDeactivationMsg = resp.msg || "Licenza disattivata"
                                            revalidatePopup.visible = false
                                            showLicenseScreen()
                                        } else {
                                            plugin.licenseNetError = (resp.msg || "Errore sconosciuto")
                                        }
                                    } catch(e) {
                                        plugin.licenseNetError = "Parse error"
                                        if (plugin.licensePostponeCount >= 2) plugin.licenseBlockedOffline = true
                                    }
                                }
                                xhr.onerror = function() {
                                    plugin.licenseRevalidating = false
                                    plugin.licenseNetError = "Rete non disponibile"
                                    if (plugin.licensePostponeCount >= 2) plugin.licenseBlockedOffline = true
                                }
                                try { xhr.send() } catch(eS) {
                                    plugin.licenseRevalidating = false
                                    plugin.licenseNetError = "Errore invio: " + eS
                                    if (plugin.licensePostponeCount >= 2) plugin.licenseBlockedOffline = true
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // v37.0.32: PIN activation popup
    Rectangle {
        id: pinPopup
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 11200; color: "#cc000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 480)
            height: pinCol.implicitHeight + 32
            color: "#ffffff"; radius: 12; border.color: "#2980b9"; border.width: 2
            Column {
                id: pinCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 18
                spacing: 14
                Text {
                    width: parent.width
                    text: "🔐 Attivazione plugin"
                    color: "#2980b9"; font.pixelSize: 22; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: "Inserisci il PIN di attivazione fornito dall'amministratore. " +
                          "Questo dispositivo verrà associato al tuo PIN."
                    color: "#1a1d27"; font.pixelSize: 13; wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                }
                Rectangle {
                    width: parent.width
                    height: deactivatedText.implicitHeight + 14
                    color: "#fff4e0"; radius: 6
                    border.color: "#e8a23a"; border.width: 1
                    visible: plugin.licenseDeactivationMsg !== ""
                    Text {
                        id: deactivatedText
                        anchors.fill: parent
                        anchors.margins: 7
                        text: "Avviso: " + plugin.licenseDeactivationMsg +
                              "\nContatta l\'amministratore per un nuovo PIN."
                        color: "#a85f00"; font.pixelSize: 12; font.bold: true
                        wrapMode: Text.WordWrap
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
                Rectangle {
                    width: parent.width; height: 56
                    color: "#f5f6f8"; radius: 8
                    border.color: pinInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: pinInput
                        anchors.fill: parent
                        anchors.leftMargin: 12; anchors.rightMargin: 12
                        color: "#1a1d27"; background: null
                        font.pixelSize: 22; font.bold: true
                        horizontalAlignment: TextInput.AlignHCenter
                        placeholderText: "PIN"
                        placeholderTextColor: "#a8b0c8"
                        inputMethodHints: Qt.ImhDigitsOnly
                    }
                }
                Rectangle {
                    width: parent.width
                    height: pinStatus.implicitHeight + 12
                    color: "#fff5f5"; radius: 6
                    border.color: "#e0d0d0"; border.width: 1
                    visible: pinStatus.text !== ""
                    Text {
                        id: pinStatus
                        anchors.fill: parent
                        anchors.margins: 6
                        text: ""
                        color: "#c0392b"; font.pixelSize: 11; wrapMode: Text.WordWrap
                    }
                }
                Row {
                    width: parent.width
                    spacing: 8
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 52
                        color: pinBackMA.pressed ? "#7b8794" : "#a8b0c8"
                        radius: 8
                        Text { anchors.centerIn: parent
                               text: "← Indietro"
                               color: "white"; font.pixelSize: 15; font.bold: true }
                        MouseArea { id: pinBackMA; anchors.fill: parent
                            onClicked: {
                                pinPopup.visible = false
                                pinInput.text = ""
                                pinStatus.text = ""
                            }
                        }
                    }
                    Rectangle {
                        width: (parent.width - 8) / 2; height: 52
                        color: plugin.licenseInProgress ? "#a8b0c8" :
                               (pinSubmitMA.pressed ? "#1f6391" : "#2980b9")
                        radius: 8
                        enabled: !plugin.licenseInProgress
                        Text { anchors.centerIn: parent
                               text: plugin.licenseInProgress ? "Verifica..." : "✓ Attiva"
                               color: "white"; font.pixelSize: 15; font.bold: true }
                        MouseArea { id: pinSubmitMA; anchors.fill: parent
                            enabled: !plugin.licenseInProgress
                            onClicked: {
                                var pin = pinInput.text.trim()
                                if (pin.length < 2) {
                                    pinStatus.text = "Inserisci un PIN valido"
                                    return
                                }
                                pinStatus.text = ""
                                verifyLicense(pin, function(ok, nome, msg) {
                                    if (ok) {
                                        pinPopup.visible = false
                                        pinInput.text = ""
                                        plugin.licenseDeactivationMsg = ""
                                        var pathInfo = plugin.licenseLastWrittenPath
                                                ? "\nSalvato in: " + plugin.licenseLastWrittenPath.split("/").pop()
                                                : ""
                                        var errInfo = plugin.licenseLastError
                                                ? "\n⚠ persist err: " + plugin.licenseLastError.substring(0,80)
                                                : ""
                                        mainWindow.displayToast("✓ Attivato " + nome + pathInfo + errInfo)
                                    } else {
                                        pinStatus.text = "❌ " + msg
                                    }
                                })
                            }
                        }
                    }
                }
                Text {
                    width: parent.width
                    text: "Device: " + plugin.licenseDeviceId
                    color: "#a8b0c8"; font.pixelSize: 9
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    visible: plugin.licenseLastWrittenPath !== ""
                    width: parent.width
                    text: "Path: " + plugin.licenseLastWrittenPath
                    color: "#a8b0c8"; font.pixelSize: 8
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WrapAnywhere
                }
                Text {
                    visible: plugin.licenseLastError !== ""
                    width: parent.width
                    text: "Errors: " + plugin.licenseLastError
                    color: "#c0392b"; font.pixelSize: 9
                    horizontalAlignment: Text.AlignLeft
                    wrapMode: Text.WrapAnywhere
                }
            }
        }
    }

    // v37.0.26: GPS accuracy warning popup
    Rectangle {
        id: gpsWarnPopup
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10800; color: "#aa000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 520)
            height: gpsCol.implicitHeight + 32
            color: "#fffbf0"; radius: 12; border.color: "#f39c12"; border.width: 2
            Column {
                id: gpsCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 14
                Text {
                    width: parent.width
                    text: "⚠ Allarme GPS"
                    color: "#e67e22"; font.pixelSize: 20; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    id: gpsWarnText
                    width: parent.width
                    color: "#1a1d27"; font.pixelSize: 14
                    wrapMode: Text.WordWrap
                }
                Rectangle {
                    width: parent.width; height: 52
                    color: gpsOkMA.pressed ? "#a93226" : "#c0392b"
                    radius: 8
                    Text { anchors.centerIn: parent; text: "OK ho capito"
                           color: "white"; font.pixelSize: 16; font.bold: true }
                    MouseArea { id: gpsOkMA; anchors.fill: parent
                        onClicked: {
                            gpsWarnPopup.visible = false
                            closeAll()
                        }
                    }
                }
            }
        }
    }

    // v37.1.119 (Step 3e): popup modale del blocco nativo (inserimento/attributi/
    // geometria) - sostituisce i toast, facili da non notare, con qualcosa che
    // l'operatore deve chiudere esplicitamente.
    Rectangle {
        id: nativeBlockedPopup
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10900; color: "#aa000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 520)
            height: nativeBlockedCol.implicitHeight + 32
            color: "#fffbf0"; radius: 12; border.color: "#c0392b"; border.width: 2
            Column {
                id: nativeBlockedCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 14
                Text {
                    width: parent.width
                    text: "✋ Funzione nativa disabilitata"
                    color: "#c0392b"; font.pixelSize: 20; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: plugin.nativeBlockedMsg
                    color: "#1a1d27"; font.pixelSize: 14
                    wrapMode: Text.WordWrap
                }
                Rectangle {
                    width: parent.width; height: 52
                    color: nativeBlockedOkMA.pressed ? "#a93226" : "#c0392b"
                    radius: 8
                    Text { anchors.centerIn: parent; text: "OK ho capito"
                           color: "white"; font.pixelSize: 16; font.bold: true }
                    MouseArea { id: nativeBlockedOkMA; anchors.fill: parent
                        onClicked: nativeBlockedPopup.visible = false
                    }
                }
            }
        }
    }

    // v37.0.28: modal di attesa per inserimento manuale GPS bad
    Rectangle {
        id: gpsWaitModal
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10700; color: "#88000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 520)
            height: gpsWaitCol.implicitHeight + 32
            color: "#fffbf0"; radius: 12; border.color: "#27ae60"; border.width: 2
            Column {
                id: gpsWaitCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 14
                Text {
                    width: parent.width
                    text: "📍 Inserimento manuale"
                    color: "#27ae60"; font.pixelSize: 20; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    id: gpsWaitLayerText
                    width: parent.width
                    text: ""
                    color: "#1a1d27"; font.pixelSize: 14; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    width: parent.width
                    text: "1) Disegna ora il punto/linea con il + di QField (toolbar in basso).\n2) Tocca OK sulla popup geometria di QField.\n3) Tocca CONTINUA qui sotto per inserire gli attributi mancanti."
                    color: "#1a1d27"; font.pixelSize: 13; wrapMode: Text.WordWrap
                }
                Rectangle {
                    width: parent.width; height: 52
                    color: gpsContMA.pressed ? "#178a3e" : "#27ae60"
                    radius: 8
                    Text { anchors.centerIn: parent; text: "✅ CONTINUA"
                           color: "white"; font.pixelSize: 17; font.bold: true }
                    MouseArea { id: gpsContMA; anchors.fill: parent
                        onClicked: {
                            gpsWaitModal.visible = false
                            // v37.0.30: il preset e' gia' stato applicato; apriamo il form
                            // L'utente avra' gia' disegnato la geometria col + nativo di QField
                            // e il QField avra' aperto il SUO form. Il nostro form serve come
                            // editing supplementare. Salviamo via plugin con GPS corrente.
                            var ld = plugin.selectedLayerDef
                            if (!ld) { closeAll(); return }
                            // re-capture GPS (potrebbe essere migliorato dopo movimento)
                            capturePendingPosition()
                            if (ld.geometryType === "line") {
                                // v37.1.35: vertice 1 con media, non campione grezzo
                                plugin.lineMode = true
                                plugin.lineVertices = []
                                plugin.pendingLineFirstVertex = true
                                startFirstVertexCapture()
                            } else {
                                overlay.visible = true
                                focusTimer.start()
                                broadcastEvent("FORM_READY")
                                emitVoiceReady()
                            }
                        }
                    }
                }
                Rectangle {
                    width: parent.width; height: 36
                    color: gpsAbMA.pressed ? "#7b8794" : "#a8b0c8"
                    radius: 6
                    Text { anchors.centerIn: parent; text: "Annulla"
                           color: "white"; font.pixelSize: 13 }
                    MouseArea { id: gpsAbMA; anchors.fill: parent
                        onClicked: { gpsWaitModal.visible = false; closeAll() }
                    }
                }
            }
        }
    }

    Rectangle {
        id: snapPopup
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10500; color: "#88000000"
        MouseArea { anchors.fill: parent }
        Rectangle {
            id: snapInner
            property var _initPos: plugin.loadWinPos("snap",
                                       Math.max(0, (snapPopup.width - width) / 2),
                                       Math.max(0, (snapPopup.height - height) / 2))
            x: _initPos.x
            y: _initPos.y
            width: Math.min(parent.width * 0.88, 460)
            height: snapCol.implicitHeight + 32 + 28
            color: "#f5f6f8"; radius: 12

            Loader {
                z: 100
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                sourceComponent: dragHandleComp
                onLoaded: { item.target = snapInner; item.winId = "snap" }
            }
            border.color: "#27ae60"; border.width: 2
            Column {
                id: snapCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top
                anchors.topMargin: 38
                anchors.leftMargin: 16; anchors.rightMargin: 16
                spacing: 12
                Text {
                    id: snapPopupTitle
                    width: parent.width
                    text: "🔗 Snap?"
                    color: "#27ae60"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }
                Text {
                    id: snapPopupBody
                    width: parent.width
                    text: ""
                    color: "#1a1d27"; font.pixelSize: 14
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                }
                Rectangle {
                    visible: false   // v37.1.41: barra voce nascosta (risposta a tap)
                    width: parent.width; height: 40
                    color: "#ffffff"; radius: 8
                    border.color: snapVoiceInput.activeFocus ? "#27ae60" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: snapVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#1a1d27"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 Di' sì o no..."
                        placeholderTextColor: "#5a6378"
                    }
                }
                RowLayout {
                    width: parent.width; spacing: 12
                    Rectangle {
                        Layout.fillWidth: true; height: 48
                        color: snapYesMA.pressed ? "#229954" : "#27ae60"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "✅ Sì"; color: "white"
                               font.pixelSize: 18; font.bold: true }
                        MouseArea { id: snapYesMA; anchors.fill: parent
                                    onClicked: snapPopupAnswer(true) }
                    }
                    Rectangle {
                        Layout.fillWidth: true; height: 48
                        color: snapNoMA.pressed ? "#c0392b" : "#e74c3c"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "❌ No"; color: "white"
                               font.pixelSize: 18; font.bold: true }
                        MouseArea { id: snapNoMA; anchors.fill: parent
                                    onClicked: snapPopupAnswer(false) }
                    }
                }
            }
        }
    }

    Rectangle {
        id: settingsPanel
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10600; color: "#88000000"
        MouseArea { anchors.fill: parent; onClicked: settingsPanel.visible = false }
        Rectangle {
            id: settingsInner
            property var _initPos: plugin.loadWinPos("settings",
                                       Math.max(0, (settingsPanel.width - width) / 2),
                                       Math.max(0, (settingsPanel.height - height) / 2))
            x: _initPos.x
            y: _initPos.y
            width: Math.min(parent.width * 0.92, 520)
            height: Math.min(parent.height * 0.85, settingsCol.implicitHeight + 40 + 28)
            color: "#f5f6f8"; radius: 12
            MouseArea { anchors.fill: parent }
            Loader {
                z: 100
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                sourceComponent: dragHandleComp
                onLoaded: { item.target = settingsInner; item.winId = "settings" }
            }
            Flickable {
                anchors.fill: parent
                anchors.margins: 16
                anchors.topMargin: 38
                contentHeight: settingsCol.implicitHeight
                clip: true
                Column {
                    id: settingsCol
                    width: parent.width
                    spacing: 14
                    Text {
                        width: parent.width
                        text: "⚙ Impostazioni Snap"
                        color: "#2980b9"; font.pixelSize: 20; font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                    }
                    RowLayout {
                        width: parent.width
                        Text { text: "Snap attivo"; color: "#1a1d27"; font.pixelSize: 15
                               Layout.fillWidth: true }
                        Switch {
                            id: snapEnabledSwitch
                            checked: plugin.snapEnabled
                            onCheckedChanged: plugin.snapEnabled = checked
                        }
                    }
                    Text {
                        id: snapDistLabel
                        width: parent.width
                        text: "Distanza max snap: " + plugin.snapMaxCm + " cm"
                        color: "#1a1d27"; font.pixelSize: 14
                    }
                    Slider {
                        id: snapDistSlider
                        width: parent.width
                        from: 5; to: 200; stepSize: 1
                        value: plugin.snapMaxCm
                        onValueChanged: {
                            plugin.snapMaxCm = Math.round(value)
                            snapDistLabel.text = "Distanza max snap: " + plugin.snapMaxCm + " cm"
                        }
                    }
                    Text {
                        width: parent.width
                        text: "Layer sorgente → target di snap"
                        color: "#2980b9"; font.pixelSize: 15; font.bold: true
                    }
                    Repeater {
                        id: snapMatrixRepeater
                        model: plugin.allLayerNames
                        delegate: Rectangle {
                            width: settingsCol.width
                            height: 50
                            color: "#ffffff"; radius: 6
                            border.color: "#c0c5d0"; border.width: 1
                            Column {
                                anchors.fill: parent
                                anchors.margins: 8
                                spacing: 2
                                Text {
                                    text: modelData
                                    color: "#1a1d27"; font.pixelSize: 14; font.bold: true
                                }
                                Text {
                                    text: "Snap su: " + ((plugin.snapMatrix[modelData] || []).join(", ") || "(nessuno)")
                                    color: "#5a6378"; font.pixelSize: 11
                                    width: parent.width
                                    elide: Text.ElideRight
                                }
                            }
                        }
                    }
                    // v37.0.31: soglia accuratezza GPS configurabile
                    Text {
                        width: parent.width
                        text: "🛰 Soglia accuratezza GPS (cm)"
                        color: "#2980b9"; font.pixelSize: 15; font.bold: true
                    }
                    Text {
                        width: parent.width
                        text: "Sopra questa soglia il plugin si blocca. Default 50 cm. Usa il + nativo di QField per inserimenti con GPS poco preciso."
                        color: "#5a6378"; font.pixelSize: 11; wrapMode: Text.WordWrap
                    }
                    Rectangle {
                        width: parent.width; height: 48
                        color: "#ffffff"; radius: 8
                        border.color: gpsThreshInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                        border.width: 2
                        Row {
                            anchors.fill: parent
                            anchors.leftMargin: 10; anchors.rightMargin: 10
                            spacing: 8
                            TextField {
                                id: gpsThreshInput
                                width: parent.width - 80
                                anchors.verticalCenter: parent.verticalCenter
                                color: "#1a1d27"; background: null
                                font.pixelSize: 15
                                inputMethodHints: Qt.ImhDigitsOnly
                                text: "" + plugin.gpsAccuracyThresholdCm
                                onEditingFinished: {
                                    plugin.saveGpsThreshold(text)
                                    text = "" + plugin.gpsAccuracyThresholdCm
                                }
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: "cm"
                                color: "#5a6378"; font.pixelSize: 14
                            }
                        }
                    }
                    // v37.1.38: soglia deriva movimento configurabile
                    Text {
                        width: parent.width
                        text: "🚶 Soglia deriva movimento (cm)"
                        color: "#2980b9"; font.pixelSize: 15; font.bold: true
                    }
                    Text {
                        width: parent.width
                        text: "Se durante i 2s di rilievo l'operatore si sposta oltre questa distanza, il plugin congela il punto usando solo i campioni da fermo. Default 25 cm."
                        color: "#5a6378"; font.pixelSize: 11; wrapMode: Text.WordWrap
                    }
                    Rectangle {
                        width: parent.width; height: 48
                        color: "#ffffff"; radius: 8
                        border.color: gpsDriftInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                        border.width: 2
                        Row {
                            anchors.fill: parent
                            anchors.leftMargin: 10; anchors.rightMargin: 10
                            spacing: 8
                            TextField {
                                id: gpsDriftInput
                                width: parent.width - 80
                                anchors.verticalCenter: parent.verticalCenter
                                color: "#1a1d27"; background: null
                                font.pixelSize: 15
                                inputMethodHints: Qt.ImhDigitsOnly
                                text: "" + plugin.gpsDriftGuardCm
                                onEditingFinished: {
                                    plugin.saveGpsDrift(text)
                                    text = "" + plugin.gpsDriftGuardCm
                                }
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: "cm"
                                color: "#5a6378"; font.pixelSize: 14
                            }
                        }
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: diagSnapMA.pressed ? "#a04000" : "#d35400"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "🧪 Probe Gatherer API"; color: "white"
                               font.pixelSize: 15; font.bold: true }
                        MouseArea { id: diagSnapMA; anchors.fill: parent
                                    onClicked: { settingsPanel.visible = false; probeGathererAPI() } }
                    }
                    Text {
                        width: parent.width
                        text: "🚧 Indagine blocco modifica nativa (Step 3b)"
                        color: "#2980b9"; font.pixelSize: 15; font.bold: true
                    }
                    Text {
                        width: parent.width
                        text: "L'inserimento nativo e' bloccato. Modifica attributi/geometria nativa NON ancora bloccata: usa questi due pulsanti per capire come, senza indovinare."
                        color: "#5a6378"; font.pixelSize: 11; wrapMode: Text.WordWrap
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: nativeStateLogMA.pressed ? "#1f6391" : "#2980b9"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "📋 Log stati nativi"; color: "white"
                               font.pixelSize: 15; font.bold: true }
                        MouseArea { id: nativeStateLogMA; anchors.fill: parent
                                    onClicked: { settingsPanel.visible = false; showNativeStateLog() } }
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: nativeEditProbeMA.pressed ? "#a04000" : "#d35400"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "🧪 Probe modifica nativa"; color: "white"
                               font.pixelSize: 15; font.bold: true }
                        MouseArea { id: nativeEditProbeMA; anchors.fill: parent
                                    onClicked: { settingsPanel.visible = false; probeNativeEditObjects() } }
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: layerEditProbeMA.pressed ? "#a04000" : "#d35400"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "🧪 Probe editing layer (matita)"; color: "white"
                               font.pixelSize: 15; font.bold: true }
                        MouseArea { id: layerEditProbeMA; anchors.fill: parent
                                    onClicked: { settingsPanel.visible = false; probeLayerEditingAPI() } }
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: readOnlyToggleMA.pressed ? "#8e0000" : "#c0392b"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "🧪 TEST: inverti readOnly layer attivo"; color: "white"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea { id: readOnlyToggleMA; anchors.fill: parent
                                    onClicked: { settingsPanel.visible = false; toggleActiveLayerReadOnly() } }
                    }
                    Rectangle {
                        width: parent.width; height: 44
                        color: closeSettingsMA.pressed ? "#1f6391" : "#2980b9"
                        radius: 8
                        Text { anchors.centerIn: parent; text: "Chiudi"; color: "white"
                               font.pixelSize: 16; font.bold: true }
                        MouseArea { id: closeSettingsMA; anchors.fill: parent
                                    onClicked: settingsPanel.visible = false }
                    }
                }
            }
        }
    }
}
