import QtQuick 2.14
import org.qfield 1.0

Item {
    Component.onCompleted: {
        iface.mainWindow().displayToast("PTE OK")
    }
}
