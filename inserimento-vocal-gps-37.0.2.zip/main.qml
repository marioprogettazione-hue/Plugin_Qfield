import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null
    property var selectedLayerDef: null

    property int okCount: 0
    property var parsedData: ({})

    // Stato linea
    property bool lineMode: false
    property var lineVertices: []
    property real pendingX: 0
    property real pendingY: 0
    property bool pendingValid: false

    // Auto-cattura
    property int autoCaptureMs: 5000

    // Voice state tracking
    property string lastParsedText: ""
    property string lastLayerVoiceText: ""
    property string lastVertexVoiceText: ""
    property string lastRadialVoiceText: ""
    property string photo1Path: ""
    property string photo2Path: ""
    property int photoSlot: 1  // 1 -> Foto_1, 2 -> Foto_2; alterna ad ogni scatto

    // Radial menu state
    property var currentPresets: []

    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true,
            voiceKeywords: ["pte", "p t e", "p.t.e", "punto terminazione"],
            fields: [
                { key: "TILABEL", label: "Quartina", alias: "Quartina", type: "text",
                  required: true, numericCombine: true,
                  voiceKeys: ["quartina", "quartine", "label", "nome", "naming", "neming", "etichetta", "numero"] },
                { key: "ARMADIO", label: "Armadio", alias: "Armadio", type: "text",
                  required: true, voiceKeys: ["armadio"] },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  required: true,
                  options: ["PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"],
                  voiceKeys: ["tipologia", "tipo", "interno", "muro esterno", "palifica", "sotterraneo", "colonnina"] },
                { key: "Posizione", label: "Ubicazione", alias: "Ubicazione", type: "picker",
                  required: true,
                  options: ["Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Muro Esterno","Palo","Pontile","Pozzetto",
                           "Seminterrato","Sottoscala"],
                  voiceKeys: ["ubicazione", "posizione", "androne", "centralino", "cortile", "divisorio",
                              "incassato", "intercapedine", "garage", "ingresso", "marciapiede",
                              "palo", "pontile", "pozzetto", "seminterrato", "sottoscala"] },
                { key: "Tipo_T", label: "Modello", alias: "Modello", type: "picker",
                  options: ["Terminale","Transito"],
                  voiceKeys: ["modello", "model", "terminale", "transito"] },
                { key: "COLON", label: "Colonnina Nuova?", alias: "Colonnina Nuova?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["colonnina nuova", "colonnina"],
                  requiredWhen: { field: "TIPOLOGIA", values: ["PTE Colonnina"] },
                  nullWhen: { field: "TIPOLOGIA", notValues: ["PTE Colonnina"] }, requireTipologia: "PTE Colonnina" },
                { key: "BASAM", label: "Basamento nuovo?", alias: "Basamento nuovo?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["basamento", "basam"],
                  requiredWhen: { field: "TIPOLOGIA", values: ["PTE Colonnina"] },
                  nullWhen: { field: "TIPOLOGIA", notValues: ["PTE Colonnina"] }, requireTipologia: "PTE Colonnina" },
                { key: "CAVO_AGG", label: "Presenza cavo spillato?", alias: "Presenza cavo spillato?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["cavo spillato", "spillato", "cavo aggiunto", "cavo agg"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Esistente","Realizzato","NON Realizzato","Progettato"],
                  required: true,
                  voiceKeys: ["stato", "esistente", "realizzato", "non realizzato", "progettato"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota", "annotazione"] },
                { key: "NOTE_ANO", label: "Note Anomalia", alias: "Note Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie", "note anomalia"] }
            ],
            presets: [
                { id: 1,  image: "images/PTE/EST_Progettato.png",       label: "Muro Est progett",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Progettato", Posizione:"Muro Esterno" } },
                { id: 2,  image: "images/PTE/EST_Realizzato.png",       label: "Muro Est realizz",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Realizzato", Posizione:"Muro Esterno" } },
                { id: 3,  image: "images/PTE/EST_Esistente.png",        label: "Muro Est esist",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Esistente",  Posizione:"Muro Esterno" } },
                { id: 4,  image: "images/PTE/EST_NON Realizzato.png",   label: "Muro Est NON real",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"NON Realizzato", Posizione:"Muro Esterno" } },
                { id: 5,  image: "images/PTE/INT_Progettato.png",       label: "Interno progett",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Progettato" } },
                { id: 6,  image: "images/PTE/INT_Realizzato.png",       label: "Interno realizz",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Realizzato" } },
                { id: 7,  image: "images/PTE/INT_Esistente.png",        label: "Interno esist",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Esistente" } },
                { id: 8,  image: "images/PTE/INT_NON Realizzato.png",   label: "Interno NON real",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"NON Realizzato" } },
                { id: 9,  image: "images/PTE/SOT_Progettato.png",       label: "Sotter progett",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Progettato", Posizione:"Pozzetto" } },
                { id: 10, image: "images/PTE/SOT_Realizzato.png",       label: "Sotter realizz",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Realizzato", Posizione:"Pozzetto" } },
                { id: 11, image: "images/PTE/SOT_Esistente.png",        label: "Sotter esist",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Esistente", Posizione:"Pozzetto" } },
                { id: 12, image: "images/PTE/SOT_NON Realizzato.png",   label: "Sotter NON real",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"NON Realizzato", Posizione:"Pozzetto" } },
                { id: 13, image: "images/PTE/COL_Progettato.png",       label: "Colonn progett",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Progettato", Posizione:"Colonnina" } },
                { id: 14, image: "images/PTE/COL_Realizzato.png",       label: "Colonn realizz",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Realizzato", Posizione:"Colonnina" } },
                { id: 15, image: "images/PTE/COL_Esistente.png",        label: "Colonn esist",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Esistente", Posizione:"Colonnina" } },
                { id: 16, image: "images/PTE/COL_NON Realizzato.png",   label: "Colonn NON real",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"NON Realizzato", Posizione:"Colonnina" } }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true, photo2Required: true,
            voiceKeywords: ["armadio", "armadi"],
            fields: [
                { key: "ARMADIO", label: "Numero Armadio", alias: "Numero Armadio", type: "text",
                  required: true, voiceKeys: ["numero armadio", "armadio", "numero"] },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Armadio Ottico Esterno","Armadio Ottico Small"],
                  required: true, voiceKeys: ["tipologia", "tipo", "esterno", "small", "ottico"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","NON Realizzato","Esistente"],
                  required: true, voiceKeys: ["stato", "realizzato", "non realizzato", "esistente"] },
                { key: "Posizione", label: "Posizione", alias: "Posizione", type: "picker",
                  options: ["MURO ESTERNO","MURO INTERNO","INCASSATO","MARCIAPIEDE","CORTILE"],
                  voiceKeys: ["posizione", "muro esterno", "muro interno", "incassato", "marciapiede", "cortile"],
                  requiredWhen: { field: "STATO", notValues: ["NON Realizzato"] },
                  nullWhen: { field: "STATO", values: ["NON Realizzato"] } },
                { key: "N_cavi", label: "Cavi attestati (compresa primaria)", alias: "Cavi attestati (compresa primaria)", type: "text",
                  voiceKeys: ["cavi attestati", "cavi", "n cavi", "numero cavi", "attestati"],
                  requiredWhen: { field: "STATO", notValues: ["NON Realizzato"] },
                  nullWhen: { field: "STATO", values: ["NON Realizzato"] } },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalie", alias: "Anomalie", type: "text",
                  voiceKeys: ["anomalie", "anomalia"] }
            ],
            presets: [
                { id: 1, image: "images/ARMADIO/LARGE_Realizzato.png",       label: "Esterno realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Realizzato" } },
                { id: 2, image: "images/ARMADIO/LARGE_NON Realizzato.png",   label: "Esterno NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"NON Realizzato" } },
                { id: 3, image: "images/ARMADIO/LARGE_Esistente.png",        label: "Esterno esist",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Esistente" } },
                { id: 4, image: "images/ARMADIO/Small_Realizzato.png",       label: "Small realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Realizzato" } },
                { id: 5, image: "images/ARMADIO/Small_NON Realizzato.png",   label: "Small NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"NON Realizzato" } },
                { id: 6, image: "images/ARMADIO/Small_Esistente.png",        label: "Small esist",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Esistente" } }
            ]
        },
        {
            name: "POZZETTI", label: "Pozzetti", icon: "⬛",
            geometryType: "point",
            photoField: "Foto_1", photoField2: "Foto_2",
            photo1Required: true,
            voiceKeywords: ["pozzetto", "pozzetti"],
            fields: [
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["125x80","90x70","76x40","40x15","Altro"],
                  required: true, voiceKeys: ["tipologia", "tipo", "125", "90", "76", "40", "altro"] },
                { key: "STATO_1", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente","Progettato"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente", "progettato"] },
                { key: "PROPRIETA", label: "Proprietario", alias: "Proprietario", type: "picker",
                  options: ["FiberCop","TIM","Comune","Enel","Privato","Fastweb","FlashFiber","Ultranet"],
                  required: true, voiceKeys: ["proprietario", "proprieta", "fibercop", "tim", "comune", "enel", "privato", "fastweb", "flashfiber", "ultranet"] },
                { key: "ANELLI", label: "Presenza Anelli?", alias: "Presenza Anelli?", type: "picker", options: ["Si","No"],
                  requiredWhen: { field: "STATO_1", values: ["Realizzato"] },
                  voiceKeys: ["anelli", "presenza anelli"] },
                { key: "Num_Anelli", label: "Numero anelli", alias: "Numero anelli", type: "picker", options: ["1","2","3"],
                  requiredWhen: { field: "ANELLI", values: ["Si"] },
                  nullWhen: { field: "ANELLI", values: ["No"] },
                  voiceKeys: ["numero anelli", "num anelli"] },
                { key: "1_Anello", label: "1 Anello", alias: "1 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "ANELLI", values: ["Si"] },
                  nullWhen: { field: "ANELLI", values: ["No"] },
                  voiceKeys: ["primo anello", "uno anello", "anello 1", "anello uno"] },
                { key: "2_Anello", label: "2 Anello", alias: "2 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "Num_Anelli", values: ["2","3"] },
                  nullWhen: { field: "Num_Anelli", values: ["1"] },
                  voiceKeys: ["secondo anello", "due anello", "anello 2", "anello due"] },
                { key: "3_Anello", label: "3 Anello", alias: "3 Anello", type: "picker", options: ["10","20","40"],
                  requiredWhen: { field: "Num_Anelli", values: ["3"] },
                  nullWhen: { field: "Num_Anelli", values: ["1","2"] },
                  voiceKeys: ["terzo anello", "tre anello", "anello 3", "anello tre"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Note Anomalia", alias: "Note Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1,  image: "images/POZZETTI/40x15_PROG.png",  label: "40x15 progett",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Progettato" } },
                { id: 2,  image: "images/POZZETTI/40x15_NEW.png",   label: "40x15 realizz",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 3,  image: "images/POZZETTI/40x15_ESIST.png", label: "40x15 esist",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 4,  image: "images/POZZETTI/76x4_PROG.png",   label: "76x40 progett",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Progettato" } },
                { id: 5,  image: "images/POZZETTI/76x40_NEW.png",   label: "76x40 realizz",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 6,  image: "images/POZZETTI/76x40_ESIST.png", label: "76x40 esist",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 7,  image: "images/POZZETTI/90x70_PROG.png",  label: "90x70 progett",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Progettato" } },
                { id: 8,  image: "images/POZZETTI/90x70_NEW.png",   label: "90x70 realizz",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 9,  image: "images/POZZETTI/90x70_ESIST.png", label: "90x70 esist",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 10, image: "images/POZZETTI/125x80_PROG.png", label: "125x80 progett",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Progettato" } },
                { id: 11, image: "images/POZZETTI/125x80_NEW.png",  label: "125x80 realizz",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Realizzato", PROPRIETA:"FiberCop" } },
                { id: 12, image: "images/POZZETTI/125x80_ESIST.png",label: "125x80 esist",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Esistente", PROPRIETA:"TIM" } },
                { id: 13, image: "images/POZZETTI/ALTRO.png",       label: "Altro",
                  values: { TIPOLOGIA:"Altro" } }
            ]
        },
        {
            name: "GIUNTI", label: "Giunti", icon: "🔗",
            geometryType: "point", photoField: "Foto1",
            voiceKeywords: ["giunto", "giunti"],
            fields: [
                { key: "TILABEL", label: "Naming", alias: "Naming", type: "text",
                  voiceKeys: ["naming", "neming", "nome", "label", "numero", "etichetta"],
                  numericCombine: true },
                { key: "TIPOLOGIA", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Compatta","Normale","Giunto di Linea"],
                  voiceKeys: ["tipologia", "tipo", "compatta", "normale", "linea", "giunto di linea"] },
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente"],
                  voiceKeys: ["stato", "realizzato", "esistente"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/GIUNTI/Compatta_Realizzato.png", label: "Compatta realizz",
                  values: { TIPOLOGIA:"Compatta", STATO:"Realizzato" } },
                { id: 2, image: "images/GIUNTI/Compatta_Esistente.png",  label: "Compatta esist",
                  values: { TIPOLOGIA:"Compatta", STATO:"Esistente" } },
                { id: 3, image: "images/GIUNTI/Normale_Realizzato.png",  label: "Normale realizz",
                  values: { TIPOLOGIA:"Normale", STATO:"Realizzato" } },
                { id: 4, image: "images/GIUNTI/Normale_Esistente.png",   label: "Normale esist",
                  values: { TIPOLOGIA:"Normale", STATO:"Esistente" } },
                { id: 5, image: "images/GIUNTI/GL_Realizzato.png",       label: "Linea realizz",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Realizzato" } },
                { id: 6, image: "images/GIUNTI/GL_Esistente.png",        label: "Linea esist",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Esistente" } }
            ]
        },
        {
            name: "PALI", label: "Pali", icon: "📏",
            geometryType: "point", photoField: "Foto_1",
            voiceKeywords: ["palo", "pali"],
            fields: [
                { key: "STATO", label: "Stato", alias: "Stato", type: "picker", options: ["Realizzato","Esistente"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente"] },
                { key: "MATERIALE", label: "Materiale", alias: "Materiale", type: "picker", options: ["Pino","Vtr"],
                  voiceKeys: ["materiale", "pino", "legno", "vtr"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "MODELLO", label: "Modello", alias: "Modello", type: "picker",
                  options: ["Singolo","Abbinato","Contropalo","Opposto"],
                  voiceKeys: ["modello", "singolo", "abbinato", "contropalo", "opposto"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "POSIZIONAM", label: "Posizionamento", alias: "Posizionamento", type: "picker", options: ["Base","Complessa"],
                  voiceKeys: ["posizionamento", "posizionam", "posiziona", "base", "complessa"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "Altezza", label: "Altezza?", alias: "Altezza?", type: "picker", options: ["8","9","10","11","12"],
                  voiceKeys: ["altezza"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "REGGIPALO", label: "Reggipalo?", alias: "Reggipalo?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["reggipalo", "reggi palo"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "TIRANTI_M", label: "Numero Tiranti a muro", alias: "Numero Tiranti a muro", type: "picker", options: ["0","1","2"],
                  voiceKeys: ["tiranti muro", "tiranti a muro", "tirante muro"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "TIRANTI_RO", label: "Numero Tiranti a Roccia", alias: "Numero Tiranti a Roccia", type: "picker", options: ["0","1","2"],
                  voiceKeys: ["tiranti roccia", "tiranti a roccia", "tirante roccia"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "PALO_ROCCI", label: "Palo VTR in roccia?", alias: "Palo VTR in roccia?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["palo roccia", "palo in roccia", "vtr roccia"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "SCORTA", label: "Presenza Scorta?", alias: "Presenza Scorta?", type: "picker", options: ["Si","No"],
                  voiceKeys: ["scorta", "presenza scorta"],
                  requiredWhen: { field: "STATO", values: ["Realizzato"] },
                  nullWhen: { field: "STATO", values: ["Esistente"] } },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalia", alias: "Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/PALI/Palo Esistente.png",     label: "Esistente",
                  values: { STATO:"Esistente" } },
                { id: 2, image: "images/PALI/Legno Singolo.png",      label: "Legno Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Singolo" } },
                { id: 3, image: "images/PALI/Legno Abbinato.png",     label: "Legno Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Abbinato" } },
                { id: 4, image: "images/PALI/Legno Contropalo.png",   label: "Legno Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Contropalo" } },
                { id: 5, image: "images/PALI/VTR Singolo.png",        label: "VTR Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Singolo" } },
                { id: 6, image: "images/PALI/VTR Abbinato.png",       label: "VTR Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Abbinato" } },
                { id: 7, image: "images/PALI/VTR Contropalo.png",     label: "VTR Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Contropalo" } }
            ]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            geometryType: "point",
            photoField: "Foto1", photoField2: "Foto2",
            photo1Required: true,
            voiceKeywords: ["extra"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Note","Colonna Montante","Foto"],
                  required: true, voiceKeys: ["tipologia", "tipo", "note", "colonna montante", "colonna", "montante", "foto"] },
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker", options: ["Nuovo","Esistente"],
                  voiceKeys: ["stato", "nuovo", "esistente"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] }
            ],
            presets: [
                { id: 1, image: "images/EXTRA/NOTE.png", label: "Note",
                  values: { Tipologia:"Note" } },
                { id: 2, image: "images/EXTRA/CM.png",   label: "Colonna Montante",
                  values: { Tipologia:"Colonna Montante" } },
                { id: 3, image: "images/EXTRA/FOTO.png", label: "Foto",
                  values: { Tipologia:"Foto" } }
            ]
        },
        {
            name: "CAVI", label: "Cavi", icon: "🪢",
            geometryType: "line", photoField: "Foto", lengthField: "Lunghezza",
            voiceKeywords: ["cavo", "cavi"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Fune Esistente","Nuova Fune"],
                  voiceKeys: ["tipologia", "tipo", "fune", "nuova fune", "esistente"] },
                { key: "Fibre", label: "Fibre", alias: "Fibre", type: "picker",
                  options: ["24","48","72","96","144","192"],
                  voiceKeys: ["fibre", "fibra"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  voiceKeys: ["lunghezza"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANOM", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/CAVI/FUNE_NUOVA.png", label: "Nuova Fune",
                  values: { Tipologia:"Nuova Fune" } },
                { id: 2, image: "images/CAVI/FUNE_ESIST.png", label: "Fune Esistente",
                  values: { Tipologia:"Fune Esistente" } }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰",
            geometryType: "line", photoField: "FOTO1", lengthField: "Lunghezza",
            voiceKeywords: ["raccordi", "raccordo"],
            fields: [
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Monofibra","Multifibra"],
                  required: true, voiceKeys: ["tipologia", "tipo", "monofibra", "multifibra"] },
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Progettato"],
                  required: true, voiceKeys: ["stato", "realizzato", "progettato"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  voiceKeys: ["lunghezza"] },
                { key: "NOTE", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Anomalia", alias: "Anomalia", type: "text",
                  voiceKeys: ["anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1, image: "images/RACCORDI/Monofibra_PROG.png",  label: "Mono progett",
                  values: { Tipologia:"Monofibra", Stato:"Progettato" } },
                { id: 2, image: "images/RACCORDI/Monofibra_REAL.png",  label: "Mono realizz",
                  values: { Tipologia:"Monofibra", Stato:"Realizzato" } },
                { id: 3, image: "images/RACCORDI/Multifibra_PROG.png", label: "Multi progett",
                  values: { Tipologia:"Multifibra", Stato:"Progettato" } },
                { id: 4, image: "images/RACCORDI/Multifibra_REAL.png", label: "Multi realizz",
                  values: { Tipologia:"Multifibra", Stato:"Realizzato" } }
            ]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte", icon: "⛏",
            geometryType: "line", photoField: "Foto1", lengthField: "Lunghezza",
            photo1Required: true,
            voiceKeywords: ["tratta", "tratte", "tratte interrate", "interrate"],
            fields: [
                { key: "Stato", label: "Stato", alias: "Stato", type: "picker",
                  options: ["Realizzato","Esistente","Progetto"],
                  required: true, voiceKeys: ["stato", "realizzato", "esistente", "progetto", "progettato"] },
                { key: "Tipologia", label: "Tipologia", alias: "Tipologia", type: "picker",
                  options: ["Canalizzazione","Trincea","Trincea Sterrato","Trincea Pregiato",
                           "Minitrincea","Microtrincea","No-Dig"],
                  required: true, voiceKeys: ["tipologia", "tipo", "canalizzazione", "trincea", "sterrato", "pregiato", "minitrincea", "microtrincea", "no dig", "no-dig", "nodig"] },
                { key: "Lunghezza", label: "Lunghezza (m)", alias: "Lunghezza (m)", type: "text", auto: "length",
                  voiceKeys: ["lunghezza"],
                  nullWhen: { field: "Stato", values: ["Progetto"] } },
                { key: "tubiera_co", label: "Tubiera completa", alias: "Tubiera completa", type: "text",
                  captureRest: true,
                  voiceKeys: ["tubiera completa", "tubiera", "minitubi", "tubi", "tubo", "fender", "pacchi"] },
                { key: "TIP_RIP", label: "Tipologia Ripristino", alias: "Tipologia Ripristino", type: "picker",
                  options: ["Bitume","Asfalto Colato","Cemento","Mattonelle cemento","Cubetti","Basoli","Ghiaia"],
                  voiceKeys: ["tipologia ripristino", "tip rip", "bitume", "asfalto", "cemento", "mattonelle", "cubetti", "basoli", "ghiaia"] },
                { key: "LARGH_RIP", label: "Larghezza Ripristino", alias: "Larghezza Ripristino", type: "text",
                  metricUnits: true,
                  voiceKeys: ["larghezza ripristino", "largh rip", "larghezza"] },
                { key: "Note", label: "Note", alias: "Note", type: "text",
                  voiceKeys: ["note", "annota"] },
                { key: "NOTE_ANO", label: "Descrizione", alias: "Descrizione", type: "text",
                  voiceKeys: ["descrizione", "anomalia", "anomalie"] }
            ],
            presets: [
                { id: 1,  image: "images/TRATTE INTERRATE/ESISTENTE.png",       label: "Esistente",
                  values: { Stato:"Esistente" } },
                { id: 2,  image: "images/TRATTE INTERRATE/Trincea_P.png",       label: "Trincea progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea" } },
                { id: 3,  image: "images/TRATTE INTERRATE/Trincea_R.png",       label: "Trincea realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea" } },
                { id: 4,  image: "images/TRATTE INTERRATE/Sterrato_P.png",      label: "Sterrato progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea Sterrato" } },
                { id: 5,  image: "images/TRATTE INTERRATE/Sterrato_R.png",      label: "Sterrato realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea Sterrato" } },
                { id: 6,  image: "images/TRATTE INTERRATE/Minitrincea_P.png",   label: "Minitr progett",
                  values: { Stato:"Progetto", Tipologia:"Minitrincea" } },
                { id: 7,  image: "images/TRATTE INTERRATE/Minitrincea_R.png",   label: "Minitr realizz",
                  values: { Stato:"Realizzato", Tipologia:"Minitrincea" } },
                { id: 8,  image: "images/TRATTE INTERRATE/Microtrincea_P.png",  label: "Microtr progett",
                  values: { Stato:"Progetto", Tipologia:"Microtrincea" } },
                { id: 9,  image: "images/TRATTE INTERRATE/Microtrincea_R.png",  label: "Microtr realizz",
                  values: { Stato:"Realizzato", Tipologia:"Microtrincea" } },
                { id: 10, image: "images/TRATTE INTERRATE/No Dig_P.png",        label: "No-Dig progett",
                  values: { Stato:"Progetto", Tipologia:"No-Dig" } },
                { id: 11, image: "images/TRATTE INTERRATE/No Dig_R.png",        label: "No-Dig realizz",
                  values: { Stato:"Realizzato", Tipologia:"No-Dig" } }
            ]
        }
    ]



    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []

    // ── SEGNALAZIONE EVENTI VIA CREATEDIR ───────────────────────
    // QField QML espone solo createDir e renameFile per la scrittura.
    // renameFile distrugge la sorgente, quindi non e' praticabile per
    // eventi ripetuti. Usiamo createDir: per ogni evento creiamo una
    // sottocartella timestampata dentro una cartella-evento. MacroDroid
    // configura il trigger "Folder Modified" su ciascuna cartella-evento.
    property string signalsRoot: "/storage/emulated/0/Download/pte_signals"
    property bool signalsRootReady: false

    // Elenco eventi noti - per pre-creare le cartelle padre
    property var knownEvents: [
        "voice_input_ready", "layer_picker_ready", "form_ready",
        "vertex_choice_ready", "line_first_vertex", "foto_scatta",
        "auto_shutter", "auto_confirm", "photo_done", "all_closed"
    ]

    function ensureSignalsRoot() {
        if (plugin.signalsRootReady) return
        try {
            platformUtilities.createDir("/storage/emulated/0/Download", "pte_signals")
            // Pre-crea le cartelle per ogni evento noto
            for (var i = 0; i < plugin.knownEvents.length; i++) {
                platformUtilities.createDir(plugin.signalsRoot, plugin.knownEvents[i])
            }
            plugin.signalsRootReady = true
        } catch(e) {
            // silent
        }
    }

    function broadcastEvent(eventName) {
        try {
            ensureSignalsRoot()
            var evDir = plugin.signalsRoot + "/" + eventName.toLowerCase()
            // Crea una sottocartella unica per l'evento → trigger MacroDroid
            // su "Folder Modified" della cartella evDir
            var subName = "t" + Date.now()
            platformUtilities.createDir(evDir, subName)
        } catch(e) {
            // silent
        }
    }

    // ── DIAGNOSTICO FILE WRITE ──────────────────────────────────
    // Prova vari metodi e accumula i risultati in diagLog, mostrato
    // in una dialog persistente cosi' i risultati sono leggibili con calma.
    property string diagLog: ""

    function diagAdd(line) {
        plugin.diagLog += line + "\n"
    }

    function probeMethods(objName, obj, methods) {
        diagAdd(objName + ":")
        if (!obj) { diagAdd("  (oggetto non esiste)"); return }
        for (var i = 0; i < methods.length; i++) {
            var m = methods[i]
            var t = "?"
            try { t = typeof obj[m] } catch(e) { t = "EXC:" + e }
            diagAdd("  " + m + " : " + t)
        }
    }

    function runFileDiagnostic() {
        plugin.diagLog = ""
        ensureSignalsRoot()

        diagAdd("=== TEST CREATEDIR APPROACH ===")
        diagAdd("Crea sottocartelle dentro /Download/pte_signals/<evento>/")
        diagAdd("")
        try {
            var testEvent = plugin.signalsRoot + "/auto_shutter"
            var subName = "diag_t" + Date.now()
            var ok = platformUtilities.createDir(testEvent, subName)
            diagAdd("createDir(\"" + testEvent + "\", \"" + subName + "\")")
            diagAdd("  -> " + ok)
            diagAdd("  esiste: " + FileUtils.fileExists(testEvent + "/" + subName))
        } catch(e) {
            diagAdd("EXC: " + e)
        }
        diagAdd("")
        diagAdd("=== PROBE METODI QFIELD ===")
        diagAdd("")

        // Probe FileUtils
        var fuObj = (typeof FileUtils !== "undefined") ? FileUtils : null
        probeMethods("FileUtils", fuObj, [
            "copyFile","copy","copyTo","clone",
            "moveFile","move","rename","renameFile",
            "deleteFile","remove","removeFile","unlink",
            "fileExists","exists","isFile","isDir",
            "writeFile","write","writeText","createFile","touch",
            "copyDir","deleteDir","makeDir","mkdir",
            "fileSuffix","fileName","absolutePath","addUniqueSuffix"
        ])
        diagAdd("")

        // Probe platformUtilities
        var puObj = (typeof platformUtilities !== "undefined") ? platformUtilities : null
        probeMethods("platformUtilities", puObj, [
            "copyFile","copy","copyTo",
            "moveFile","move","renameFile",
            "deleteFile","remove",
            "createDir","makeDir","mkdir",
            "createSymbolicLink","symlink","link",
            "openFile","openLink","openUrl",
            "writeFile","write","createFile","touch",
            "vibrate","getCameraPictureFilePath"
        ])
        diagAdd("")

        // Probe iface se ha sotto-oggetti utili
        var ifaceObj = (typeof iface !== "undefined") ? iface : null
        probeMethods("iface", ifaceObj, [
            "platformUtilities","fileUtils","writeFile",
            "mainWindow","findItemByObjectName","addItemToPluginsToolbar"
        ])
        diagAdd("")

        // Probe globals
        diagAdd("Globals:")
        try { diagAdd("  Qt.fileExists?: " + typeof Qt.fileExists) } catch(e) {}
        try { diagAdd("  qgisProject: " + typeof qgisProject) } catch(e) {}
        try { diagAdd("  qgisProject.homePath: " + qgisProject.homePath) } catch(e) {}
        diagAdd("")

        // Test pratico: createSymbolicLink (se esiste)
        diagAdd("=== TEST createSymbolicLink ===")
        var seedPath = "(non usato in v23)"
        var destPath = plugin.signalsDir + "/_diag_test.signal"
        diagAdd("SEED: " + seedPath)
        diagAdd("DEST: " + destPath)

        if (puObj && typeof puObj.createSymbolicLink === "function") {
            try {
                var ok = puObj.createSymbolicLink(seedPath, destPath)
                diagAdd("createSymbolicLink -> " + ok)
            } catch(e) {
                diagAdd("createSymbolicLink EXC: " + e)
            }
            try {
                diagAdd("file esiste dopo: " + FileUtils.fileExists(destPath))
            } catch(e) {}
        } else {
            diagAdd("createSymbolicLink NON disponibile")
        }
        diagAdd("")

        // Test pratico: scrittura in qgisProject.homePath (cartella sicuramente scrivibile)
        diagAdd("=== TEST homePath copy ===")
        try {
            var home = qgisProject.homePath
            diagAdd("homePath: " + home)
            var homeDest = home + "/_diag_in_project.signal"
            diagAdd("dest in project: " + homeDest)
            if (puObj && typeof puObj.renameFile === "function") {
                // First, prova a creare un seed temporaneo in homePath via openFile?
                // Saltiamo, useremo renameFile dopo un copy se possibile
            }
            diagAdd("(test homePath skipped — serve un metodo copy/write per riempirlo)")
        } catch(e) {
            diagAdd("homePath test EXC: " + e)
        }

        diagAdd("")
        diagAdd("=== FINE ===")
        diagAdd("Manda screenshot di questa schermata.")
        diagDialog.visible = true
    }

    // Evento "ombrello": emesso ogni volta che un input vocale e' pronto.
    // Configura UNA macro MacroDroid su pte.plugin.VOICE_INPUT_READY
    // che attivi il microfono della tastiera — copre tutti gli stati
    // (picker layer, form punto, modale vertice, form fine-tratta, ritorno dopo foto).
    function emitVoiceReady() {
        broadcastEvent("VOICE_INPUT_READY")
    }

    // Polling per form
    Timer {
        id: pollTimer
        interval: 500; repeat: true; running: overlay.visible
        onTriggered: {
            if (inputArea.text !== plugin.lastParsedText && inputArea.text.length > 2) {
                plugin.lastParsedText = inputArea.text
                processVoice(inputArea.text)
            }
        }
    }

    // Polling per layer picker
    Timer {
        id: layerVoicePollTimer
        interval: 400; repeat: true; running: layerPicker.visible
        onTriggered: {
            if (layerVoiceInput.text !== plugin.lastLayerVoiceText
                    && layerVoiceInput.text.length > 1) {
                plugin.lastLayerVoiceText = layerVoiceInput.text
                tryMatchLayerVoice(layerVoiceInput.text)
            }
        }
    }

    // Polling per vertex choice
    Timer {
        id: vertexVoicePollTimer
        interval: 400; repeat: true; running: vertexChoice.visible
        onTriggered: {
            if (vertexVoiceInput.text !== plugin.lastVertexVoiceText
                    && vertexVoiceInput.text.length > 1) {
                plugin.lastVertexVoiceText = vertexVoiceInput.text
                processVertexVoice(vertexVoiceInput.text)
            }
        }
    }

    // Polling per radial menu
    Timer {
        id: radialVoicePollTimer
        interval: 400; repeat: true; running: radialMenu.visible
        onTriggered: {
            if (radialVoiceInput.text !== plugin.lastRadialVoiceText
                    && radialVoiceInput.text.length > 0) {
                plugin.lastRadialVoiceText = radialVoiceInput.text
                processRadialVoice(radialVoiceInput.text)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        layerPicker.parent     = mainWindow.contentItem
        overlay.parent         = mainWindow.contentItem
        picker.parent          = mainWindow.contentItem
        freeTextEditor.parent  = mainWindow.contentItem
        vertexChoice.parent    = mainWindow.contentItem
        radialMenu.parent      = mainWindow.contentItem
        diagDialog.parent      = mainWindow.contentItem
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible || picker.visible || freeTextEditor.visible || vertexChoice.visible || radialMenu.visible) {
            return
        }
        if (layerPicker.visible) {
            closeAll(); return
        }

        capturePendingPosition()

        if (plugin.lineMode) {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido")
                return
            }
            vertexCountText.text = "Vertici raccolti: " + plugin.lineVertices.length +
                                   " + 1 in attesa"
            plugin.lastVertexVoiceText = ""
            vertexVoiceInput.text = ""
            vertexChoice.visible = true
            vertexFocusTimer.start()
            broadcastEvent("VERTEX_CHOICE_READY")
            emitVoiceReady()
        } else {
            updateGPS()
            plugin.lastLayerVoiceText = ""
            layerVoiceInput.text = ""
            layerPicker.visible = true
            layerFocusTimer.start()
            broadcastEvent("LAYER_PICKER_READY")
            emitVoiceReady()
        }
    }

    function capturePendingPosition() {
        plugin.pendingValid = false
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                var pos = positionSource.projectedPosition
                plugin.pendingX = pos.x
                plugin.pendingY = pos.y
                plugin.pendingValid = true
            }
        }
    }

    function closeAll() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        picker.visible = false
        freeTextEditor.visible = false
        vertexChoice.visible = false
        radialMenu.visible = false
        plugin.lineMode = false
        plugin.lineVertices = []
        plugin.pendingValid = false
        plugin.lastLayerVoiceText = ""
        plugin.lastVertexVoiceText = ""
        plugin.lastRadialVoiceText = ""
        if (layerVoiceInput) layerVoiceInput.text = ""
        if (vertexVoiceInput) vertexVoiceInput.text = ""
        if (radialVoiceInput) radialVoiceInput.text = ""
        resetData()
        broadcastEvent("ALL_CLOSED")
    }

    QfToolButton {
        id: micBtn
        bgcolor: "#2980b9"
        iconSource: Theme.getThemeVectorIcon("ic_add_white_24dp")
        iconColor: "white"
        round: true
        onClicked: togglePanel()
        Text {
            anchors.centerIn: parent
            text: "+"
            color: "white"
            font.pixelSize: 28
            font.bold: true
            z: 2
        }
    }

    function findLayerDef(name) {
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            if (plugin.layerDefs[i].name === name) return plugin.layerDefs[i]
        }
        return null
    }

    function tryMatchLayerVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.length < 2) return

        var best = null
        var bestScore = 0
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            var ld = plugin.layerDefs[i]
            var kws = ld.voiceKeywords || []
            for (var j = 0; j < kws.length; j++) {
                var kw = kws[j].toLowerCase()
                if (t.indexOf(kw) !== -1) {
                    if (kw.length > bestScore) { bestScore = kw.length; best = ld }
                }
            }
            if (t.indexOf(ld.name.toLowerCase()) !== -1 ||
                t.indexOf(ld.label.toLowerCase()) !== -1) {
                if (ld.name.length > bestScore) { bestScore = ld.name.length; best = ld }
            }
        }
        if (best) {
            mainWindow.displayToast("🎯 " + best.label + " selezionato")
            selectLayer(best)
        }
    }

    // ── VOICE PARSER PER MODALE VERTICE ─────────────────────────
    function processVertexVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.indexOf("fine") !== -1 || t.indexOf("chiudi") !== -1
                || t.indexOf("termina") !== -1 || t.indexOf("ultimo") !== -1) {
            endLineAndOpenForm()
        } else if (t.indexOf("vertice") !== -1 || t.indexOf("intermedio") !== -1
                   || t.indexOf("punto") !== -1) {
            addIntermediateVertex()
        } else if (t.indexOf("annulla") !== -1 || t.indexOf("cancella") !== -1
                   || t.indexOf("abort") !== -1) {
            vertexChoice.visible = false
            closeAll()
            mainWindow.displayToast("Tratta annullata")
        }
    }

    // Riconosce numero da digitazione o voce (italiano)
    function parseNumberFromText(text) {
        var t = text.toLowerCase().trim()
        var m = t.match(/\d+/)
        if (m) return parseInt(m[0])
        var words = ["zero","uno","due","tre","quattro","cinque","sei",
                     "sette","otto","nove","dieci","undici","dodici",
                     "tredici","quattordici","quindici","sedici"]
        for (var i = 0; i < words.length; i++) {
            if (t.indexOf(words[i]) !== -1) return i
        }
        return -1
    }

    function processRadialVoice(text) {
        var n = parseNumberFromText(text)
        if (n < 1) return
        // Cerca preset con id corrispondente
        for (var i = 0; i < plugin.currentPresets.length; i++) {
            if (plugin.currentPresets[i].id === n) {
                selectPreset(plugin.currentPresets[i])
                return
            }
        }
    }

    function selectPreset(preset) {
        // Pre-popola parsedData con i values del preset
        var d = plugin.parsedData
        if (preset.values) {
            for (var k in preset.values) {
                d[k] = preset.values[k]
            }
        }
        plugin.parsedData = d
        var n = 0
        for (var k2 in d) if (d[k2] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()

        radialMenu.visible = false
        mainWindow.displayToast("✓ Preset " + preset.id + ": " + preset.label)

        // Se layer e' linea, avvia lineMode con primo vertice; altrimenti apri form
        var def = plugin.selectedLayerDef
        if (def && def.geometryType === "line") {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido, vertice 1 saltato")
                return
            }
            plugin.lineVertices = [{ x: plugin.pendingX, y: plugin.pendingY }]
            plugin.lineMode = true
            plugin.pendingValid = false
            Qt.inputMethod.hide()
            mainWindow.displayToast("📍 Vertice 1 salvato. Spostati e ripremi.")
            broadcastEvent("LINE_FIRST_VERTEX")
        } else {
            overlay.visible = true
            focusTimer.start()
            broadcastEvent("FORM_READY")
            emitVoiceReady()
        }
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.selectedLayerDef = layerDef
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            plugin.selectedLayer = layer
            dashBoard.activeLayer = layer
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        resetData()
        layerPicker.visible = false

        if (layerDef.geometryType === "line" && layerDef.presets && layerDef.presets.length > 0) {
            // Linea CON preset: mostra radial PRIMA di avviare lineMode
            plugin.currentPresets = layerDef.presets
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            radialMenu.visible = true
            radialFocusTimer.start()
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
        } else if (layerDef.geometryType === "line") {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido, vertice 1 saltato")
                return
            }
            plugin.lineVertices = [{ x: plugin.pendingX, y: plugin.pendingY }]
            plugin.lineMode = true
            plugin.pendingValid = false
            Qt.inputMethod.hide()
            mainWindow.displayToast("📍 Vertice 1 salvato. Spostati e ripremi.")
            broadcastEvent("LINE_FIRST_VERTEX")
        } else if (layerDef.presets && layerDef.presets.length > 0) {
            // Layer con preset: mostra menu radial
            plugin.currentPresets = layerDef.presets
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            radialMenu.visible = true
            radialFocusTimer.start()
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
        } else {
            overlay.visible = true
            focusTimer.start()
            broadcastEvent("FORM_READY")
            emitVoiceReady()
        }
    }

    function findLayer(name) {
        if (plugin.selectedLayer) return plugin.selectedLayer
        if (dashBoard && dashBoard.activeLayer) return dashBoard.activeLayer
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++)
            d[plugin.currentFields[i].key] = ""
        plugin.parsedData = d
        plugin.okCount = 0
        plugin.photo1Path = ""
        plugin.photo2Path = ""
        plugin.photoSlot = 1
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 250; repeat: false
        onTriggered: {
            inputArea.forceActiveFocus()
            Qt.inputMethod.show()
            focusRetry.start()
        }
    }
    Timer {
        id: focusRetry
        interval: 700; repeat: false
        onTriggered: {
            if (overlay.visible && !inputArea.activeFocus) {
                inputArea.forceActiveFocus()
                Qt.inputMethod.show()
            }
        }
    }
    Timer {
        id: layerFocusTimer
        interval: 300; repeat: false
        onTriggered: {
            layerVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }
    Timer {
        id: vertexFocusTimer
        interval: 250; repeat: false
        onTriggered: {
            vertexVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }
    Timer {
        id: radialFocusTimer
        interval: 250; repeat: false
        onTriggered: {
            radialVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    function processVoice(text) {
        var t = text.toLowerCase()

        if (t.indexOf("scatta foto") !== -1
                || t.indexOf("fai foto") !== -1
                || t.indexOf("fai una foto") !== -1
                || t.indexOf("scatta una foto") !== -1) {
            inputArea.text = ""
            plugin.lastParsedText = ""
            triggerPhotoCapture()
            return
        }

        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    function triggerPhotoCapture() {
        platformUtilities.createDir(qgisProject.homePath, "DCIM")
        broadcastEvent("FOTO_SCATTA")
        cameraLoader.active = true
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#f5f6f8"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer (voce o tap)"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width; height: 44
                    color: "#ffffff"; radius: 8
                    border.color: layerVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: layerVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#1a1d27"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 Di' il nome del layer..."
                        placeholderTextColor: "#5a6378"
                    }
                }

                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#d5dde8" : "#e3eef8"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label +
                                      (modelData.geometryType === "line" ? "  ⟶" : "")
                                color: "#1a1d27"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#2980b9"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── MODALE VERTICE / FINE TRATTA con voice input ────────────
    Rectangle {
        id: vertexChoice
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 460)
            height: vcCol.implicitHeight + 32
            color: "#f5f6f8"; radius: 12

            Column {
                id: vcCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 12

                Text {
                    width: parent.width
                    text: "Disegno tratta"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    id: vertexCountText
                    width: parent.width
                    text: ""
                    color: "#1e8449"; font.pixelSize: 13
                    horizontalAlignment: Text.AlignHCenter
                }

                // Voice input per vertice
                Rectangle {
                    width: parent.width; height: 44
                    color: "#ffffff"; radius: 8
                    border.color: vertexVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: vertexVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#1a1d27"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 'vertice' o 'fine tratta'"
                        placeholderTextColor: "#5a6378"
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: vM.pressed ? "#d5dde8" : "#e3eef8"
                    border.color: "#2a5a8a"; border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "📍"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "VERTICE intermedio"
                               color: "#1a1d27"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: vM; anchors.fill: parent
                        onClicked: addIntermediateVertex()
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: fM.pressed ? "#178a3e" : "#1db954"
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "🏁"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "FINE TRATTA"
                               color: "white"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: fM; anchors.fill: parent
                        onClicked: endLineAndOpenForm()
                    }
                }

                Rectangle {
                    width: parent.width; height: 42; radius: 8
                    color: cancM.pressed ? "#2a2d40" : "#ffffff"; border.color: "#c0c5d0"
                    Text { anchors.centerIn: parent; text: "✕ Annulla tratta"
                           color: "#5a6378"; font.pixelSize: 14 }
                    MouseArea {
                        id: cancM; anchors.fill: parent
                        onClicked: {
                            vertexChoice.visible = false
                            closeAll()
                            mainWindow.displayToast("Tratta annullata")
                        }
                    }
                }
            }
        }
    }

    function addIntermediateVertex() {
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            Qt.inputMethod.hide()
            return
        }
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        // Nascondi tastiera: torniamo alla mappa fra un vertice e l'altro
        Qt.inputMethod.hide()
        mainWindow.displayToast("📍 Vertice " + plugin.lineVertices.length + " salvato")
    }

    function endLineAndOpenForm() {
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            return
        }
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        mainWindow.displayToast("🏁 Tratta chiusa con " +
                                plugin.lineVertices.length + " vertici")

        var def = plugin.selectedLayerDef
        if (def && def.lengthField) {
            var lengthM = calculateLineLength()
            var formatted = lengthM.toFixed(1)
            var d = plugin.parsedData
            d[def.lengthField] = formatted
            plugin.parsedData = d
            var n = 0
            for (var k in d) if (d[k] !== "") n++
            plugin.okCount = n
            fieldsModel.refresh()
        }

        overlay.visible = true
        focusTimer.start()
        broadcastEvent("FORM_READY")
        emitVoiceReady()
    }

    function calculateLineLength() {
        if (plugin.lineVertices.length < 2) return 0
        var total = 0
        var isGeographic = false
        try {
            isGeographic = qgisProject.crs && qgisProject.crs.isGeographic
        } catch(e) {
            var v = plugin.lineVertices[0]
            isGeographic = (Math.abs(v.x) <= 180 && Math.abs(v.y) <= 90)
        }
        for (var i = 1; i < plugin.lineVertices.length; i++) {
            var v1 = plugin.lineVertices[i-1]
            var v2 = plugin.lineVertices[i]
            if (isGeographic) {
                total += haversineDistance(v1.y, v1.x, v2.y, v2.x)
            } else {
                var dx = v2.x - v1.x
                var dy = v2.y - v1.y
                total += Math.sqrt(dx*dx + dy*dy)
            }
        }
        return total
    }

    function haversineDistance(lat1, lon1, lat2, lon2) {
        var R = 6371000
        var toRad = Math.PI / 180
        var dLat = (lat2 - lat1) * toRad
        var dLon = (lon2 - lon1) * toRad
        var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: 2
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.62, 660)
            color: "#f5f6f8"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = plugin.selectedLayerDef
                            if (!def) return "⚡ Voice Parser"
                            var suffix = (def.geometryType === "line")
                                ? "  (" + plugin.lineVertices.length + " vertici)"
                                : ""
                            return def.icon + " " + def.label + suffix
                        }
                        color: "#2980b9"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#d5dde8" : "#ffffff"
                        border.color: "#c0c5d0"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#5a6378"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#ffffff"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#5a6378"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 56
                    color: "#ffffff"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "🎤 Parla ora oppure digita..."
                            color: "#1a1d27"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            onTextChanged: { if (text.length > 2) processVoice(text) }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#5a6378"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            // Stati: VERDE = OK; ROSSO = obbligatorio mancante;
                            //        GIALLO/ARANCIONE = popolato in conflitto (deve essere null);
                            //        GRIGIO = opzionale non popolato
                            color: model.fieldMustNull && model.fieldOk ? "#fff3cd"
                                 : model.fieldOk ? "#d4edda"
                                 : model.fieldRequired ? "#ffd2d2"
                                 : "#f8f8fa"
                            border.color: model.fieldMustNull && model.fieldOk ? "#d68910"
                                        : model.fieldOk ? "#27ae60"
                                        : model.fieldRequired ? "#c0392b"
                                        : "#c0c5d0"
                            border.width: model.fieldRequired && !model.fieldOk ? 3 : 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel
                                              + (model.fieldRequired ? " *" : "")
                                              + (model.fieldMustNull && model.fieldOk ? " (da svuotare)" : "")
                                       font.pixelSize: 9; font.bold: true
                                       color: model.fieldMustNull && model.fieldOk ? "#f39c12"
                                            : model.fieldOk ? "#27ae60"
                                            : model.fieldRequired ? "#c0392b"
                                            : "#5a6378" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldMustNull && model.fieldOk ? "#f1c40f"
                                            : model.fieldOk ? "#1e8449"
                                            : model.fieldRequired ? "#c0392b"
                                            : "#5a6378"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldType === "picker" ? "▾" : "✎"
                                color: "#2980b9"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        // FIX v30: Recupera opzioni direttamente da currentFields
                                        // (ListModel non conserva bene gli array)
                                        var opts = []
                                        for (var ii = 0; ii < plugin.currentFields.length; ii++) {
                                            if (plugin.currentFields[ii].key === model.fieldKey) {
                                                opts = plugin.currentFields[ii].options || []
                                                break
                                            }
                                        }
                                        plugin.activeFieldOptions = opts
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Foto 1
                Rectangle {
                    Layout.fillWidth: true
                    height: 48; radius: 8
                    color: fotoM.pressed ? "#d5dde8" : (plugin.photo1Path !== "" ? "#d4edda" : "#ffffff")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#c0c5d0"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text { text: plugin.photo1Path !== "" ? "✅" : "📷"; font.pixelSize: 18
                               anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: plugin.photo1Path !== ""
                                  ? "Foto 1 acquisita ✔"
                                  : "Foto 1 (di' 'scatta foto')"
                            color: plugin.photo1Path !== "" ? "#1e8449" : "#5a6378"
                            font.pixelSize: 13
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: { plugin.photoSlot = 1; triggerPhotoCapture() }
                    }
                }
                // Foto 2 (visibile solo se il layer la supporta)
                Rectangle {
                    Layout.fillWidth: true
                    visible: plugin.selectedLayerDef && plugin.selectedLayerDef.photoField2
                    height: visible ? 48 : 0
                    radius: 8
                    color: foto2M.pressed ? "#d5dde8" : (plugin.photo2Path !== "" ? "#d4edda" : "#ffffff")
                    border.color: plugin.photo2Path !== "" ? "#27ae60" : "#c0c5d0"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text { text: plugin.photo2Path !== "" ? "✅" : "📷"; font.pixelSize: 18
                               anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: plugin.photo2Path !== ""
                                  ? "Foto 2 acquisita ✔"
                                  : "Foto 2"
                            color: plugin.photo2Path !== "" ? "#1e8449" : "#5a6378"
                            font.pixelSize: 13
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: foto2M; anchors.fill: parent
                        onClicked: { plugin.photoSlot = 2; triggerPhotoCapture() }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma\" per salvare · \"scatta foto\" per la foto"
                    color: "#2980b9"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#ffffff"; border.color: "#c0c5d0"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#5a6378"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        property bool canSave: {
                            if (plugin.okCount === 0) return false
                            for (var ii = 0; ii < fieldsModel.count; ii++) {
                                var m = fieldsModel.get(ii)
                                if (m.fieldRequired && !m.fieldOk) return false
                                if (m.fieldMustNull && m.fieldOk) return false
                            }
                            var def = plugin.selectedLayerDef
                            if (def && def.photo1Required && plugin.photo1Path === "") return false
                            if (def && def.photo2Required && plugin.photo2Path === "") return false
                            return true
                        }
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: canSave ? (okM.pressed ? "#178a3e" : "#1db954") : "#3a2a2a"
                        Text { anchors.centerIn: parent
                               text: parent.canSave ? "✔ CONFERMA" : "⛔ Vincoli mancanti"
                               color: parent.canSave ? "white" : "#aa8888"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#f5f6f8"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#2980b9"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                // Bottone "Nessuno" per cancellare il valore (non visibile se required)
                Rectangle {
                    id: nullBtn
                    visible: {
                        // Mostra se il field corrente NON e' required
                        for (var ci = 0; ci < plugin.currentFields.length; ci++) {
                            if (plugin.currentFields[ci].key === plugin.activeFieldKey) {
                                return !plugin.currentFields[ci].required
                            }
                        }
                        return true
                    }
                    width: parent.width; height: visible ? 40 : 0; radius: 6
                    color: nullMA.pressed ? "#fadbd8" : "#fafafa"
                    border.color: "#c0c5d0"; border.width: 1
                    Text { anchors.centerIn: parent; text: "✕ Nessuno (vuoto)"
                           color: "#c0392b"; font.pixelSize: 13; font.italic: true }
                    MouseArea {
                        id: nullMA; anchors.fill: parent
                        onClicked: {
                            var d = JSON.parse(JSON.stringify(plugin.parsedData))
                            d[plugin.activeFieldKey] = ""
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            picker.visible = false
                        }
                    }
                }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#ffffff" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#1e8449" : "#1a1d27"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                // FIX v31: deep copy per garantire reattivita' QML
                                var d = JSON.parse(JSON.stringify(plugin.parsedData))
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#f5f6f8"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#2980b9"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#ffffff"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#c0c5d0"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#1a1d27"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = JSON.parse(JSON.stringify(plugin.parsedData))
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // ── CAMERA con auto-cattura via intent broadcast ────────────
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                id: cameraItem
                visible: false
                Component.onCompleted: {
                    open()
                    if (plugin.autoCaptureMs > 0) autoCapTimer.start()
                }

                Timer {
                    id: autoCapTimer
                    interval: plugin.autoCaptureMs
                    repeat: false
                    onTriggered: {
                        mainWindow.displayToast("📸 Scatto in corso...")
                        // Invia intent broadcast — MacroDroid intercetta e
                        // simula il tap sul tasto scatto via accessibility
                        broadcastEvent("AUTO_SHUTTER")
                        // Secondo intent dopo 1.5s per il tap di conferma
                        confirmCapTimer.start()
                    }
                }

                Timer {
                    id: confirmCapTimer
                    interval: 1500
                    repeat: false
                    onTriggered: broadcastEvent("AUTO_CONFIRM")
                }

                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    // Assegna allo slot corrente, poi avanza
                    if (plugin.photoSlot === 1) {
                        plugin.photo1Path = filename
                        plugin.photoSlot = 2
                        mainWindow.displayToast("📷 Foto 1 acquisita!")
                    } else {
                        plugin.photo2Path = filename
                        plugin.photoSlot = 1
                        mainWindow.displayToast("📷 Foto 2 acquisita!")
                    }
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onCanceled: {
                    close()
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onClosed: cameraLoader.active = false
            }
        }
    }

    // ── MENU RADIAL (preset per layer con presets) ──────────────
    Rectangle {
        id: radialMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        // Pannello centrale: ruota radiale con bottoni intorno
        Item {
            id: wheelArea
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 660)
            height: width

            // Titolo
            Text {
                anchors.top: parent.top
                anchors.horizontalCenter: parent.horizontalCenter
                text: {
                    var def = plugin.selectedLayerDef
                    return (def ? def.icon + " " + def.label : "") + " - Preset"
                }
                color: "#2980b9"; font.pixelSize: 18; font.bold: true
            }

            // Cerchio centrale con bottone X (annulla)
            Rectangle {
                anchors.centerIn: parent
                width: 100; height: 100; radius: 50
                color: cnclMA.pressed ? "#5a1a1a" : "#3a1a1a"
                border.color: "#8a3a3a"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 2
                    Text { text: "✕"; color: "white"; font.pixelSize: 24
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                    Text { text: "annulla"; color: "#bbb"; font.pixelSize: 10
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                }
                MouseArea {
                    id: cnclMA; anchors.fill: parent
                    onClicked: { radialMenu.visible = false; closeAll() }
                }
            }

            // Bottoni preset disposti in cerchio
            Repeater {
                model: plugin.currentPresets
                delegate: Rectangle {
                    readonly property real myAngle: (index / Math.max(plugin.currentPresets.length, 1)) * 2 * Math.PI - Math.PI / 2
                    readonly property real distance: wheelArea.width * 0.38
                    width: 100; height: 100; radius: 50
                    x: wheelArea.width / 2 + Math.cos(myAngle) * distance - width / 2
                    y: wheelArea.height / 2 + Math.sin(myAngle) * distance - height / 2
                    color: presetMA.pressed ? "#2a5a8a" : "#e3eef8"
                    border.color: "#2980b9"; border.width: 2

                    Column {
                        anchors.centerIn: parent; spacing: 1
                        // Immagine (se preset ha "image") oppure emoji "icon"
                        Item {
                            width: 56; height: 56
                            anchors.horizontalCenter: parent.horizontalCenter
                            Image {
                                anchors.fill: parent
                                source: modelData.image
                                       ? Qt.resolvedUrl(modelData.image)
                                       : ""
                                fillMode: Image.PreserveAspectFit
                                smooth: true
                                visible: modelData.image ? true : false
                                asynchronous: true
                            }
                            Text {
                                anchors.centerIn: parent
                                visible: !modelData.image
                                text: modelData.icon || "•"
                                font.pixelSize: 28
                            }
                        }
                        Text {
                            text: "" + modelData.id
                            color: "#2980b9"; font.pixelSize: 13; font.bold: true
                            horizontalAlignment: Text.AlignHCenter
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                        Text {
                            text: modelData.label
                            color: "#a8b0c8"; font.pixelSize: 8
                            width: 90
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                    }

                    MouseArea {
                        id: presetMA; anchors.fill: parent
                        onClicked: selectPreset(modelData)
                    }
                }
            }
        }

        // Input vocale in basso (numero)
        Rectangle {
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 80
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(parent.width * 0.7, 360)
            height: 50
            color: "#ffffff"; radius: 8
            border.color: radialVoiceInput.activeFocus ? "#3d8ef0" : "#c0c5d0"
            border.width: 2
            TextField {
                id: radialVoiceInput
                anchors.fill: parent
                anchors.leftMargin: 12; anchors.rightMargin: 12
                color: "#1a1d27"; background: null
                font.pixelSize: 16
                placeholderText: "🎤 di' il numero (uno, due, tre...)"
                placeholderTextColor: "#5a6378"
            }
        }
    }

    // ── DIALOG DIAGNOSTICA (persistente, leggibile con calma) ──
    Rectangle {
        id: diagDialog
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 11000; color: "#66000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.95, 700)
            height: Math.min(parent.height * 0.85, 700)
            color: "#f5f6f8"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                Text {
                    width: parent.width
                    text: "🔧 Risultato diagnostica"
                    color: "#2980b9"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width
                    height: parent.height - 90
                    color: "#0a0d17"; radius: 8
                    border.color: "#c0c5d0"; border.width: 1
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        clip: true
                        TextArea {
                            id: diagLogArea
                            text: plugin.diagLog
                            color: "#1e8449"
                            font.family: "monospace"
                            font.pixelSize: 11
                            readOnly: true
                            wrapMode: TextArea.Wrap
                            background: null
                        }
                    }
                }

                Rectangle {
                    width: parent.width; height: 44; radius: 8
                    color: closeDiagMA.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ CHIUDI"
                           color: "white"; font.pixelSize: 14; font.bold: true }
                    MouseArea {
                        id: closeDiagMA; anchors.fill: parent
                        onClicked: diagDialog.visible = false
                    }
                }
            }
        }
    }

    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureForm.save()
            drawer.close()
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            closeAll()
        }
    }

    // Dopo chiusura camera, riporta focus al form ed emette VOICE_INPUT_READY
    Timer {
        id: photoReturnTimer
        interval: 350
        repeat: false
        onTriggered: {
            if (overlay.visible) {
                inputArea.forceActiveFocus()
                Qt.inputMethod.show()
                emitVoiceReady()
            }
        }
    }

    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            var d = plugin.parsedData
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                if (fd.key === "OBJECTID") continue
                var val = d[fd.key] || ""
                var lbl = fd.alias || fd.label || fd.key
                var isReq = isRequired(fd, d)
                var mustNull = isMustBeNull(fd, d)
                append({
                    fieldLabel:    lbl,
                    fieldKey:      fd.key,
                    fieldValue:    val,
                    fieldOk:       val !== "",
                    fieldType:     fd.type,
                    fieldOptions:  fd.options || [],
                    fieldRequired: isReq,
                    fieldMustNull: mustNull
                })
            }
        }
        Component.onCompleted: refresh()
    }

    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    // ── PARSER VOCE evoluto con voiceKeys + propagation ─────────
    function parseText(raw) {
        var t = raw.toLowerCase()
        var d = {}

        // Inizializza d copiando i valori esistenti
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""
        }

        // Per ogni field, prova a matchare
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            var matched = false
            var matchedValue = ""

            if (fd.type === "picker" && fd.options) {
                // Match diretto sui valori delle opzioni
                for (var j = 0; j < fd.options.length; j++) {
                    var opt = fd.options[j].toLowerCase()
                    if (t.indexOf(opt) !== -1) {
                        matchedValue = fd.options[j]; matched = true; break
                    }
                }
                // Match su sinonimi specifici (voiceKeys)
                if (!matched && fd.voiceKeys) {
                    for (var k = 0; k < fd.voiceKeys.length; k++) {
                        var vk = fd.voiceKeys[k]
                        if (t.indexOf(vk) !== -1) {
                            // Sinonimi noti per stati
                            if (fd.key === "STATO" || fd.key === "STATO_1" || fd.key === "Stato") {
                                if (vk === "nuovo") { matchedValue = "Realizzato"; matched = true; break }
                                if (vk === "presente") { matchedValue = "Esistente"; matched = true; break }
                            }
                            // Campo Si/No: se il nome viene menzionato, prova a vedere Si/No
                            if (fd.options.length === 2 &&
                                fd.options.indexOf("Si") !== -1 && fd.options.indexOf("No") !== -1) {
                                if (t.search(/\bsi\b/) !== -1) { matchedValue = "Si"; matched = true; break }
                                if (t.search(/\bno\b/) !== -1) { matchedValue = "No"; matched = true; break }
                                matchedValue = "No"; matched = true; break
                            }
                        }
                    }
                }
                if (matched) {
                    d[fd.key] = matchedValue
                    propagateValue(fd, matchedValue, d)
                }
            } else if (fd.type === "text") {
                if (fd.auto === "length") {
                    var lm = t.match(/lunghezza\s+(\d+(?:[,.]\d+)?)/)
                    if (lm) d[fd.key] = lm[1].replace(",", ".")
                } else if (fd.numericCombine) {
                    var triggered = false
                    if (fd.voiceKeys) {
                        for (var kk = 0; kk < fd.voiceKeys.length; kk++) {
                            if (t.indexOf(fd.voiceKeys[kk]) !== -1) { triggered = true; break }
                        }
                    }
                    if (triggered) {
                        var combined = parseNumericCombine(t)
                        if (combined !== "") d[fd.key] = combined
                    }
                } else if (fd.metricUnits) {
                    // Parser metric: converte "X centimetri", "Y metri e Z", "X.Y" in metri
                    if (fd.voiceKeys) {
                        for (var kk3 = 0; kk3 < fd.voiceKeys.length; kk3++) {
                            var trig3 = fd.voiceKeys[kk3]
                            var idx3 = t.indexOf(trig3)
                            if (idx3 !== -1) {
                                var after3 = t.substring(idx3 + trig3.length).trim()
                                var v = parseMetricValue(after3)
                                if (v !== "") { d[fd.key] = v; break }
                            }
                        }
                    }
                } else {
                    // Text field con voiceKeys: cattura numero o testo dopo trigger
                    if (fd.voiceKeys) {
                        for (var kk2 = 0; kk2 < fd.voiceKeys.length; kk2++) {
                            var trig = fd.voiceKeys[kk2]
                            var idx = t.indexOf(trig)
                            if (idx !== -1) {
                                var after = t.substring(idx + trig.length).trim()
                                // 1) Prova numero
                                var nm = after.match(/^[:\s]*(\d+(?:[.,]\d+)?)/)
                                if (nm) { d[fd.key] = nm[1].replace(",", "."); break }
                                // 2) Cattura testo libero fino a 80 char (vale per qualsiasi text field)
                                //    Rimuovi parole-chiave finali tipo "fine", "conferma"
                                var clean = after.replace(/\s*(conferma|fine|stop|cancella).*$/, "").trim()
                                clean = clean.substring(0, 80).trim()
                                if (clean.length > 0) { d[fd.key] = clean; break }
                            }
                        }
                    }
                }
            }
        }

        // Deep copy per garantire reattivita' QML
        plugin.parsedData = JSON.parse(JSON.stringify(d))
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    // Propaga il valore agli altri campi indicati in field.propagate
    function propagateValue(field, value, dataObj) {
        if (!field.propagate) return
        for (var i = 0; i < field.propagate.length; i++) {
            var targetKey = field.propagate[i]
            var targetField = null
            for (var j = 0; j < plugin.currentFields.length; j++) {
                if (plugin.currentFields[j].key === targetKey) {
                    targetField = plugin.currentFields[j]; break
                }
            }
            if (!targetField) continue
            if (dataObj[targetKey] && dataObj[targetKey] !== "") continue
            if (targetField.options && targetField.options.indexOf("Si") !== -1
                && targetField.options.indexOf("No") !== -1) {
                if (value === "Si" || value === "No") dataObj[targetKey] = value
                else dataObj[targetKey] = "No"
            }
        }
    }

    // ── VINCOLI: required condizionale e null-when ──────────────
    function evalCondition(cond, dataObj) {
        // cond = { field: "X", values: [...] } o { field: "X", notValues: [...] }
        if (!cond || !cond.field) return false
        var v = dataObj[cond.field] || ""
        if (cond.values) {
            for (var i = 0; i < cond.values.length; i++) {
                if (v === cond.values[i]) return true
            }
            return false
        }
        if (cond.notValues) {
            if (v === "") return false  // se l'altro campo e' vuoto, condizione neutra
            for (var j = 0; j < cond.notValues.length; j++) {
                if (v === cond.notValues[j]) return false
            }
            return true
        }
        return false
    }

    function isRequired(field, dataObj) {
        if (field.required === true) return true
        if (field.requiredWhen) return evalCondition(field.requiredWhen, dataObj)
        return false
    }

    function isMustBeNull(field, dataObj) {
        if (field.nullWhen) return evalCondition(field.nullWhen, dataObj)
        return false
    }

    function getConstraintViolations() {
        var d = plugin.parsedData
        var missing = []
        var conflict = []
        for (var i = 0; i < plugin.currentFields.length; i++) {
            var f = plugin.currentFields[i]
            if (f.key === "OBJECTID") continue
            var v = d[f.key] || ""
            if (isRequired(f, d) && v === "") {
                missing.push(f.alias || f.label || f.key)
            }
            if (isMustBeNull(f, d) && v !== "") {
                conflict.push(f.alias || f.label || f.key)
            }
        }
        var def = plugin.selectedLayerDef
        if (def) {
            if (def.photo1Required === true && plugin.photo1Path === "") missing.push("Foto 1")
            if (def.photo2Required === true && plugin.photo2Path === "") missing.push("Foto 2")
        }
        return { missing: missing, conflict: conflict }
    }

    // Parser numerico per GIUNTI/PTE naming (con accenti italiani)
    function parseNumericCombine(text) {
        var t = normalizeItalian(text)
        var parts = []
        var consumed = []

        function isConsumed(pos) {
            for (var c = 0; c < consumed.length; c++) {
                if (pos >= consumed[c][0] && pos < consumed[c][1]) return true
            }
            return false
        }

        var re1 = /(?:da\s+)?(\d+)\s+a\s+(\d+)/g
        var m
        while ((m = re1.exec(t)) !== null) {
            parts.push({pos: m.index, val: m[1] + ":" + m[2]})
            consumed.push([m.index, m.index + m[0].length])
        }
        var re2 = /(\d+)\s+e\s+(\d+)/g
        while ((m = re2.exec(t)) !== null) {
            if (isConsumed(m.index)) continue
            var ai = parseInt(m[1]), bi = parseInt(m[2])
            var op = (bi === ai + 1) ? ":" : "-"
            parts.push({pos: m.index, val: ai + op + bi})
            consumed.push([m.index, m.index + m[0].length])
        }
        var re3 = /\b(\d+)\b/g
        while ((m = re3.exec(t)) !== null) {
            if (isConsumed(m.index)) continue
            parts.push({pos: m.index, val: m[1]})
        }
        if (parts.length === 0) return ""
        parts.sort(function(x, y) { return x.pos - y.pos })
        var vals = []
        for (var p = 0; p < parts.length; p++) vals.push(parts[p].val)
        return vals.join(",")
    }

    // Converte espressioni metriche in numero decimale (in metri)
    //   "75 centimetri" -> "0.75"
    //   "1 metro e 20"  -> "1.20"
    //   "0.75"          -> "0.75"
    //   "2 metri"       -> "2"
    //   "1,5 m"         -> "1.5"
    function parseMetricValue(text) {
        var t = text.toLowerCase().trim()
        // FIX v35: leading-zero "035" → "0.35", "012" → "0.12"
        var lz = t.match(/^0(\d+)(?!\.)(?!,)/)
        if (lz) {
            return "0." + lz[1]
        }
        // 1) "X metro/metri e Y" (centimetri impliciti)
        var m1 = t.match(/(\d+(?:[.,]\d+)?)\s*metr[oi]\s+e\s+(\d+(?:[.,]\d+)?)/)
        if (m1) {
            var meters = parseFloat(m1[1].replace(",", "."))
            var cm     = parseFloat(m1[2].replace(",", "."))
            return (meters + cm/100).toFixed(2)
        }
        // 2) "X centimetri" / "X cm"
        var m2 = t.match(/(\d+(?:[.,]\d+)?)\s*(?:centimetr[oi]|cm)/)
        if (m2) {
            var cm2 = parseFloat(m2[1].replace(",", "."))
            return (cm2/100).toFixed(2)
        }
        // 3) "X metri" / "X m"
        var m3 = t.match(/(\d+(?:[.,]\d+)?)\s*(?:metr[oi]\b|m\b)/)
        if (m3) {
            var meters3 = parseFloat(m3[1].replace(",", "."))
            return meters3.toString()
        }
        // 4) Numero puro (es. "0.75")
        var m4 = t.match(/^[:\s]*(\d+(?:[.,]\d+)?)/)
        if (m4) {
            return m4[1].replace(",", ".")
        }
        return ""
    }

    function buildLineWkt() {
        var coords = []
        for (var i = 0; i < plugin.lineVertices.length; i++) {
            var v = plugin.lineVertices[i]
            coords.push(v.x + " " + v.y)
        }
        // v37: MULTILINESTRING per layer GPKG di linee
        return "MULTILINESTRING((" + coords.join(", ") + "))"
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        var def = plugin.selectedLayerDef
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }

        // FIX v31: Validazione bidirezionale (required + nullWhen)
        var v = getConstraintViolations()
        if (v.missing.length > 0 || v.conflict.length > 0) {
            var msg = ""
            if (v.missing.length > 0) msg += "⛔ Obbligatori vuoti: " + v.missing.join(", ")
            if (v.conflict.length > 0) {
                if (msg !== "") msg += " | "
                msg += "⚠ Da svuotare: " + v.conflict.join(", ")
            }
            mainWindow.displayToast(msg)
            return
        }

        try {
            var wkt
            if (def && def.geometryType === "line") {
                if (plugin.lineVertices.length < 2) {
                    mainWindow.displayToast("⚠ Servono almeno 2 vertici per la tratta")
                    return
                }
                wkt = buildLineWkt()
            } else {
                if (!positionSource || !positionSource.active) {
                    mainWindow.displayToast("⚠ GPS non attivo!"); return
                }
                var pos = positionSource.projectedPosition
                wkt = "POINT(" + pos.x + " " + pos.y + ")"
            }

            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            // Foto principale (Foto_1)
            if (plugin.photo1Path !== "") {
                var photoFieldName = (def && def.photoField) ? def.photoField : "Foto_1"
                var fi = fieldNames.indexOf(photoFieldName)
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            // Foto secondaria (Foto_2), se il layer la supporta
            if (plugin.photo2Path !== "" && def && def.photoField2) {
                var fi2 = fieldNames.indexOf(def.photoField2)
                if (fi2 >= 0) feature.setAttribute(fi2, plugin.photo2Path)
            }

            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}
