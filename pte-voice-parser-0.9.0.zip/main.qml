import QtQuick 2.14
import org.qfield 1.0
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
    }

    QfToolButton {
        id: micBtn
        text: "PTE"
        toolTip: "PTE Voice Parser"
        onClicked: {
            mainWindow.displayToast("PTE Voice Parser - funziona!")
        }
    }
}
