import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null

    property int okCount: 0
    property var parsedData: ({})

    // ── DEFINIZIONE LAYER E CAMPI ────────────────────────────────
    // Ogni layer ha: name (nome nel gpkg), label (etichetta), icon, fields
    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            fields: [
                { key:"Label",      label:"QUARTINA",   type:"text" },
                { key:"DESCRIPTIO", label:"TIPOLOGIA",  type:"picker",
                  options:["PTE Muro Esterno","PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"] },
                { key:"ArmadioId",  label:"ARMADIO",    type:"text" },
                { key:"Posizione",  label:"UBICAZIONE", type:"picker",
                  options:["Muro Esterno","Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Palo","Pontile","Pozzetto","Seminterrato","Sottoscala"] },
                { key:"STATO_1",    label:"STATO",      type:"picker",
                  options:["Esistente","Realizzato","NON Realizzato"] }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄️",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"Label",      label:"LABEL",    type:"text" },
                { key:"DESCRIPTIO", label:"NOTE",     type:"text" }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰️",
            fields: [{ key:"OBJECTID", label:"OBJECT ID", type:"text" }]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte", icon: "⛏️",
            fields: [{ key:"OBJECTID", label:"OBJECT ID", type:"text" }]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"DESCRIPTIO", label:"TIPO",     type:"text" },
                { key:"Label",      label:"LABEL",    type:"text" }
            ]
        },
        {
            name: "STRUCTURE", label: "Structure", icon: "🏗️",
            fields: [
                { key:"OBJECTID",   label:"OBJECT ID",  type:"text" },
                { key:"MAIN_SUB_1", label:"MAIN SUB",   type:"text" }
            ]
        }
    ]

    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []
    property string lastParsedText: ""
    property string photo1Path: ""
    property bool lineMode: false
    property var linePoints: []
    property var lineLayerNames: ["RACCORDI", "TRATTE INTERRATE"]

    // Preset PTE con icone base64
    property var ptePresets: [
        {
            num: 1, label: "PTE Interno",
            icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAAA6GlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8zQAETA4MDLl5JUVB7k4KEZFRCgxIIDG5uIABN2BkYPh2DUQyMFzWDSxh5cejFhvgLAJaCKQ/ALFIOpjNyAJiJ0HYEiB2eUlBCZCtA2InFxSB2EAXM/AUhQQ5A9k+QLZCOhI7CYmdklqcDGTnANnxCL/lz2dgsPjCwMA8ESGWNI2BYXs7A4PEHYSYykIGBv5WBoZtlxFin/3B/mUUO1SSWlECEvHTd2QoSCxKBEszgwI0LY2B4dNyBgbeSAYG4QsMDFzREHeAAWsxMKBJDCdCAABy2DaEG9YP8QAADCJJREFUeJztnXmT28YRxd/rIfeQZMt22alU5ft/pFSlLOuwpLUs2dLq2oNLTL/8MQeGhyRy5aDCZF5xuSAIgOQPjZ7uHnKGkvDfL6WboLwEYryBAABCLMtlJ8Lr3mVl2sjSvYPePG2AQTbuUjeux/TmJsiA4AiiNSAliBDhlt/R7D/O6H9c3PHpAwXNYoH1Ib74mbG6T95BkgvS+BwhhzhaOcB2Qe0FxvEyU1o1vjsCgB+iRbP+05qLqKy5sTnHbVBIZL9BAHK4KwoSCIjj02UvNq5qDXSWp2WxOV/pvZCHCHoUNx5+2ZybTTW6dwOC0ZjPnQFhpJxcs60ev3ptr8tCKC3Ap97HAYFuLuW1Fm/10239qAldASaDKAEGC2NLt7HL1kMZNvbY4UQfEOg1rXwyba5qzkxDOflOEU4BcgCwsO2Qf7EOF/R+KpQdEqHsy2P062u/WvpiyG7aCIMCEOqugkhnPRCJHBK6wx1IJ9Egy95dUHq2aT4OCnQKBQCAO1oflUOGHETIMQw0IsxA85ubqz9ef3z2+/Wf58PlQhIDNTMEygCmgAR0UDTRCJhoDkQxUjGHKyJhACmrjWQJRnhwoHdCuxF11JMjwOWuOBABgaBpOVy9/PPNP//17tHTm7cfSNjRHEdB86BAQB4Fl0WYGMBgoDksAktxAGL2SKKJAKkaltAJkSqh4QGB/qT2SW0dcqhEd8OwfP/+6sXLy8e/Ls/fh1mY3zkNp8c4nmMeBChGRCgqe3hLqeQSXII3YMwvnrJAlOgQgBHkGNwdBujNWIOjudb8Oafi26nX3L2NEBw+YLnkzSLcLIPrNMxOT+4c3btjd09wcgTSoyOKESYaYAQYYUtgqQSaIgDBVEJCUiAMTgNrpnMQoJO4fq+x4DBukomvrQJG0GYw5LPjkfTZLJzeOT0K8/v373/7tx9PfvjO7t/lnROYwV0RdFEl76GDEVyCA+iA53ymWjSZvAi40pAcDugmrU3y5CMLybB9p6aYtL5WUJSEwNnJ/M7x8Xc//fDtP/4e/v4jfvgW905hAe7w4jcciSjoCA4KphwgCmhAZ8Rcub4OBHSpPLRJy5o5q/7j5to1FfbuMS6XvhwQOZ/N7x2HH77B377HT9/jm1MEQ4xwAQE0ePE8RswIlitDxUenhWzO7ZUlHAboQrmSZfMQrdfVxv2mcv0o/WnweBOXEUOcHfN0jm9O8N1dfH9X906YQTtsBlq+oEiEgDCDzZLPhgDnWIWqzu3wQGPFnIX1EvPn4r6xlUwPU6tYYJCCIhQJzQ2nc9w90b0T3T32O0cMNDd4lM1gs+xAaLK5bO5NHj42HMUK1LyntHgAoPWJW6uVkk9byM/tplYDknyCFCijKBGaGY6OcDzH0ZzzwJlZIN3hZKCYIsLgsIhZiqVVCk+s5cCS41efZgcEulVrvPq8Lbc7sdznZK2YYLAU8IqUmUJACDQCohwOeHIdTjpgysVRdzDC1LAGGo+dzvWYtIOHArr1e60D2WPn6jWZWyyAMMKoCtoMZuk0CFJC6irpXcr6BDjFphqQbsx5YV7JaggHY9GroXP+J4ClDN9utt1tF4uW6ucngAza6KlZMwMNZrAgBmcUSZIIgTPABEsHMmoO5u4UgmAAARrl2cap1TN8AKBRuBlQooXanFOf9yGsppwC22y/LFYo0pFMtu0PSO0kHUbAEISA7CtEyADAa38Oi/dYu+baN38YoEuyopq1tKC9gTlqJcxqWHONJhxIvYalFU3xHwkjQSMYBINMrL3bYq3L5eNivHDKK7Vv6iBAF/vI1syU8Nbigq1R3VLxKMn5eKZqoEs55VDi7UoNGWmEzYLgAEMKH1IKD3hzXY2uSjAKWnkv40k+CNBJbbYnYEs/7A7iOoJ0sLh6EyiaBYNkAK34lnqQmomMzUaJIrfrcEDnVA7543G8cveizPailkFGJ1P85iw3gxstlL6Y4DDkylEpPLMNfGoGZCmsY2PLB2fRSSXEStra07I1nxHLuTGOSR3pNNFyiEc4IUusCcuvRZrooknKgYgzO4nqOli6bdv4qL784YH+SyWmyEy5eFq/EEY4AYOSjyZEOtrAcLWkwg2ntK6DA72lmVt58lO1pHET1tQQgoEGBtKabKX0mNeaYV4oMUvNVsaoo9z/D/ho1iZwdBz8EtbNo6yU2JRdSS4j506U8noZt2ozmO2ZpSVu3khZ+mRMfziggbWQ+LZHWPkCjAFmkMlKSJ1a2m255dbvzuyqgwBd2/Q1e+FKORIbl3Kza2m5st3mZ1MLSRgdGOhL+FBAswbfWw675Txw5ZmNS+0gQKMmF1vWfn4V1x6kokbt9iIBo0SnBmTQjuRDin+hlQOtQGzWbF4CG+/sUEBnrZeQbqOtZ8ubdMVXuWk1N7qlDgP0eh7WaIxlUZJk7GLq7Vq1EUatCao46+qxqimvuoltBz9ci97sWNmeqnwuENnuPkuvSFP/aOuDXwgYdzX22zaiXXuqg55IHfRE6qAnUgc9kTroidRBT6QOeiJ10BOpg55IHfRE6qAnUgc9kTroidRBT6QOeiJ10BOpg55IHfRE6qAnUgc9kTroidRBT6QOeiJ10BOpg55IHfRE6qAnUgc9kTroidRBT6QOeiJ10BOpg55IHfRE6qAnUgc9kTroiXQwP3/779Lnxsva/nO5Dvq22sqT679LrA866Nvqcz8c3cK6g95DI8DNn9XWoVbGnzrX5/tQP7dTS/mTP04fR2rrFv11+txPxLechA56H7UD3q2tb0dVWg9IhA76a7U2ahXHgcTWTLqD/jqtjfeRh1AxlskO64Yd9G1V/EMars2Zx65JYYblQXlH1h3016mMTOPAMA4x1o7pmO876F20mXGrGbWNIjzPflOdRR1tSx30rdSGyXnU8zz1zeYIZWqMuoO+nZoMcDWm+9QwVh30HipDpY8WXcb+LXO0FNfR+uikDnoXtcSkEsXV8eoBTyNv1tkLK+g6MFkH/deIZaTjFnSrDnoPsQQSa8U7lpRlbUzeutAteke14UOKNsaUr4zDqzJD1kqr2KOOr1IJkHORqWHaWPmqOuhd1biLbMRCGY0eLJPx1PoeaiW616P3VlNmrgN3Z4sunS8lsm5qeEkd9O20kZek8WfVBHRc2a6D3kXruXViOJq2Susore1WZprroG+l7cNUa2WCmLUtOui9JUFKuTgtT+bLNLL3eAbqFAHuaYf/e9CSMrlPjsmtMk1tnptEchcAs5V5pCSWE1CaQwnRFSPc+3fv9pdymSOfo2Z6Z7WzAQh52lR3uP/fW/ReElAmyHFA0hBlebYFMzYGnmZud8HTnHzdR++iaqcpRCbNACG6u3sUSFqgGSz5Zjmja4jp60okQOug91BOrtPUncrzekrKE4xXi071peRWgqUptjroXSWMRSMCRgQzBbgrz2Y7htGlz6VOiNFB76SmOzB55yQzzmAe8mzjKEZMADSa5BFDhBzdR++nPAmRaqsYjJZCjpj+CSCMmAWYcRGxWOB6gTh00F+SSnd2iSjc3d0BwSyYGYyZvhgdADhL7gLXC7w5x/v3uL7uoHdV8rsOQa4YBScsMKSQxCS4KKcAOWRa3PDtO5y9wKtX+Pihg95bTLM+pWSEHGe1N6rO3TlEfvyo31/5k1/97Ezv3nbQO4griySDWf6iUnS4chJoAUZFcXmD6yu8+N0fP7l68Mvi6dPh/LyD/pJKCb80gTAaDZDBI12AlwnBCUHLJS+u8PoNHj9ePnhw+eDBxfPni7fdoveXgTCDABcQcwEphdjDwMsLvD7X0+fxl4dXDx9e/vrk6uXLxYePHfQ+Up16ten7NsgAOeOAiwv8+RrPzoZfHl49+Pny8aOb387i+bl61LGXVn55lVcQApYDFte4/IhXf+Dp8/jo8fXPv1w8+Pnmt+d6+2Z+eTFT7KD3l0piUilffsSbN/rj5fD02fDo0c2Tx1ePn1yfPdP566PFZVA065nhTlr5Ag1SPSmZtYOLG759j7MX8emTxcOHV48eXj97evPiTG9ez6+u53E4ImYd9C2l8p0CCTdLfLzE63N/8fLm+W+XZ79dv3oZ357Pry5mUcfEccDMrPew3EpjtzcQHYsFLi71/n18+2757t3Nhw/D1SUGGTAzzoLNg/0brm06tHIAzjMAAAAASUVORK5CYII=",
            values: { "DESCRIPTIO": "PTE Interno Edificio", "STATO_1": "Realizzato" }
        },
        {
            num: 2, label: "PTE Muro Esterno",
            icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAAA6GlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8zQAETA4MDLl5JUVB7k4KEZFRCgxIIDG5uIABN2BkYPh2DUQyMFzWDSxh5cejFhvgLAJaCKQ/ALFIOpjNyAJiJ0HYEiB2eUlBCZCtA2InFxSB2EAXM/AUhQQ5A9k+QLZCOhI7CYmdklqcDGTnANnxCL/lz2dgsPjCwMA8ESGWNI2BYXs7A4PEHYSYykIGBv5WBoZtlxFin/3B/mUUO1SSWlECEvHTd2QoSCxKBEszgwI0LY2B4dNyBgbeSAYG4QsMDFzREHeAAWsxMKBJDCdCAABy2DaEG9YP8QAADR9JREFUeJztnelz28i1xc+5DVKyvMqe8Zo4Hk8qleRDqt7//2e8l1Q8S2biGVuS40W7RBJ9z/vQDRAkRW12IWGqT6koLE2Q+KF5+96LRjcl4T9dUvMHCBABgoRBBrHZDHRPhQABE0wCHHRw5qCAIMUR4olhYqQxkGvwAb2CEwIMoMOIkI4jgOm7yEGRs8c8R9WXw/GfrqVISMJopIV88fJVSnutu5aPRNKaK345rRjoVGXPO7npPuVXCQDZKTGt+CIIGhloJANgICXCkapvPqIgKf/6mQVSqYJfQqsFuqWlWV6d/WwLABQkUASgxJTZ9ii/AACNVHMlpNoxIWoKhEMSAiBJ7h4h0cxCgKUL4Bk0px87/00BrBropCUVmnM71dphtDW6oYwWjhEMAACHhBhZAxNDTQJwINlhUgJdkjO9Cc2FTKDnrvpCJVgV0Fyg29ReLmzOaijLmy0GAJ7bVDK1delfVKx9HDkhJ2uIAdHyMQKQLAoscAivIcABd1CAtyZq5tMXqvZKgO5SVrNK8Ky2aNGzmJ60utVZalfc61G9tz85OLERhtgIdhtYgwgAQ8N6wJohOBQRa9Q15HBHNuTp2O1V13QVAHOBlQCdxNx25eXOr5M4azFpjjU7aCI8AjXGI9//dLi1dbj90Y/qm+H2zfV7FddVK9a1BsRahXWLIdaqY6xR13Q3ucnJ/ybQao3EjF1IP918Hmz85inrFrF3juIwQCZAk8g4RhzhYD++ebv76ru3P76e7I/uDG9v3vpqENZHp5Pj05MJXUPzNdaMtY9jrE2qgEoKEJkbVM1ZjZUEjYXamz0uREzdMGsoc/oGNefZECfhAiVBiKgnOB3h056/2dl/9ePO//79eO9k89ZmfPB0bbhxeHyye3hw6pNYwYeoVU/i2D1W5NDC0BgI5saQDej20rdmLW9ZEdBL5EBszix0Xs97R/dXIaF2jGodHMf3nyY77+vDkXMdD4C1ITxiEhQjKmAAKNCCOS1YCJWZGVPTqkWs0/ZDqwi69VhFdgyEZ6MAa0501mjP2W0BIgESZggDVGu0aqhwm2Htxsbmo4f3//D7tUdPbk7q2we7Yx9paBrQ4e61pECrzALN0lfqmg4KMx+N9se4CqBzAzafyyCmdhnNcuen2yK26ebkaKRrQcIqDIS1G7Z+88bGzXt37mqw9vW33z76n7+svfhGYjzejz7meuDQ1DpzAmlczK7gvJh1FUBnnQE6TI1xtxnMBTqIp75u8qoFQAYYrEI1xGAYhuvDjQ1u3Lrx+OGtF7/l75/CgNOH8DHWAwacuVogZP99oNuWpuOlSQQMHDTOcNdMcrEuJ7aSS1IK6wRnak/lmESduEhMBsFvDMIAALARECtUi/bXmnjysloJ0MgnOZswSrGzZr2p1tsAgCa10Xlbk5sQzIUIRKF2r30U41GM8Hiseuz1jfSGOMbkBBIqQRHucAABHEADgNMPTlrxGn2euhmOrivX7D0jdGyCFmZSIoBIjkkYakOkuyIEqY6awGV1C5qgQGPyJ5eAXsx3rRTouYRHN8mQ9jexY9dedFknRwOgPHkIjfNNE6nKGAIqY2WkgXCaK9BchuQ0U5ZqtFBxOehFrRDoc1PsHVcDZ1WofAjSctoNMoMZyJSfo9FSXtpIy7dOSEMqZvkiEtbkmcIZDfByrQroMxzUpUXnC8wk1tp/ahBnz7p5Yw4sc7OX/e1OjqUbhF5BKwE6JRTmWOuMU+00gp1iac9M+SnXRFminNLU4jfZFUMwGHOeH2dFQGd944UtKwEa6OaPmi3nnO45NXoKnClFkcIQp2QSJDbBHjJoMwTmqGjJJ1xCqwI66xLxwTL7vKBMWSnpkUBrFjRAKlVnw4wzs+TDl2vFQCe1qVGkGyVdR/nyoDGljOzl6SzHuBvnY572pbWSoP+turLRSLKLixR9CRXQPamA7kkFdE8qoHtSAd2TCuieVED3pAK6JxXQPamA7kkFdE8qoHtSAd2TCuieVED3pAK6JxXQPamA7kkFdE8qoHtSAd2TCuieVED3pAK6JxXQPamA7kkFdE8qoHtSAd2TCuieVED3pAK6JxXQPamA7kkFdE8qoHtSAd2TCujrS3MrWljtbCnPGV5HSx8aXf40aQF9sbpPj3fGCOmOxdeMtbf8sdoC+spSZ3ghdUZIWBhdK5dOKja6J5UafR1xYeHCogX0xWppzg78Mb88v4MzGwvoLyktDDbRGu0C+moiOiORdTaLXYfkjBHxCuiLpXkz0A531axxZjYYnOXmFdBfRmpGsk6en5o6X0B/nmZjk7Yuex6ObLbCAyigv5Q64zO1lGdYF9BfRppfnK/UBfRV1G3p2nH0GgejqcvZNHfaT6GA/lwtGQOWzWjebEaTLKA/T/MO9Rzr6fxwBfTFmobgnN/SbmxeBDBNHcfuAKgF9HW0UIvbzZi1zgX050oLy1wg21kmCujLaO4OSzfg6xK3TtOX+Bb37nO1aDkW7MZ8prqAvo66g37P5Zs6E+3MXI4C+jpqQdrMliX3WwQU0J8hQXkGP2vHqm/2NBPFTLcV0FdWiqpd7nK5E4QZLTDn8Rr8SNMs5za0gL6GBLjg7rXHSBCozMg0dZcn0Eygyz3Dz1c3M+pwF8lO8n/uXm0BfbG6PsR0wiLCjADpBCR5irrz7ONo59HJ7y+gr6DOnSoBIC0EgGmKEZdIpNmKLDuAHaevgL6yHErzRxphMBgQHS7IM2VALrlANDOLsIC+WHMhuEsxTXXLbD8ETqe8T36He4wOAsEIlhp9BXW7knp24miAmpsqnT6lkuTuTQbVCujrKDVziWeE59nN2IIWJBJsZzJTucNyOXF+lQGWPI0olxAQKgaQqVVkaicHpmbaIkgF9BWUTIcxxSaIyUIIyc2jmOKY5I5YMEFwlwsooK+jNMOhSGvCbebpbaE8TTMIMjWTycwU0NdQSmAYaWYVpWa2w7a7EqCI5N6l6eQK6Guo7QBGWJpb1dq+pMlxhueZgMnc9bT40deQJBcE0Wi0kGLA1K8xTWKbsx/Kk8TTwAL6Ksr3DAV3B0EnjZbzzrFJcQhukMOjBMgL6Gsq5TByGOh5buXmTqxywomEjF6jjilxWkBfTQQCSaM75HK5iBDMko/hEXWdokWQrB0nI4zGqGMBfTUxx9pGInr02lNbx4oE4DXqiQCZMUYcnWJ3FwdHGJ0W0FdW8pBJiCa6Z7MtUMnDzvnR0Xjy4dPxmzfj9x/qo8OVAb340NnMPOGLhS51SOYDcX6a6o6aMLp7tzW7GIbKzN0UOXEFAFQ1MAnjGnuHJ2/ebn3/w8e3W8d7u6sBeq4TRTrPM54HPqsD0VK1HZuTd5bXNPucdw430ESA6ZqktTQ5O90wmbCuJUMwiRiPsbuPt9v7P//y7ufX21vb+/v7qwF6ThdWXJ1TZulF8OZ5H+8UShunF1pAzL4GKFbZjghIuQ6G0UQfd09f/3Lw6vsP//zl9NMBo6rB2oqAFoCFWrzwjJkac6LsZ03V/hSyJWizy01/cVFK9RUdG6IIxPbD0rsjVMMhDy64AgJkAoID4wk+7U1++nX7//628/2PJwcHN6q1O4/v+XBVQGP25uh5pdLlWF5ueik0tRMJtwEm0ZvEEBZqtAQXo5sr1oqREycH5JrcMJ5g9xC/bh3+/Yedv32/s7W9fvvWw6dPnvzm2XDz/uqAvqKWtpQ5aQ/FiPSXcLPbDWNqOjgLGnAiGqMs0iJNRhmEusbu/snPb06/+8fOqx8OtnYYdXvzwf3nL+5/+xIPv14d0Eu6fwMzJrlJVi4pRdBIAVGIEXWNGHP9NTasZ827RHmmTRhQZU/aUDHITYZJxNGJv9169+q7d399tfd2hxN//PjRo5cv77x4gWdP8eDBioBe1rRpZoGNlT6zOKfhBvK9j9SrSMm5MMkgE2zKmpY8EiqFJbnTRkhvic6J4+QEhyNsf9z76ad3//jp7bsdyJ88ffziT3+8/+c/hufPsHkXGytioxcf3et2rJ9WYjUbZ0gTnZJqX81gAQxAgMydtQNOpXtVAABHiKgCjGncgpiOI0Sirnk69v3D0fvd4533p2/fffh1a/9g325t3Lq3+dU3Lx/8+U/hm+fYvOuDKpqvAOg2/xuZHQIC1vwBAJvGr4lhUoyWFpvDEEq3pyFQJEOFiqgFVpJ5RIyAwzUFHREiA2mG0HSqAwDUwGmNvZHvfDp8/Wb7n68/bL87Ojwyq+7/5ulXz59vvvwm/O4Z7t/B+oDupskKgEbj3DrgxIJvNlOjk86s0UiOhkvJAISAyhAiGCB6RHTAodyRCwAcFhkCDAjZ1CTLVDtOhcOxfzw82Xr/4Zc3v+78K5o9fPTowdMnj17+7uZvn+H+XawPQKdPLPrKjKmkLu5OV8KrHmXqJ1tqANMPo/GfNXXZkR1zpng7R5JOuMmpGjiNOjqd7B8efdzb3d07PD3FcHBz8+6dr78aPLiHWxuxMk8pvTj+f6L+6dmVeLhVAAAAAElFTkSuQmCC",
            values: { "DESCRIPTIO": "PTE Muro Esterno/Palifica", "STATO_1": "Realizzato" }
        },
        {
            num: 3, label: "PTE Sotterraneo",
            icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAAA6GlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8zQAETA4MDLl5JUVB7k4KEZFRCgxIIDG5uIABN2BkYPh2DUQyMFzWDSxh5cejFhvgLAJaCKQ/ALFIOpjNyAJiJ0HYEiB2eUlBCZCtA2InFxSB2EAXM/AUhQQ5A9k+QLZCOhI7CYmdklqcDGTnANnxCL/lz2dgsPjCwMA8ESGWNI2BYXs7A4PEHYSYykIGBv5WBoZtlxFin/3B/mUUO1SSWlECEvHTd2QoSCxKBEszgwI0LY2B4dNyBgbeSAYG4QsMDFzREHeAAWsxMKBJDCdCAABy2DaEG9YP8QAADXdJREFUeJztnWtTG0myht/MagEGm4sxBjPYsHti1vP9nP//HzbixO76Ph7AMAPGwgh068r3fKiuVqslzG1CZzqi3lCIVlephZ5OZWVlV1cJSfz1xcozCAFAAhSw3A0AkOKhUn1jlCc8SYgADnAKCIABBx07/4rz7zI0bS1i4QncPIzIPYwQFMcjoEAmyBQuvBcgYPG5/ESr/EMAgOxPpPFXEkdf8YZaHsM+O53e17PB6Vf081ZrsfXoUtx8PrR8OKCZCFRFBBShgip0QgUFAJRwBkc4gwJCID4DRR00EPT03x/jN5IR4LKmjJ6lfAnSYIZ8gMtLf/L14vN+e/8gv+wttBYXl1Yzt9DvD7v9Xu5zCsSJOIEIVKgwCZ9HQByhhoxwhDB+GOOPUIqNJoAeEYt+osKSQPxSkHKDk+4EkFge3m4Gn6Pfw/m5P/zS/teb/f+86Z9fPl54sra6MTe3eNXtX1x1evnQi7Elmqk4BxUCRpIEqBCNoJVQjtwJBSCssRZ9nQgg2Nl1LoOQwqcX/tZgQwz66FzayenVh1/P/vc/3fOOX9tY2CYfr/X6/avO96thP1djC9JSbWWiSsK80VNIhQigBhcoj4MuHgAaBrr44U/xHrEN5PWUycAaMEAD6NCuCpB71xvMd/vwXFp8/OTF9qPNn+a8zV9+7w37Xg0tIBOdc6KOBD3pCSK0pmLRli2Crp5RAZoBWqZsRRMuWr34mMa5cKaBNUvXIwBE4DLMz+vC4uLS4/WVVVvJ1n9+vfU//72w91/eZb57led9KJERDpI5OA0UaRVPVm7EYGPUYsTnJoD+oSbawB+oFooooFCHrCVz83OPFh8vr2B+cXX31errf7jXv2BuDr0e8gEURUuXKUQhMoory7iTEx+FZoKufJHCHqtGgymg6x5GCo8hhGgw/8DLCwhCTDOZX8DSoltdxvIcAMwvYDgPJ3AP/f+bAZrjRhNjiFG4OlaC6wpEoBpfCRQUeCA3Dm2YW9cAoKcYCOfC24aGwQCZwhQAtPyHYv+l/P9uUjNA/xlSQHRsjwACAzxgyCl9CESGIl5IGknkQ8sHgkwYT1CVKW/XLQLQONA104l9j8q3lap3nFQZS5eHElCCP/EiUDGndA4iArDlQIfMQUvfweJpevhzrRoGOqjWG6n8nVZSFEi1X8hRZQmhMKGU0PdTcSoQiEhLSGrmRB1i7FI/9O3USNCzUHALk9HMPRgDqLj3pJpiUH5fsjUl0Neo5PsnZZET6BkpgZ6REugZKYGekRLoGSmBnpES6BkpgZ6REugZKYGekRLoGSmBnpES6BkpgZ6REugZKYGekRLoGSmBnpES6BkpgZ6REugZKYGekRLoGSmBnpES6BkpgZ6REugZKYGekRLoGSmBnpES6BkpgZ6REugZKYGekRLoGSndlXWzyts2ZXIXKrd9Exy/7b96+0sCfXfVbrFnvbC23cD5Ov4i4gRrTJlgCAn0/VWdNKJkrXGnTKlVKoG+o1iZf6063UIEzYkTEZRA30u1WVGmzRWSQD9Yk/fSTmsPE+gHq3Yn/vhLGZ9gotxIoO8oqZCdNp+TTJyIoAT6LiobPZ02USQhqPdZyu0E+o66frKs6u5Jo06g76ByZs6aps6dUjsjCfTNGs2CGTdqThnlLIYxlJ705An03TTZ9w4aTddU3VPZSKDvrGoGAxPx3JiPLifUTKBvr1p0XIuUddxjKEYnJIF+qCa5h/zSmNeOZQn0fVRLdQSNzThY5p6QQN9RUzMYk0lpKWc5trHiBPrPkRSzJF87TV4C/RAVIXWYI1yjOcu0SzAJ9IMkBeuCsk6l3KyJuv+akorT+IHfQAJ9e01OY1x6DC1nDZ9my8mi76NqWq4yNzJkcr0MSaAfoDHQJGkEGHoqMs1zSIOWB/n/VnWkEmNv20DQaN5IkQwysdxCXH4njeu4j6o5OSFpRhJiUK1Z9KjrmCz6ISrjjWmjDRBW6yrTSkigHyIVoSrIsEzAKH0XfUu1gUyg7ykBJKzrQsh4DB3WiqoMMwUS6HtLAEBEXLy4Elo9MkQjE8t2JdA3a3LAV1y4qMRZ+AuCxiK8FhUpzgGRQD9Y4x6jWFASIlKz6QT6/gqLBEeHAaPRjCAEAq11XxLom1XrsHDkMRBWYTUQhNFAY7EmUfm+IgOSQN9HrIXPRBFo1McoWRGDJNB3Ve1a4GhYAYMha/gjIiAJQ1irOYG+jarpuolrgSIxmxSypjHABkDQYJ5mYAJ9X9V63gqBBt5x9Wwz0Ip1bhPoO2nq/SkMFixl0xdYE2S56C9EEui7qdrWjbZHI+9YeAyg8OSFv07h3R1VGyNaQrcxZ1JdFhzBdSfQN4vjWBWAje0qcnXFJgVQUILjMIQ1mhPoO6hgWzrpQFlgoC9AAygaxWIcXvTbDQMtExt31OQ1akw0b3c5jJS+OThm6tixQ7GiKaDlmpcyWXzNGZBocQQ55XxVRjKXgfF1B50YtBsDuqJzrhCFKIUkDWSjXMctYN4olp06jLxrWKq64hFC5DvxxrHPHeUw4lClIvlPVwymEYGINww9zGDNAQ3Eq2+3rz2mifEtjDvK4eMFZYvxWfjIkMUwBnbB3BUw0EgjBXBQKGACqlnRP6QgN/QGGA6R+4aAjr/p6ZpSUHe4BMMARCu6b5QAVAAVqLIwUoMZzI+9USx6FtXQv5ZQYOaNIlB1IQFNSp6TQlXmplddnF/g6gqDQUNAB002Vz+y8BssmqU5q0CL66vXWLTFDyvGioYOShEtg2pUMREipKPDD6A38F/bw+Pj/Ns3u7pqFOgbNEZy3KuyCpohApPSaUhpqeUAr/FjIvY+whXBwutQVUSE1NzLwENZuBVVmOHqqnd0/Me7d+0vX7rn500AXYml6nvGXhdZYRm3XIm+PXJkfIMUrZjoqGqJPu6S0o0X+0iCnoSIU3UinhgM0OtBSOckc4Ch18fpWefg8MuHj4f7v52ffWsC6DvqB1FxEVwUwW/kWgk3ilpj4V1oA0Xile2yuoBiEDMY4Q0gPNkbsN+3s/bw8+f24ZeLb9+urrrd4bAxoEMUFVRec44FLAvKfaVb1cKcRSBKSCwQU5jCBAZ4o5lZCHpHnxRCP2HhxcGY1XeEGfKh5XnB2mXiTXp9O/9+eXLSPji4PDxsn562stbm5ubT58+bAFpqroDxqkbddBkrlykeQizEZBCBuMJyBQBNEB6e9EbvvTcxGsBo0QYhVUSFCiKcNXFQEZKWD6zbU6q4TNTJwOO8M9j/0v708fDTrxftb9nC/Prm5vLTtYUnS00AHTW1+zwqkHq1yu5RHjNYKQEyUAY84c28eTNhCDhGPpoATEY/FoGEKDFE0YAonCqG5MVl9+i4/eHT1w8f2odfBirrT9eevXq5tfsye7beJNCIMRnHb528puaPKpQ/ieBeA7QQLVNiWqh6oPJwNOS5WE5QVHRhzlGRE51Lf/z7t4+/Hn/81D46Zn+wvLH+bGtrZWcn29nB+tNmgWbZG7ZopT9CWdse8z6VvQxDX8JwZqFIFXQcE1P5nfgc+QAKaWXiMgw9Li9xdHT16dezz5/PTk+G3i+vrW3tvtrY2320+Rwry1h81CzQd5MUjeHtqqqOHiPONh69GMAQd4uKqANhnU7/8PDq3Yezjx87pycq8nh9fX1r6/nf/7a8vY3VVc7PW3MvZXHUKlYU/XHVt4wS9Jxw86PbqUScSuYkc6rFoDkU6fwYhYfeuZCqlEwBeEPnsv/l6OjNmz/+/fbq95MWsbGxsbS1tbz9YnFnG+tPsfgImUNT0qRBdS8R4E2kMFHtedT8BqfV0EBZNXPiVFSrmScg3KEiIcMPETgVCvo9dC6GR8dnb98fvn3z+8G+Dm1na2v7b3tP9nbdxjO3ssylRXGZEM43JakUFbPst6p5c6pvZNQCp3Bau0NidBAFRAsv7oBBn53OxW+/nb55e/z2/en+wXAwWF15urr9Yu3Vjnu5g9UVLMz5lhPnFIRZM0Bfj0yq4XRp3pWQTmKeY+IYRcgn0JBLrqaWiirxNk3GkeaxtNsdHh8d/ftfH/75z7P9I2d8trG5vbe3vrvrnm9g5QkeL6LVUidx5o6GgMZ01tO9QiyqQJ/aK2c1JU2KFdloGmNnXAkXsqSecAIA/Ryd7zg+PH///uTduz8ODvv9/vbzrd1//Lzz8+uFrW2srmC+hcwhcxJ6lM0CHXWtcU/Nb0iteCxOKy+mhLSmETmYkzmYl3WEhPfwhBHDfNhud48OLz9/OP30sdduLz9ear148dPe3zd/+WVxdxcra5ib81mmzoXOOotYUpsAesRPxnMeZV+ZExiLyyCs9k1qxwyp53ClBAQ86YGc5lkm/kNu2gN5jsEAF53+8dHp+7d/vH978fUky3Rvd2/51avll6+WtrfxdA2LS8gyhSJriQjLOwAadM0waqpFjxnu1O1rLNrKB2lkGDfgR4n/YPJGDHN0u/h+MTw5PT84/H3/YNjvvvjpxc7Ll89+eS3PN2VpyebnkDnNMgkpaaJMXrOBoG/QbQKS8eqVR7h4O3ZxNu73hsEQ3Z7vdLrt9sW3NuFdlj1dX9etLayvQ9RDREVURveFc+Sf/g/V9/NvvAdmnQAAAABJRU5ErkJggg==",
            values: { "DESCRIPTIO": "PTE Sotterraneo", "STATO_1": "Realizzato" }
        },
        {
            num: 4, label: "PTE Colonnina",
            icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAAA6GlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8zQAETA4MDLl5JUVB7k4KEZFRCgxIIDG5uIABN2BkYPh2DUQyMFzWDSxh5cejFhvgLAJaCKQ/ALFIOpjNyAJiJ0HYEiB2eUlBCZCtA2InFxSB2EAXM/AUhQQ5A9k+QLZCOhI7CYmdklqcDGTnANnxCL/lz2dgsPjCwMA8ESGWNI2BYXs7A4PEHYSYykIGBv5WBoZtlxFin/3B/mUUO1SSWlECEvHTd2QoSCxKBEszgwI0LY2B4dNyBgbeSAYG4QsMDFzREHeAAWsxMKBJDCdCAABy2DaEG9YP8QAAFcJJREFUeJztXWuX3LhxvVUg2T3vGT03uxsd22v7xJ+Tj8nf91+wfTaJrF2tXqOR5j3NJlE3HwCQILtnJI29zuG66/BwSDYI9lwUq24V0ICQxOSE2T6IAgQFBDxAwNLnkvZxI4SQ1qNe6rJB63F63v75Lyd//OPpX/6Eqjr8j39/8F//Wf72OxSKq2u2RFFJUUFCjYQQIEiYh7XwHmbxYapQgWp8Uv9FWPwj8fkZJQNdsv2t0gEPACTMYB6EwFTgFE6hCqegwQm0ewwhgAggqQaBGIK+rgJNmTjQHGp0EpEeQN5WKiClAhUIASN9S7+EQdkWyqpAVUIFMwcFnEIFJIwAoQpViMYGihptQFenZEBbUP8pAL0KFdcdCASgQBmR5tCGRAmNoMiA9sa2RnstHgX2KuW8xKyCACjoRFQhAiOMIKEC56AFEC4a6GFBoyW2oqRWpoXHTgHotXKLukq6ogllGd6UygXtCzd4sl2yvUYL5bIUbhUoCwDQMjYJAB8aTZJxcBAFBCRoyXx3lqsDOj5zgkB3nnCtXQjqzPj6cgQ0I/SCZHVBgCQbWg1C2DhhkW5SJ0UbgVYBHQhQaAZrIQ4QiEIUkn8ngkzmW8LBFIBeq5OdGR55veEVyc6iJQmveNR9Itu1DMaHlL4BGYqpiAigINAC3ug9qBCFc9EHBkNhBhjQmRENRm0KQN8hn+AWgyKrZgbQ6NlUCTUkCpfd4kECAqqIQFQUjlJAAqOQQE5cAloiIQGiVwxuUyeh0QAygyG5wo6AkTH0HdVjbjHC2xzJg4MoRKhCEQiI/hkeXCagHVhAFYgqXApMQEAULtVLB3PxO7nBV5kG0J01DiEJOoiZbGMelqCHO/9fJXo1BqUT6VDWpIb5BgAeaABLrlU7+2sGD3jCJ/rsFACYCDUIp1GjVSHT0WgkFhGk001I1g53iq7SQgJkv62IQTzETKjioAFqWyz8dW1XC6sbaT0IKiDKwLVD3SJQiS+HCCcBNIdbf12A4NM6vV1nssfXOkjN+s0bzWgEc44GgQpDgzqHwkHIZnl2cfXT65u379uLK2lbiFiwPE6DwnfgEqFKcFqmwzKs+/BPPscjdsF2r3PwhDe0Hq2HNwn5CstDSwjUwQnpqIWUCsCW9enZ6fO/nv338+bjqZqpK8wJnbPC0cEQ1FkJMdIbDeQ0IkMAGdbBemiyHqsE77PEEBS528TgDEIRSnxZAActoAY6qAt+wdBcX18fH5+/fNmcfHBANZtJ6VCVrEoWaioQoSpFSHijkbTpAI2Ecmam2ZPpnMSNeXd/HvixhNc5OFYTUEBx1BICijOBxVsUcAIllDFqgadfNs3NTXN95Rc3hXPlrCpL5+YVtmYoCzq1wBdFCDGGB00H6JFGI2o0xxo9Vu90zuy885+UmPUQ58SV4iCqdGIxbFSgIIxQg4RrBhpJikpZFtvb2/tHh/OD3WJ/V3e2ZFZSnYlQE5kRJRScgjNclc+gGJ9fi0IctHBaFlpACgftTEdIPjtCu0dazMcVzlXz2f7+/uHjR/PHD9yDA93blVkJUYuOWkUVWkDcxOgdhhHJmPR+US3dkQrUiSu1KJwr4ZyK9v7VBB4YmKaYsSuA7bI62N3df/iw+OorfXIkB/uYlUKh92Rg6got4RxEJwN0lwaSGDvE7T6eMNYYMj59FC7d+94JE4vsTZCAItBCi3nldrZ3tg8O5OFDPH7Ew31UpZihaWEEBKpwZYgkpwF0TjA6eueQ0uu33fOJGlOSHiF/R7LLMw2LSq7SEm26FoVKVc1lvoXtHezsys4uygLeo2iiE44ardPQ6KFGDePt1TAmz26s1tKJplwHABrN03szDzPS+ltDzjpAFusRERUUkAIQhgheA/3T9Jakd0VcSqdMxEZ3vSL56fp4cXTPHTVGjQ5ZajPz3gzs+llTMRlqtEjAGlADfEi8msGT3qCQ0LMl6cta6GSZCNBBeny7g9uAXodyZ3P6doueNKY8LB3c6XD7S4ysRFJGm4MykpwIZWJAAwnWjgjb8NNVCiLxJuQNJGkvnWqDClOEHMXneNgQ+kBEun5ep3AqAXBxEAe4LjU4NaCD3GExbimLtLf12hlib1nR30/WOqoqgY7UAyAyQaDXmoix04uqhgzZLmuNzIDEFHRKmjAE3pI0PRW2Nfqdt7OlJ7B/dJ6CSbVNCuggcnsmKftvhzAAEYx4HLu208a0rQLd2ZmU0OOgONmjPES2p/1TBfqzhes2y6AYGYrVF4Z3tOn4CWs+zmWCQOeMenRR1gCwukmX1JPulWfo/BYhhxhx9FAg86MhATjUaMT3KbVl/E6TAjpnXcz2GO6T3IYy+ubI971uDmkaRpVKBy8kC9BTkDlgoSKxX3xaQH8q3OvK2Drudz9Z+4jEkHN/imy/JhMzGaBH5nAUr8Uy6w1nVGXpS4mslOsikPzOQXAi8e7YIWgiIr1r7Pt8DIGWp2RMqGoaQOeuLOdnq682h12LvTXu8RwEdt2WbHVGTQJynWlJTxKKUjSOAhGwU95gpxPWMSyMd00JaBsCrZ+4KcrIsGNkeZNN7i5+RlR491cVWZfBnQDQqxyqU7gh9xoThDXRTNoHztCN6BBSSM2O+zq58hCOPGv3ZYJSr+MpkwB6VTL6Gw1ndx0J35xSjO7uaQFzrLsIYx0v7mVIyiVsHFUH4Uilpw40gDGh/uS7HxtnhfoNPOStMnrBOCDjAWVEYo4QSAKYBNAjj5czgZyydp8iKy9rUc+pc15t5y5Hj+eoVTt1FkgaA9FjbQRFzMQUyhS9TwBorMI3TiavuWG1DZBdIcbq3PON1QrHpjinKTbS6LS3UbQ/DaCD5ED3/8EYl2C6c3Y3lNyl5qrN/qZPfQ8iDFYfs/FB1TJ89iSBVqwqbMfcgsauMo5bJKPMo4M1D0b0lZaoSZ7q646kG+WYfTgloD9PBjzk55AQCYaBYwnMmDRNXbkWem074DFdoDsFvl1kXQnedlM3tPGTTUQElCXso8uggiriQrgYxvtK5ysm+huWDq01Y3bjP3ZHE7BvgzyAyQPEEcvBwLKEPIcXeBETJHV2QgdxgpDNcqMEwVSBDvLpcPmOEkNMP1+jMciO5BrtwojdQUif6p8k0APJDSE4VsCVcoMycYv9pyHDPNbo1WokJxnhPPWiK2AaSUfnLCZto4E8l5EDs14jR7EIgcjP1vxMaAAzmX6YtIJ+IvId1umN4LCEAPK5KbCNDES63H5k4pLMxa0yZY3+fxJh+g0AYmw4iE5GPjZtG6A/JSM1TU6wBzomTlPhIdBdEm8D9H0kDHGMk1CslS6OSRc2QH+h9OqcDaDpu8963kIZWJQN0F8sgqwXJs9qZx0+q3mmDev4B8kG6C+Vdf0xK2Pv+l9AJtmYji+VLvQZ9tOMEiYAhoRlA/S9hSk2HVjj2zpnNkDfQ8apjvj7im7yIAk5vYFsgL6fJDMtg67GUbfaL7uH5WcXdvxuJRk1SighO96wji8UAUADLdgKSdOuAejHIYxVGxuNvofkv63o07R5H0La5/1tG6C/WNYOMBgVQJbR2wD9N0ngHNnwkR52wUDfw34D9M8l+fgcbID+u0nWVyZDDf/nArr75/uRTPlniBNJIE0mseb+IMMZ8obdi4Pg+58U6H+M5BrdyQbov0XSEIXsStejzqFGB9kA/cUSBjCCElMazCjIYMzMQDZA31PuCKnzSVC7UGYD9BdL6DPMhp+n4KTPVMvgN54C4Qboe0lKjnZzIQxGnYeWiHPUJmOyAfrvImOznP8EPxxtsndfKAMOLRDpx4ONxt4N6fhGo+8ha8dF5mSPg4iIm0GO95TeC4bTtF/hdZlqb4D+QhHJ8JX147FXMx3cAP3FMugozEYX3KnRG3r3N8g6XV4vxMYZ3lcyLU6LNK1DvjcfG6DvI91gg/V6PcrBbgai308IMM38SBkb6IHRBqBR3TdAf7EwTqkEExnqdR+jdAP9NUzNtgH6ftIPIY2DOgaUo5t9M/TSTqwXfKXvaZ2//wQF4OCwH5YRZyvgiLDd+XWysbqa5q9PdQsT0P2P8qcBtKw7zYOzu7kW404E/cCiPGnBNEAA6BFH95Su1wRARzKyycG6h6ROrFCDSFw/coKs45PcdTWfI+MPV++Iv0vhIOd259egpEWWHaAwQ9ui9ShVEJKkSNP+RJkO0KsgrMA5HEA0GK6VH6Q5fSybfcooZmoR7q7qMFG6CGCAS3eLmgqdSiFSgILWY1ljuRAt4TQoPEHGVffIyQB9S+4x13AOZsrswdKsYP6ad/6s2yiMU351AwpooIE50IHWqcb13hwItB7LJZYLVIBzyTlaWh4HU1rC6TOF2ZSk67IPuWRTPnbzXQ6t9y0S1sJS8UTj0YbVE4IWe5gnqYIwK706mdLkVb2stb4yvpz5yHwQc7qhfzmSgU4TCyJOazziJ5kzpIioiIb1xK1eomkggqpgVUBoy5q+FaeuLERLlbBM6rSmnscnWN6I0EqupkEG5jdrBekn3yAwWt4GlDhFBPp+WBrpzcJiICooHUpn8Na2aJfKQp2CPnUCTB1ojj+MaGSng18RM/tspV2yMG/YWNkKhyDMs23btm09hM6hLOAEMHgP8SChDkUpUmBpXNRcNPA2DaBHs5T30s9QHGCnMCxdmihHjEqYQRb59GBi/36iXGUIQLoHYPiLCYpvfVMvl23TzmayPcfWHArUCywohagoihLFnAa7uPDvz/zpOW7qaQAN9D2fnYy0sXurBza2G3fRqWpoFEE/nXaYPwbKGIO44SJGQwtFocHMDGTpZF6hKgGiqVFTdCbVTKoZdIaruj25vHnxpn7zzp9fTgZoDAxslLtIRda7ka6MprrK0ZfB6dBCjaYKVNWiqqpZVZaFqAAe1sIKiKAotCyhFai4Wvrj0/MXP539+NPiw8fpAd3b2EFYsa50Lwm7NRMPppm2w2qz0Tdqfp9IruJSVOV8Z0t35pUTbZdYLuC3oVuoCpQFSDRL3BhOPrZv3p2/fvPu9euLaQGNoYKu2JJbynXSLyzWbb1Gx9Ryv7pQLEmB5avWK7RUNytc5dQ82gWaGiCqUqoZRVnXcnGDD5f+xeuL16+uzk9vmnohE3GG64QrpxnyY5Sl2wG5C8wgj+snD4oa4JOJjgG4g4k1bJe2bL03NhCicCgLqNOmtdOzq5dvzn746eKvry6OPy7aer6/U+5vTwloybAcqLMkdNcO1o/QBX0Fuvxot5ZVstEhwRxWTg9igEecgzTycWVjzfXyarG4rACPFoWwcCCwqHFz07x68/H775//5fuT1++clodHj548eLC9uzsloDEMBoee8La4OXNuHVVLHC/TaCSUB34waLTldSsaa67ry5vF5bwsTYlCRQX10haL5uTk8sUPH54/P/7xh9Or66MnX+189fDJs2cPHj2cHNB5Ti4ncX2JdEH6gllsQ1lnwNMEPhhObtyRwzw/7a1plvWyWTQOFlqmaXBxyYuLy5cv3z9/fv76javro/3dJ18/ffjsXw6efV09fDAtoAN+EcUh1gAyPCVb82ew4A/TjIFZlSH6tjiJ3Sj2HMfxhJKO5kAV0gz1Aqfn8N4fH5//8OLjT6/axeLx0dHRv3778He/3Xn2bfX4CLs70wIaGKC8TsZMeb3EoCbbwvrfXYqpK+ZSDBPFs1K3W82Karbjiqr1OL3gVc3rm8X748Xbt3a92N7Zffztv379h9/Pf/0rPDzC1harYjJAryrayuX8bAXizHFGvTfAx70Y1OCMIDWsIQsgQEyBxD1IeNvS8uHWbrO9t0du3Sz59vi6Xi7OLxYXF7JcHm5vzZ5+9eDXv5n/+jf45itsz6EymV7wzvAOw2EZl+jKRFKyEgsOAsUwET/DpqQjYBRatw6LEgUBQgWhg0pam2t5ONu2cnt+c12cXTYfzq7OLy6urozY2t/bPXpUffNt9fU3ODrC1hyFg/nJJJWC3BVwZ9K/9oPzcSXs/pjBTCzimxNHAcQQJz6HQAFKIW4G5xvD+dWiqZfLZX19Y2bF3u7e3uHR46d49BR7e1D1dY0lxLcwPzmgV2PoXvIYPYh28eCIofQBCwEDPWiwtGyqZKXNwwi2LB1FQPrWN4u6Pjtfvjv29YKAOLe7u7f18PHekyc4OsJ8DiOurlBftzTznjYpjR7qNLtd9wmHWEtmbZL1kYFKp3WBQveKaehhMUrXHWakh0HEwzso2Pr6+ur8w8fzd++u3ryhb7e2dw6OjvYOj3YePZKDAxQONzc48TjXRqwmG9LbL6bPsEd0sHAZ0sHATRIwwnv4BvAoBDNnM9eWAmeGFmzSKioeCkLgnKiIAXXdnJ19ePv63auX12/fVEVxWBY7ChbilX658B8/+otTOLRiC9oCsgQ8J9fDAgwc39CKdMEFE56EBMBU2I+rJeBbLms0DeBRCrZK2y78XFCYoYZfADXowBaOVBfH0C1bXFy0Jyenx8cnH06am6v93V2vWNCfLq6uTz+0y0VTuFZIsKFf0paQhsJpdWUN7YSMr2JNsGgp3LDcXgtghraBXwJEKZxpO5O6MEjTsqbVQAsIxEMIGpolrgynF3j9ujl5v6wXfla5o8PZg6PqyUO/t33hIM2NXbWtK1qhF2nJlvQUI/DPMOKfCWUODEi26KCS8EtbXrcLtFb7JcUDCikAL/Bc1v7suj4+Xb5661+8uDj9WO3vPvjdd0VZHB4e7B0d6NbMnDOnourEARBVgTiCVBh/QUD3WaMoQ/XvnWRk2UWBqoISbAFvzc3i5vLy+gKyVfvGnAAVUAAe7QJnlzc/vH7//fMP//O8OXkP2uGvnj09OnC7O9tbs3I+w2zGsqCLXelGmIT1EcOqOL+MnyhnMUxI2uvKGJrwYQitSQqETlmVUEPTwi+xuOHNtdULzCqDUF2Muq1uP5w2P707/9/nx3/+09vnL7y1j7799tEf/u3x73+Lw30Ny+lVlcxmcC50e0U6booE9PQ1OicWt44W6BwjWpAMi9SIaAhAPJpG2mZG7roC1WxezoQObYu68afvFn/98frHN+cvX958/AC21f7O7jdPD777Vfn773CwB9+ibVEWKGdQ7fvXI9D9qzQloMeRoYw9IZLrw7puXAM86elBKqSgh7VoW7StkttFebS9Lds7O7MtZ4rlAufn/sdXixc/nL9+d3n2URwOHj/YefrkwbNvykdH2J6jmgElfAN1kCJz0qFLIT1VgOkNCRvJuqh8NbHXnRrY0kgrDM48vIdv4b2KbJXl3nwuW1tb5UxN0NS4uvDHJ/W79zcfP9b1opjPdo8Oj775ev/JI92awzx8g5ApJQUWldeSRnOCqyh/kax1id2pgaQZEEeKmsEokFLdvKi0qEpXCAXWol7w8spfXC6vr1vv59s72/t7ew+OtvZ2pSxaGnwjqmG4qcSlORHWhAOEIfGd8lP/Bzrn28s/MpBOAAAAAElFTkSuQmCC",
            values: { "DESCRIPTIO": "PTE Colonnina", "STATO_1": "Realizzato" }
        }
    ]
    property bool presetMenuVisible: false

    // Timer polling: controlla ogni 500ms se il testo è cambiato
    // Necessario perché la tastiera vocale Android non sempre
    // trigghera onTextChanged correttamente
    Timer {
        id: pollTimer
        interval: 500
        repeat: true
        running: overlay.visible
        onTriggered: {
            if (inputArea.text !== plugin.lastParsedText && inputArea.text.length > 2) {
                plugin.lastParsedText = inputArea.text
                processVoice(inputArea.text)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        layerPicker.parent = mainWindow.contentItem
        overlay.parent        = mainWindow.contentItem
        picker.parent         = mainWindow.contentItem
        presetMenu.parent     = mainWindow.contentItem
        lineChoiceOverlay.parent = mainWindow.contentItem
        freeTextEditor.parent = mainWindow.contentItem
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    // ── TASTO BT ────────────────────────────────────────────────
    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible) {
            closeAll()
        } else if (layerPicker.visible) {
            closeAll()
        } else {
            // Mostra prima il selettore layer
            updateGPS()
            layerPicker.visible = true
        }
    }

    function closeAll() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        resetData()
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: togglePanel()
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        // Metodo corretto da VocalField:
        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            plugin.selectedLayer = layer
            dashBoard.activeLayer = layer
            mainWindow.displayToast("✅ Layer attivo: " + layerDef.name)
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        resetData()
        layerPicker.visible = false

        if (plugin.lineLayerNames.indexOf(layerDef.name) !== -1) {
            // Layer lineare
            plugin.lineMode = true
            plugin.linePoints = []
            if (positionSource && positionSource.active) {
                var pos = positionSource.projectedPosition
                plugin.linePoints = [{ x: pos.x, y: pos.y }]
                mainWindow.displayToast("🟢 Punto 1 salvato — spostati e premi BT")
            } else {
                mainWindow.displayToast("⚠ GPS non attivo!")
                plugin.lineMode = false
            }
        } else if (layerDef.name === "PTE") {
            // PTE: mostra menu preset
            plugin.lineMode = false
            presetMenu.visible = true
            presetFocusTimer.start()
        } else {
            // Altri layer puntuali
            plugin.lineMode = false
            overlay.visible = true
            focusTimer.start()
        }
    }

    function findLayer(name) {
        // Usa il layer trovato e impostato in selectLayer
        if (plugin.selectedLayer) return plugin.selectedLayer
        if (dashBoard && dashBoard.activeLayer)
            return dashBoard.activeLayer
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++)
            d[plugin.currentFields[i].key] = ""
        plugin.parsedData = d
        plugin.okCount = 0
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 400; repeat: false
        onTriggered: { inputArea.forceActiveFocus(); Qt.inputMethod.show() }
    }

    function processVoice(text) {
        var t = text.toLowerCase()
        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                // Bottoni layer
                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#22405a" : "#1e3a52"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label
                                color: "#e8eaf0"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#5ba3ff"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.90, 720)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = null
                            for (var i = 0; i < plugin.layerDefs.length; i++)
                                if (plugin.layerDefs[i].name === plugin.selectedLayerName)
                                    def = plugin.layerDefs[i]
                            return def ? def.icon + " " + def.label : "⚡ Voice Parser"
                        }
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    // Bottone cambia layer
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#1a3a5a" : "#22263a"
                        border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#8890a8"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 56
                    color: "#22263a"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Usa 🎤 tastiera oppure digita..."
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            // onTextChanged per digitazione normale
                            onTextChanged: {
                                if (text.length > 2) processVoice(text)
                            }
                            // onEditingFinished per input vocale Android
                            // (la tastiera vocale scrive tutto in un colpo)
                            Component.onCompleted: {
                                inputArea.textChanged.connect(function() {
                                    parseTimer.restart()
                                })
                            }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldType === "picker" ? "▾" : "✎"
                                color: "#5ba3ff"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = model.fieldOptions
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Bottone foto
                Rectangle {
                    Layout.fillWidth: true
                    height: 52; radius: 8
                    color: fotoM.pressed ? "#1a3a5a" : (plugin.photo1Path !== "" ? "#0a2018" : "#22263a")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#3a3d50"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text {
                            text: plugin.photo1Path !== "" ? "✅" : "📷"
                            font.pixelSize: 20
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: plugin.photo1Path !== "" ? "Foto acquisita ✔" : "Scatta foto"
                            color: plugin.photo1Path !== "" ? "#a8f0c6" : "#8890a8"
                            font.pixelSize: 14
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: {
                            platformUtilities.createDir(qgisProject.homePath, "DCIM")
                            // Invia broadcast Android che MacroDroid intercetta
                            // come trigger "Intento ricevuto"
                            Qt.openUrlExternally("intent://pte.plugin.FOTO_SCATTA#Intent;scheme=pte;end")
                            cameraLoader.active = true
                        }
                    }
                }

                                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma\" per salvare"
                    color: "#5ba3ff"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── MENU PRESET PTE ─────────────────────────────────────────
    Rectangle {
        id: presetMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.95, 620)
            height: presetCol.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: presetCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                // Header
                RowLayout {
                    width: parent.width
                    Text {
                        text: "📡 Seleziona tipo PTE"
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true
                        Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: skipM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea {
                            id: skipM; anchors.fill: parent
                            onClicked: {
                                presetMenu.visible = false
                                overlay.visible = true
                                focusTimer.start()
                            }
                        }
                    }
                }

                // Campo vocale numero
                Rectangle {
                    width: parent.width; height: 44
                    color: "#22263a"; radius: 8
                    border.color: presetVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextArea {
                        id: presetVoiceInput
                        anchors.fill: parent; anchors.margins: 8
                        placeholderText: "🎤 Di' il numero (1,2,3,4)..."
                        color: "#e8eaf0"; font.pixelSize: 13; background: null
                        onTextChanged: {
                            var n = parseInt(text.trim())
                            if (n >= 1 && n <= plugin.ptePresets.length) {
                                presetVoiceTimer.restart()
                            }
                        }
                    }
                }

                Timer {
                    id: presetVoiceTimer
                    interval: 600; repeat: false
                    onTriggered: {
                        var n = parseInt(presetVoiceInput.text.trim())
                        if (n >= 1 && n <= plugin.ptePresets.length) {
                            applyPreset(n - 1)
                        }
                    }
                }

                Timer {
                    id: presetPollTimer
                    interval: 500; repeat: true
                    running: presetMenu.visible
                    onTriggered: {
                        if (presetVoiceInput.text.length > 0) presetVoiceTimer.restart()
                    }
                }

                // Griglia preset 2 colonne
                GridLayout {
                    width: parent.width
                    columns: 2; columnSpacing: 8; rowSpacing: 8

                    Repeater {
                        model: plugin.ptePresets
                        delegate: Rectangle {
                            Layout.fillWidth: true
                            height: 130; radius: 10
                            color: presetItemM.pressed ? "#22405a" : "#1e3a52"
                            border.color: "#2a5a8a"; border.width: 1.5

                            Column {
                                anchors.fill: parent; anchors.margins: 8
                                spacing: 6

                                // Numero
                                Rectangle {
                                    width: 28; height: 28; radius: 14
                                    color: "#3d8ef0"
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    Text {
                                        anchors.centerIn: parent
                                        text: modelData.num
                                        color: "white"; font.pixelSize: 14; font.bold: true
                                    }
                                }

                                // Icona
                                Image {
                                    width: 64; height: 64
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    source: modelData.icon
                                    fillMode: Image.PreserveAspectFit
                                }

                                // Label
                                Text {
                                    width: parent.width
                                    text: modelData.label
                                    color: "#e8eaf0"; font.pixelSize: 11
                                    horizontalAlignment: Text.AlignHCenter
                                    wrapMode: Text.Wrap
                                }
                            }

                            MouseArea {
                                id: presetItemM; anchors.fill: parent
                                onClicked: applyPreset(index)
                            }
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── SCELTA VERTICE / FINE TRATTA ────────────────────────────
    Rectangle {
        id: lineChoiceOverlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#cc000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 480)
            height: 190; color: "#1a1d27"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 16; spacing: 12

                Text {
                    width: parent.width
                    text: "Punto " + plugin.linePoints.length + " salvato"
                    color: "#5ba3ff"; font.pixelSize: 16; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width; height: 54; radius: 8
                    color: verticeM.pressed ? "#1a3a5a" : "#1e3a52"
                    border.color: "#2a5a8a"; border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 10
                        Text { text: "🔵"; font.pixelSize: 22; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "Vertice — continua tratta"
                               color: "#e8eaf0"; font.pixelSize: 15; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: verticeM; anchors.fill: parent
                        onClicked: {
                            lineChoiceOverlay.visible = false
                            mainWindow.displayToast("🔵 Vertice salvato — spostati e premi BT")
                        }
                    }
                }

                Rectangle {
                    width: parent.width; height: 54; radius: 8
                    color: fineM.pressed ? "#178a3e" : "#1db954"
                    Row {
                        anchors.centerIn: parent; spacing: 10
                        Text { text: "🔴"; font.pixelSize: 22; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "Fine tratta — compila e salva"
                               color: "white"; font.pixelSize: 15; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: fineM; anchors.fill: parent
                        onClicked: saveLineFeature()
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#5ba3ff"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#e8eaf0"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = plugin.parsedData
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // Camera loader - metodo esatto plugin snap ufficiale
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                visible: false
                Component.onCompleted: open()
                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    plugin.photo1Path = filename
                    mainWindow.displayToast("📷 Foto acquisita!")
                }
                onCanceled: close()
                onClosed: cameraLoader.active = false
            }
        }
    }

    // Timer per auto-salvataggio e chiusura form
    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureForm.save()
            drawer.close()
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            closeAll()
        }
    }

    // ── MODEL ───────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                var val = plugin.parsedData[fd.key] || ""
                append({
                    fieldLabel:   fd.label,
                    fieldKey:     fd.key,
                    fieldValue:   val,
                    fieldOk:      val !== "",
                    fieldType:    fd.type,
                    fieldOptions: fd.options || []
                })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── FUNZIONI ────────────────────────────────────────────────
    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function parseText(raw) {
        var t = raw.toLowerCase()
        var d = {}

        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""

            if (fd.type === "picker" && fd.options) {
                // Cerca corrispondenza tra le opzioni
                for (var j = 0; j < fd.options.length; j++) {
                    if (t.indexOf(fd.options[j].toLowerCase()) !== -1) {
                        d[fd.key] = fd.options[j]; break
                    }
                }
                // Sinonimi speciali per PTE
                if (fd.key === "STATO_1") {
                    if (t.indexOf("non realizzato") !== -1 || t.indexOf("non fatto") !== -1)
                        d[fd.key] = "NON Realizzato"
                    else if (t.indexOf("realizzato") !== -1 || t.indexOf("nuovo") !== -1)
                        d[fd.key] = "Realizzato"
                    else if (t.indexOf("esistente") !== -1 || t.indexOf("presente") !== -1)
                        d[fd.key] = "Esistente"
                }
                if (fd.key === "DESCRIPTIO" && plugin.selectedLayerName === "PTE") {
                    if (t.indexOf("muro esterno") !== -1 || t.indexOf("palifica") !== -1)
                        d[fd.key] = "PTE Muro Esterno/Palifica"
                    else if (t.indexOf("sotterraneo") !== -1)
                        d[fd.key] = "PTE Sotterraneo"
                    else if (t.indexOf("colonnina") !== -1)
                        d[fd.key] = "PTE Colonnina"
                    else if (t.indexOf("interno") !== -1)
                        d[fd.key] = "PTE Interno"
                }
            } else if (fd.type === "text") {
                // Estrai numero dopo keyword
                var kw = fd.label.toLowerCase()
                var m  = t.match(new RegExp(kw + "\\s+(\\d+)"))
                if (m) d[fd.key] = m[1]
            }
        }

        plugin.parsedData = d
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    Timer {
        id: presetFocusTimer
        interval: 400; repeat: false
        onTriggered: {
            presetVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    function applyPreset(index) {
        presetMenu.visible = false
        presetVoiceInput.text = ""
        var preset = plugin.ptePresets[index]
        // Precompila i campi con i valori del preset
        var d = plugin.parsedData
        for (var key in preset.values) {
            d[key] = preset.values[key]
        }
        plugin.parsedData = d
        // Conta campi compilati
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
        // Apri form vocale
        overlay.visible = true
        focusTimer.start()
        mainWindow.displayToast("✅ " + preset.label + " — modifica o conferma")
    }

    function saveLineFeature() {
        lineChoiceOverlay.visible = false
        var layer = plugin.selectedLayer
        if (!layer) layer = dashBoard ? dashBoard.activeLayer : null
        if (!layer) { mainWindow.displayToast("⚠ Layer non trovato!"); return }
        try {
            var wktPts = []
            for (var i = 0; i < plugin.linePoints.length; i++)
                wktPts.push(plugin.linePoints[i].x + " " + plugin.linePoints[i].y)
            var wkt = "LINESTRING(" + wktPts.join(", ") + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var fieldNames = feature.fields.names
            // Lunghezza automatica
            var total = 0
            for (var j = 1; j < plugin.linePoints.length; j++) {
                var dx = plugin.linePoints[j].x - plugin.linePoints[j-1].x
                var dy = plugin.linePoints[j].y - plugin.linePoints[j-1].y
                total += Math.sqrt(dx*dx + dy*dy)
            }
            var lIdx = fieldNames.indexOf("LUNGHEZZA")
            if (lIdx < 0) lIdx = fieldNames.indexOf("lunghezza")
            if (lIdx < 0) lIdx = fieldNames.indexOf("LENGTH")
            if (lIdx >= 0) feature.setAttribute(lIdx, Math.round(total * 100) / 100)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            plugin.lineMode = false
            plugin.linePoints = []
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }
        if (!positionSource || !positionSource.active) {
            mainWindow.displayToast("⚠ GPS non attivo!"); return
        }
        try {
            var pos = positionSource.projectedPosition
            var wkt = "POINT(" + pos.x + " " + pos.y + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            // Aggiungi foto se presente
            if (plugin.photo1Path !== "") {
                var fi = fieldNames.indexOf("Foto_1")
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            // Salva tramite drawer (metodo che funziona)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}
