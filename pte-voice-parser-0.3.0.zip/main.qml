import QtQuick
import org.qfield 1.0

Item {
    id: root

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micButton)
        iface.mainWindow().displayToast("PTE Plugin caricato!")
    }

    QfToolButton {
        id: micButton
        text: "PTE"
        onClicked: {
            iface.mainWindow().displayToast("PTE Voice Parser attivo!")
        }
    }
}
