import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null
    property var selectedLayerDef: null

    property int okCount: 0
    property var parsedData: ({})

    // Stato linea
    property bool lineMode: false
    property var lineVertices: []
    property real pendingX: 0
    property real pendingY: 0
    property bool pendingValid: false

    // Auto-cattura
    property int autoCaptureMs: 5000

    // Voice state tracking
    property string lastParsedText: ""
    property string lastLayerVoiceText: ""
    property string lastVertexVoiceText: ""
    property string lastRadialVoiceText: ""
    property string photo1Path: ""

    // Radial menu state
    property var currentPresets: []

    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            geometryType: "point", photoField: "Foto_1",
            voiceKeywords: ["pte", "p t e"],
            fields: [
                { key: "TILABEL", label: "QUARTINA", type: "text" },
                { key: "ARMADIO", label: "ARMADIO", type: "text" },
                { key: "TIPOLOGIA", label: "TIPOLOGIA", type: "picker",
                  options: ["PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"] },
                { key: "Posizione", label: "UBICAZIONE", type: "picker",
                  options: ["Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Muro Esterno","Palo","Pontile","Pozzetto",
                           "Seminterrato","Sottoscala"] },
                { key: "Tipo_T", label: "MODELLO", type: "picker",
                  options: ["Terminale","Transito"] },
                { key: "COLON", label: "COLONNINA?", type: "picker", options: ["Si","No"] },
                { key: "BASAM", label: "BASAMENTO?", type: "picker", options: ["Si","No"] },
                { key: "CAVO_AGG", label: "CAVO SPILLATO?", type: "picker", options: ["Si","No"] },
                { key: "STATO", label: "STATO", type: "picker",
                  options: ["Esistente","Realizzato","NON Realizzato","Progettato"] },
                { key: "OBJECTID", label: "OBJECT ID", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/PTE__ROE PTE Muro Esterno.png",
                  label: "Muro Est progett",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Progettato", Posizione:"Muro Esterno" } },
                { id: 2, image: "images/PTE__ROE PTE Muro Esterno Realizzato.png",
                  label: "Muro Est realizz",
                  values: { TIPOLOGIA:"PTE Muro Esterno/Palifica", STATO:"Realizzato", Posizione:"Muro Esterno" } },
                { id: 3, image: "images/PTE__ROE PTE Interno Esistente.png",
                  label: "Interno esist",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Esistente" } },
                { id: 4, image: "images/PTE__ROE PTE Interno Realizzato.png",
                  label: "Interno realizz",
                  values: { TIPOLOGIA:"PTE Interno", STATO:"Realizzato" } },
                { id: 5, image: "images/PTE__ROE PTE Sotterraneo.png",
                  label: "Sotter progett",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Progettato", Posizione:"Pozzetto" } },
                { id: 6, image: "images/PTE__ROE PTE Sotterraneo Realizzato.png",
                  label: "Sotter realizz",
                  values: { TIPOLOGIA:"PTE Sotterraneo", STATO:"Realizzato", Posizione:"Pozzetto" } },
                { id: 7, image: "images/PTE__ROE PTE Colonnina.png",
                  label: "Colonnina progett",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Progettato", Posizione:"Colonnina" } },
                { id: 8, image: "images/PTE__ROE PTE Colonnina Realizzato.png",
                  label: "Colonnina realizz",
                  values: { TIPOLOGIA:"PTE Colonnina", STATO:"Realizzato", Posizione:"Colonnina" } }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄",
            geometryType: "point", photoField: "Foto_1",
            voiceKeywords: ["armadio", "armadi"],
            fields: [
                { key: "ARMADIO", label: "NUMERO ARMADIO", type: "text" },
                { key: "TIPOLOGIA", label: "TIPOLOGIA", type: "picker",
                  options: ["Armadio Ottico Esterno","Armadio Ottico Small"] },
                { key: "STATO", label: "STATO", type: "picker",
                  options: ["Realizzato","NON Realizzato","Esistente"] },
                { key: "Posizione", label: "POSIZIONE", type: "picker",
                  options: ["MURO ESTERNO","MURO INTERNO","INCASSATO","MARCIAPIEDE","CORTILE"] },
                { key: "N_cavi", label: "N. CAVI", type: "text" },
                { key: "Note", label: "NOTE", type: "text" },
                { key: "OBJECTID", label: "OBJECT ID", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/ARMADIO__Armadio Ottico Esterno Realizzato.png",
                  label: "Esterno realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Realizzato" } },
                { id: 2, image: "images/ARMADIO__Armadio Ottico Esterno NON Realizzato.png",
                  label: "Esterno NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"NON Realizzato" } },
                { id: 3, image: "images/ARMADIO__Armadio Ottico Esterno Esistente.png",
                  label: "Esterno esist",
                  values: { TIPOLOGIA:"Armadio Ottico Esterno", STATO:"Esistente" } },
                { id: 4, image: "images/ARMADIO__Armadio Ottico Small Realizzato.png",
                  label: "Small realizz",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Realizzato" } },
                { id: 5, image: "images/ARMADIO__Armadio Ottico Small NON Realizzato.png",
                  label: "Small NON real",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"NON Realizzato" } },
                { id: 6, image: "images/ARMADIO__Armadio Ottico Small Esistente.png",
                  label: "Small esist",
                  values: { TIPOLOGIA:"Armadio Ottico Small", STATO:"Esistente" } }
            ]
        },
        {
            name: "POZZETTI", label: "Pozzetti", icon: "⬛",
            geometryType: "point", photoField: "Foto_1",
            voiceKeywords: ["pozzetto", "pozzetti"],
            fields: [
                { key: "TIPOLOGIA", label: "TIPOLOGIA", type: "picker",
                  options: ["125x80","90x70","76x40","40x15","Altro"] },
                { key: "STATO_1", label: "STATO", type: "picker",
                  options: ["Realizzato","Esistente","Progettato"] },
                { key: "PROPRIETA", label: "PROPRIETA", type: "text" },
                { key: "ANELLI", label: "ANELLI?", type: "picker", options: ["Si","No"] },
                { key: "Num_Anelli", label: "N. ANELLI", type: "picker", options: ["1","2","3"] },
                { key: "1_Anello", label: "1 ANELLO", type: "picker", options: ["10","20","40"] },
                { key: "2_Anello", label: "2 ANELLO", type: "picker", options: ["10","20","40"] },
                { key: "3_Anello", label: "3 ANELLO", type: "picker", options: ["10","20","40"] },
                { key: "OBJECTID", label: "OBJECT ID", type: "text" }
            ],
            presets: [
                { id: 1,  image: "images/POZZETTI__Pozzetto Piccolo 47x47 Progettato.png",
                  label: "40x15 progett",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Progettato" } },
                { id: 2,  image: "images/POZZETTI__Pozzetto Piccolo 47x47 Nuovo.png",
                  label: "40x15 realizz",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Realizzato" } },
                { id: 3,  image: "images/POZZETTI__Pozzetto Piccolo 47x47 Esistente.png",
                  label: "40x15 esist",
                  values: { TIPOLOGIA:"40x15", STATO_1:"Esistente" } },
                { id: 4,  image: "images/POZZETTI__Pozzetto Piccolo 40x76 Progettato.png",
                  label: "76x40 progett",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Progettato" } },
                { id: 5,  image: "images/POZZETTI__Pozzetto Piccolo 40x76 Nuovo.png",
                  label: "76x40 realizz",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Realizzato" } },
                { id: 6,  image: "images/POZZETTI__Pozzetto Piccolo 40x76 Esistente.png",
                  label: "76x40 esist",
                  values: { TIPOLOGIA:"76x40", STATO_1:"Esistente" } },
                { id: 7,  image: "images/POZZETTI__Pozzetto 90x70 Progettato.png",
                  label: "90x70 progett",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Progettato" } },
                { id: 8,  image: "images/POZZETTI__Pozzetto 90x70 Nuovo.png",
                  label: "90x70 realizz",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Realizzato" } },
                { id: 9,  image: "images/POZZETTI__Pozzetto 90x70 Esistente.png",
                  label: "90x70 esist",
                  values: { TIPOLOGIA:"90x70", STATO_1:"Esistente" } },
                { id: 10, image: "images/POZZETTI__Pozzetto 125x80 Progetto.png",
                  label: "125x80 progett",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Progettato" } },
                { id: 11, image: "images/POZZETTI__Pozzetto 125x80 Nuovo.png",
                  label: "125x80 realizz",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Realizzato" } },
                { id: 12, image: "images/POZZETTI__Pozzetto 125x80 Esistente.png",
                  label: "125x80 esist",
                  values: { TIPOLOGIA:"125x80", STATO_1:"Esistente" } },
                { id: 13, image: "images/POZZETTI__Pozzetto Altro.png",
                  label: "Altro",
                  values: { TIPOLOGIA:"Altro" } }
            ]
        },
        {
            name: "GIUNTI", label: "Giunti", icon: "🔗",
            geometryType: "point", photoField: "Foto1",
            voiceKeywords: ["giunto", "giunti"],
            fields: [
                { key: "TILABEL", label: "NAMING", type: "text" },
                { key: "TIPOLOGIA", label: "TIPOLOGIA", type: "picker",
                  options: ["Compatta","Normale","Giunto di Linea"] },
                { key: "STATO", label: "STATO", type: "picker",
                  options: ["Realizzato","Esistente"] },
                { key: "Note", label: "NOTE", type: "text" },
                { key: "OBJECTID", label: "OBJECT ID", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/GIUNTI__Compatta Realizzato.png",
                  label: "Compatta realizz",
                  values: { TIPOLOGIA:"Compatta", STATO:"Realizzato" } },
                { id: 2, image: "images/GIUNTI__Compatta Esistente.png",
                  label: "Compatta esist",
                  values: { TIPOLOGIA:"Compatta", STATO:"Esistente" } },
                { id: 3, image: "images/GIUNTI__Normale Realizzato.png",
                  label: "Normale realizz",
                  values: { TIPOLOGIA:"Normale", STATO:"Realizzato" } },
                { id: 4, image: "images/GIUNTI__Normale Esistente.png",
                  label: "Normale esist",
                  values: { TIPOLOGIA:"Normale", STATO:"Esistente" } },
                { id: 5, image: "images/GIUNTI__Giunto di Linea Realizzato.png",
                  label: "Linea realizz",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Realizzato" } },
                { id: 6, image: "images/GIUNTI__Giunto di Linea Esistente.png",
                  label: "Linea esist",
                  values: { TIPOLOGIA:"Giunto di Linea", STATO:"Esistente" } }
            ]
        },
        {
            name: "PALI", label: "Pali", icon: "📏",
            geometryType: "point", photoField: "Foto_1",
            voiceKeywords: ["palo", "pali"],
            fields: [
                { key: "STATO", label: "STATO", type: "picker", options: ["Realizzato","Esistente"] },
                { key: "MATERIALE", label: "MATERIALE", type: "picker", options: ["Pino","Vtr"] },
                { key: "MODELLO", label: "MODELLO", type: "picker",
                  options: ["Singolo","Abbinato","Contropalo","Opposto"] },
                { key: "POSIZIONAM", label: "POSIZIONAM.", type: "picker", options: ["Base","Complessa"] },
                { key: "Altezza", label: "ALTEZZA", type: "picker", options: ["8","9","10","11","12"] },
                { key: "REGGIPALO", label: "REGGIPALO?", type: "picker", options: ["Si","No"] },
                { key: "TIRANTI_M", label: "TIRANTI MURO", type: "picker", options: ["0","1","2"] },
                { key: "TIRANTI_RO", label: "TIRANTI ROCC.", type: "picker", options: ["0","1","2"] },
                { key: "PALO_ROCCI", label: "PALO ROCCIA?", type: "picker", options: ["Si","No"] },
                { key: "SCORTA", label: "SCORTA?", type: "picker", options: ["Si","No"] },
                { key: "OBJECTID", label: "OBJECT ID", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/PALI__Palo Esistente.png",
                  label: "Esistente",
                  values: { STATO:"Esistente" } },
                { id: 2, image: "images/PALI__Palo Legno Singolo.png",
                  label: "Legno Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Singolo" } },
                { id: 3, image: "images/PALI__Palo Legno Abbinato.png",
                  label: "Legno Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Abbinato" } },
                { id: 4, image: "images/PALI__Palo Legno Contropalo.png",
                  label: "Legno Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Pino", MODELLO:"Contropalo" } },
                { id: 5, image: "images/PALI__Palo VTR Singolo.png",
                  label: "VTR Singolo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Singolo" } },
                { id: 6, image: "images/PALI__Palo VTR Abbinato.png",
                  label: "VTR Abbinato",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Abbinato" } },
                { id: 7, image: "images/PALI__Palo VTR Contropalo.png",
                  label: "VTR Contropalo",
                  values: { STATO:"Realizzato", MATERIALE:"Vtr", MODELLO:"Contropalo" } }
            ]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            geometryType: "point", photoField: "Foto1",
            voiceKeywords: ["extra"],
            fields: [
                { key: "Tipologia", label: "TIPOLOGIA", type: "picker",
                  options: ["Note","Colonna Montante","Foto"] },
                { key: "Stato", label: "STATO", type: "picker", options: ["Nuovo","Esistente"] },
                { key: "Note", label: "NOTE", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/EXTRA__Note.png",
                  label: "Note",
                  values: { Tipologia:"Note" } },
                { id: 2, image: "images/EXTRA__Colonna Montante.png",
                  label: "Colonna Montante",
                  values: { Tipologia:"Colonna Montante" } },
                { id: 3, image: "images/EXTRA__Foto.png",
                  label: "Foto",
                  values: { Tipologia:"Foto" } }
            ]
        },
        {
            name: "CAVI", label: "Cavi", icon: "🪢",
            geometryType: "line", photoField: "Foto", lengthField: "Lunghezza",
            voiceKeywords: ["cavo", "cavi"],
            fields: [
                { key: "Tipologia", label: "TIPOLOGIA", type: "picker",
                  options: ["Fune Esistente","Nuova Fune"] },
                { key: "Fibre", label: "FIBRE", type: "picker",
                  options: ["24","48","72","96","144","192"] },
                { key: "Lunghezza", label: "LUNGHEZZA (m)", type: "text", auto: "length" },
                { key: "Note", label: "NOTE", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/CAVI__NUOVA FUNE.png",
                  label: "Nuova Fune",
                  values: { Tipologia:"Nuova Fune" } },
                { id: 2, image: "images/CAVI__FUNE ESISTENTE.png",
                  label: "Fune Esistente",
                  values: { Tipologia:"Fune Esistente" } }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰",
            geometryType: "line", photoField: "FOTO1", lengthField: "Lunghezza",
            voiceKeywords: ["raccordi", "raccordo"],
            fields: [
                { key: "Tipologia", label: "TIPOLOGIA", type: "picker",
                  options: ["Monofibra","Multifibra"] },
                { key: "Stato", label: "STATO", type: "picker",
                  options: ["Realizzato","Progettato"] },
                { key: "Lunghezza", label: "LUNGHEZZA (m)", type: "text", auto: "length" },
                { key: "TIP_COLL", label: "TIPOL. CAVO", type: "text" },
                { key: "CAMB_PTE", label: "PTE VARIATO?", type: "text" },
                { key: "CASCATA", label: "CASCATA PTE?", type: "text" }
            ],
            presets: [
                { id: 1, image: "images/RACCORDI__Monofibra Progettato.png",
                  label: "Mono progett",
                  values: { Tipologia:"Monofibra", Stato:"Progettato" } },
                { id: 2, image: "images/RACCORDI__Monofibra Realizzato.png",
                  label: "Mono realizz",
                  values: { Tipologia:"Monofibra", Stato:"Realizzato" } },
                { id: 3, image: "images/RACCORDI__Multifibra Progettato.png",
                  label: "Multi progett",
                  values: { Tipologia:"Multifibra", Stato:"Progettato" } },
                { id: 4, image: "images/RACCORDI__Multifibra Realizzato.png",
                  label: "Multi realizz",
                  values: { Tipologia:"Multifibra", Stato:"Realizzato" } }
            ]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte", icon: "⛏",
            geometryType: "line", photoField: "Foto1", lengthField: "Lunghezza",
            voiceKeywords: ["tratta", "tratte", "tratte interrate", "interrate"],
            fields: [
                { key: "Stato", label: "STATO", type: "picker",
                  options: ["Realizzato","Esistente","Progetto"] },
                { key: "Tipologia", label: "TIPOLOGIA", type: "picker",
                  options: ["Canalizzazione","Trincea","Trincea Sterrato","Trincea Pregiato",
                           "Minitrincea","Microtrincea","No-Dig"] },
                { key: "Lunghezza", label: "LUNGHEZZA (m)", type: "text", auto: "length" },
                { key: "1_Min", label: "MINITUBI?", type: "picker", options: ["SI","NO"] },
                { key: "Tipo_Min1", label: "TIPO MINI", type: "picker", options: ["12","14"] },
                { key: "Num_Min1", label: "N. MINITUBI", type: "text" },
                { key: "1_Tubo", label: "TUBI?", type: "picker", options: ["SI","NO"] },
                { key: "Tipo_Tub1", label: "TIPO TUBO", type: "picker",
                  options: ["40","50","63","80","100","110","125","160"] },
                { key: "Num_Tubo1", label: "N. TUBI", type: "text" },
                { key: "ripristino", label: "RIPRISTINO?", type: "picker", options: ["SI","NO"] }
            ],
            presets: [
                { id: 1,  image: "images/TRATTE INTERRATE__PROGETTATO.png",
                  label: "Progettato",
                  values: { Stato:"Progetto" } },
                { id: 2,  image: "images/TRATTE INTERRATE__Esistente.png",
                  label: "Esistente",
                  values: { Stato:"Esistente" } },
                { id: 3,  image: "images/TRATTE INTERRATE__MANCA RIPRISTINO.png",
                  label: "Manca ripristino",
                  values: { Stato:"Realizzato", ripristino:"NO" } },
                { id: 4,  image: "images/TRATTE INTERRATE__Trincea Progetto.png",
                  label: "Trincea progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea" } },
                { id: 5,  image: "images/TRATTE INTERRATE__Trincea Realizzato.png",
                  label: "Trincea realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea" } },
                { id: 6,  image: "images/TRATTE INTERRATE__Trincea Sterrato Progetto.png",
                  label: "Tr Sterrato progett",
                  values: { Stato:"Progetto", Tipologia:"Trincea Sterrato" } },
                { id: 7,  image: "images/TRATTE INTERRATE__Trincea Sterrato Realizzato.png",
                  label: "Tr Sterrato realizz",
                  values: { Stato:"Realizzato", Tipologia:"Trincea Sterrato" } },
                { id: 8,  image: "images/TRATTE INTERRATE__Minitrincea Progetto.png",
                  label: "Minitr progett",
                  values: { Stato:"Progetto", Tipologia:"Minitrincea" } },
                { id: 9,  image: "images/TRATTE INTERRATE__Minitrincea Realizzato.png",
                  label: "Minitr realizz",
                  values: { Stato:"Realizzato", Tipologia:"Minitrincea" } },
                { id: 10, image: "images/TRATTE INTERRATE__No-Dig Progetto.png",
                  label: "No-Dig progett",
                  values: { Stato:"Progetto", Tipologia:"No-Dig" } },
                { id: 11, image: "images/TRATTE INTERRATE__No-Dig Realizzato.png",
                  label: "No-Dig realizz",
                  values: { Stato:"Realizzato", Tipologia:"No-Dig" } }
            ]
        }
    ]


    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []

    // ── SEGNALAZIONE EVENTI VIA CREATEDIR ───────────────────────
    // QField QML espone solo createDir e renameFile per la scrittura.
    // renameFile distrugge la sorgente, quindi non e' praticabile per
    // eventi ripetuti. Usiamo createDir: per ogni evento creiamo una
    // sottocartella timestampata dentro una cartella-evento. MacroDroid
    // configura il trigger "Folder Modified" su ciascuna cartella-evento.
    property string signalsRoot: "/storage/emulated/0/Download/pte_signals"
    property bool signalsRootReady: false

    // Elenco eventi noti - per pre-creare le cartelle padre
    property var knownEvents: [
        "voice_input_ready", "layer_picker_ready", "form_ready",
        "vertex_choice_ready", "line_first_vertex", "foto_scatta",
        "auto_shutter", "auto_confirm", "photo_done", "all_closed"
    ]

    function ensureSignalsRoot() {
        if (plugin.signalsRootReady) return
        try {
            platformUtilities.createDir("/storage/emulated/0/Download", "pte_signals")
            // Pre-crea le cartelle per ogni evento noto
            for (var i = 0; i < plugin.knownEvents.length; i++) {
                platformUtilities.createDir(plugin.signalsRoot, plugin.knownEvents[i])
            }
            plugin.signalsRootReady = true
        } catch(e) {
            // silent
        }
    }

    function broadcastEvent(eventName) {
        try {
            ensureSignalsRoot()
            var evDir = plugin.signalsRoot + "/" + eventName.toLowerCase()
            // Crea una sottocartella unica per l'evento → trigger MacroDroid
            // su "Folder Modified" della cartella evDir
            var subName = "t" + Date.now()
            platformUtilities.createDir(evDir, subName)
        } catch(e) {
            // silent
        }
    }

    // ── DIAGNOSTICO FILE WRITE ──────────────────────────────────
    // Prova vari metodi e accumula i risultati in diagLog, mostrato
    // in una dialog persistente cosi' i risultati sono leggibili con calma.
    property string diagLog: ""

    function diagAdd(line) {
        plugin.diagLog += line + "\n"
    }

    function probeMethods(objName, obj, methods) {
        diagAdd(objName + ":")
        if (!obj) { diagAdd("  (oggetto non esiste)"); return }
        for (var i = 0; i < methods.length; i++) {
            var m = methods[i]
            var t = "?"
            try { t = typeof obj[m] } catch(e) { t = "EXC:" + e }
            diagAdd("  " + m + " : " + t)
        }
    }

    function runFileDiagnostic() {
        plugin.diagLog = ""
        ensureSignalsRoot()

        diagAdd("=== TEST CREATEDIR APPROACH ===")
        diagAdd("Crea sottocartelle dentro /Download/pte_signals/<evento>/")
        diagAdd("")
        try {
            var testEvent = plugin.signalsRoot + "/auto_shutter"
            var subName = "diag_t" + Date.now()
            var ok = platformUtilities.createDir(testEvent, subName)
            diagAdd("createDir(\"" + testEvent + "\", \"" + subName + "\")")
            diagAdd("  -> " + ok)
            diagAdd("  esiste: " + FileUtils.fileExists(testEvent + "/" + subName))
        } catch(e) {
            diagAdd("EXC: " + e)
        }
        diagAdd("")
        diagAdd("=== PROBE METODI QFIELD ===")
        diagAdd("")

        // Probe FileUtils
        var fuObj = (typeof FileUtils !== "undefined") ? FileUtils : null
        probeMethods("FileUtils", fuObj, [
            "copyFile","copy","copyTo","clone",
            "moveFile","move","rename","renameFile",
            "deleteFile","remove","removeFile","unlink",
            "fileExists","exists","isFile","isDir",
            "writeFile","write","writeText","createFile","touch",
            "copyDir","deleteDir","makeDir","mkdir",
            "fileSuffix","fileName","absolutePath","addUniqueSuffix"
        ])
        diagAdd("")

        // Probe platformUtilities
        var puObj = (typeof platformUtilities !== "undefined") ? platformUtilities : null
        probeMethods("platformUtilities", puObj, [
            "copyFile","copy","copyTo",
            "moveFile","move","renameFile",
            "deleteFile","remove",
            "createDir","makeDir","mkdir",
            "createSymbolicLink","symlink","link",
            "openFile","openLink","openUrl",
            "writeFile","write","createFile","touch",
            "vibrate","getCameraPictureFilePath"
        ])
        diagAdd("")

        // Probe iface se ha sotto-oggetti utili
        var ifaceObj = (typeof iface !== "undefined") ? iface : null
        probeMethods("iface", ifaceObj, [
            "platformUtilities","fileUtils","writeFile",
            "mainWindow","findItemByObjectName","addItemToPluginsToolbar"
        ])
        diagAdd("")

        // Probe globals
        diagAdd("Globals:")
        try { diagAdd("  Qt.fileExists?: " + typeof Qt.fileExists) } catch(e) {}
        try { diagAdd("  qgisProject: " + typeof qgisProject) } catch(e) {}
        try { diagAdd("  qgisProject.homePath: " + qgisProject.homePath) } catch(e) {}
        diagAdd("")

        // Test pratico: createSymbolicLink (se esiste)
        diagAdd("=== TEST createSymbolicLink ===")
        var seedPath = "(non usato in v23)"
        var destPath = plugin.signalsDir + "/_diag_test.signal"
        diagAdd("SEED: " + seedPath)
        diagAdd("DEST: " + destPath)

        if (puObj && typeof puObj.createSymbolicLink === "function") {
            try {
                var ok = puObj.createSymbolicLink(seedPath, destPath)
                diagAdd("createSymbolicLink -> " + ok)
            } catch(e) {
                diagAdd("createSymbolicLink EXC: " + e)
            }
            try {
                diagAdd("file esiste dopo: " + FileUtils.fileExists(destPath))
            } catch(e) {}
        } else {
            diagAdd("createSymbolicLink NON disponibile")
        }
        diagAdd("")

        // Test pratico: scrittura in qgisProject.homePath (cartella sicuramente scrivibile)
        diagAdd("=== TEST homePath copy ===")
        try {
            var home = qgisProject.homePath
            diagAdd("homePath: " + home)
            var homeDest = home + "/_diag_in_project.signal"
            diagAdd("dest in project: " + homeDest)
            if (puObj && typeof puObj.renameFile === "function") {
                // First, prova a creare un seed temporaneo in homePath via openFile?
                // Saltiamo, useremo renameFile dopo un copy se possibile
            }
            diagAdd("(test homePath skipped — serve un metodo copy/write per riempirlo)")
        } catch(e) {
            diagAdd("homePath test EXC: " + e)
        }

        diagAdd("")
        diagAdd("=== FINE ===")
        diagAdd("Manda screenshot di questa schermata.")
        diagDialog.visible = true
    }

    // Evento "ombrello": emesso ogni volta che un input vocale e' pronto.
    // Configura UNA macro MacroDroid su pte.plugin.VOICE_INPUT_READY
    // che attivi il microfono della tastiera — copre tutti gli stati
    // (picker layer, form punto, modale vertice, form fine-tratta, ritorno dopo foto).
    function emitVoiceReady() {
        broadcastEvent("VOICE_INPUT_READY")
    }

    // Polling per form
    Timer {
        id: pollTimer
        interval: 500; repeat: true; running: overlay.visible
        onTriggered: {
            if (inputArea.text !== plugin.lastParsedText && inputArea.text.length > 2) {
                plugin.lastParsedText = inputArea.text
                processVoice(inputArea.text)
            }
        }
    }

    // Polling per layer picker
    Timer {
        id: layerVoicePollTimer
        interval: 400; repeat: true; running: layerPicker.visible
        onTriggered: {
            if (layerVoiceInput.text !== plugin.lastLayerVoiceText
                    && layerVoiceInput.text.length > 1) {
                plugin.lastLayerVoiceText = layerVoiceInput.text
                tryMatchLayerVoice(layerVoiceInput.text)
            }
        }
    }

    // Polling per vertex choice
    Timer {
        id: vertexVoicePollTimer
        interval: 400; repeat: true; running: vertexChoice.visible
        onTriggered: {
            if (vertexVoiceInput.text !== plugin.lastVertexVoiceText
                    && vertexVoiceInput.text.length > 1) {
                plugin.lastVertexVoiceText = vertexVoiceInput.text
                processVertexVoice(vertexVoiceInput.text)
            }
        }
    }

    // Polling per radial menu
    Timer {
        id: radialVoicePollTimer
        interval: 400; repeat: true; running: radialMenu.visible
        onTriggered: {
            if (radialVoiceInput.text !== plugin.lastRadialVoiceText
                    && radialVoiceInput.text.length > 0) {
                plugin.lastRadialVoiceText = radialVoiceInput.text
                processRadialVoice(radialVoiceInput.text)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        layerPicker.parent     = mainWindow.contentItem
        overlay.parent         = mainWindow.contentItem
        picker.parent          = mainWindow.contentItem
        freeTextEditor.parent  = mainWindow.contentItem
        vertexChoice.parent    = mainWindow.contentItem
        radialMenu.parent      = mainWindow.contentItem
        diagDialog.parent      = mainWindow.contentItem
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible || picker.visible || freeTextEditor.visible || vertexChoice.visible || radialMenu.visible) {
            return
        }
        if (layerPicker.visible) {
            closeAll(); return
        }

        capturePendingPosition()

        if (plugin.lineMode) {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido")
                return
            }
            vertexCountText.text = "Vertici raccolti: " + plugin.lineVertices.length +
                                   " + 1 in attesa"
            plugin.lastVertexVoiceText = ""
            vertexVoiceInput.text = ""
            vertexChoice.visible = true
            vertexFocusTimer.start()
            broadcastEvent("VERTEX_CHOICE_READY")
            emitVoiceReady()
        } else {
            updateGPS()
            plugin.lastLayerVoiceText = ""
            layerVoiceInput.text = ""
            layerPicker.visible = true
            layerFocusTimer.start()
            broadcastEvent("LAYER_PICKER_READY")
            emitVoiceReady()
        }
    }

    function capturePendingPosition() {
        plugin.pendingValid = false
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                var pos = positionSource.projectedPosition
                plugin.pendingX = pos.x
                plugin.pendingY = pos.y
                plugin.pendingValid = true
            }
        }
    }

    function closeAll() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        picker.visible = false
        freeTextEditor.visible = false
        vertexChoice.visible = false
        radialMenu.visible = false
        plugin.lineMode = false
        plugin.lineVertices = []
        plugin.pendingValid = false
        plugin.lastLayerVoiceText = ""
        plugin.lastVertexVoiceText = ""
        plugin.lastRadialVoiceText = ""
        if (layerVoiceInput) layerVoiceInput.text = ""
        if (vertexVoiceInput) vertexVoiceInput.text = ""
        if (radialVoiceInput) radialVoiceInput.text = ""
        resetData()
        broadcastEvent("ALL_CLOSED")
    }

    QfToolButton {
        id: micBtn
        bgcolor: "#27ae60"
        iconSource: Theme.getThemeVectorIcon("ic_add_white_24dp")
        iconColor: "white"
        round: true
        onClicked: togglePanel()
        // Overlay "+" come fallback se l'icona non si carica
        Text {
            anchors.centerIn: parent
            text: "+"
            color: "white"
            font.pixelSize: 26
            font.bold: true
            z: 2
            visible: micBtn.iconSource === "" || true
        }
    }

    function findLayerDef(name) {
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            if (plugin.layerDefs[i].name === name) return plugin.layerDefs[i]
        }
        return null
    }

    function tryMatchLayerVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.length < 2) return

        var best = null
        var bestScore = 0
        for (var i = 0; i < plugin.layerDefs.length; i++) {
            var ld = plugin.layerDefs[i]
            var kws = ld.voiceKeywords || []
            for (var j = 0; j < kws.length; j++) {
                var kw = kws[j].toLowerCase()
                if (t.indexOf(kw) !== -1) {
                    if (kw.length > bestScore) { bestScore = kw.length; best = ld }
                }
            }
            if (t.indexOf(ld.name.toLowerCase()) !== -1 ||
                t.indexOf(ld.label.toLowerCase()) !== -1) {
                if (ld.name.length > bestScore) { bestScore = ld.name.length; best = ld }
            }
        }
        if (best) {
            mainWindow.displayToast("🎯 " + best.label + " selezionato")
            selectLayer(best)
        }
    }

    // ── VOICE PARSER PER MODALE VERTICE ─────────────────────────
    function processVertexVoice(text) {
        var t = text.toLowerCase().trim()
        if (t.indexOf("fine") !== -1 || t.indexOf("chiudi") !== -1
                || t.indexOf("termina") !== -1 || t.indexOf("ultimo") !== -1) {
            endLineAndOpenForm()
        } else if (t.indexOf("vertice") !== -1 || t.indexOf("intermedio") !== -1
                   || t.indexOf("punto") !== -1) {
            addIntermediateVertex()
        } else if (t.indexOf("annulla") !== -1 || t.indexOf("cancella") !== -1
                   || t.indexOf("abort") !== -1) {
            vertexChoice.visible = false
            closeAll()
            mainWindow.displayToast("Tratta annullata")
        }
    }

    // Riconosce numero da digitazione o voce (italiano)
    function parseNumberFromText(text) {
        var t = text.toLowerCase().trim()
        var m = t.match(/\d+/)
        if (m) return parseInt(m[0])
        var words = ["zero","uno","due","tre","quattro","cinque","sei",
                     "sette","otto","nove","dieci","undici","dodici",
                     "tredici","quattordici","quindici","sedici"]
        for (var i = 0; i < words.length; i++) {
            if (t.indexOf(words[i]) !== -1) return i
        }
        return -1
    }

    function processRadialVoice(text) {
        var n = parseNumberFromText(text)
        if (n < 1) return
        // Cerca preset con id corrispondente
        for (var i = 0; i < plugin.currentPresets.length; i++) {
            if (plugin.currentPresets[i].id === n) {
                selectPreset(plugin.currentPresets[i])
                return
            }
        }
    }

    function selectPreset(preset) {
        // Pre-popola parsedData con i values del preset
        var d = plugin.parsedData
        if (preset.values) {
            for (var k in preset.values) {
                d[k] = preset.values[k]
            }
        }
        plugin.parsedData = d
        var n = 0
        for (var k2 in d) if (d[k2] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()

        radialMenu.visible = false
        mainWindow.displayToast("✓ Preset " + preset.id + ": " + preset.label)

        // Se layer e' linea, avvia lineMode con primo vertice; altrimenti apri form
        var def = plugin.selectedLayerDef
        if (def && def.geometryType === "line") {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido, vertice 1 saltato")
                return
            }
            plugin.lineVertices = [{ x: plugin.pendingX, y: plugin.pendingY }]
            plugin.lineMode = true
            plugin.pendingValid = false
            Qt.inputMethod.hide()
            mainWindow.displayToast("📍 Vertice 1 salvato. Spostati e ripremi.")
            broadcastEvent("LINE_FIRST_VERTEX")
        } else {
            overlay.visible = true
            focusTimer.start()
            broadcastEvent("FORM_READY")
            emitVoiceReady()
        }
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.selectedLayerDef = layerDef
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            plugin.selectedLayer = layer
            dashBoard.activeLayer = layer
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        resetData()
        layerPicker.visible = false

        if (layerDef.geometryType === "line" && layerDef.presets && layerDef.presets.length > 0) {
            // Linea CON preset: mostra radial PRIMA di avviare lineMode
            plugin.currentPresets = layerDef.presets
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            radialMenu.visible = true
            radialFocusTimer.start()
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
        } else if (layerDef.geometryType === "line") {
            if (!plugin.pendingValid) {
                mainWindow.displayToast("⚠ GPS non valido, vertice 1 saltato")
                return
            }
            plugin.lineVertices = [{ x: plugin.pendingX, y: plugin.pendingY }]
            plugin.lineMode = true
            plugin.pendingValid = false
            Qt.inputMethod.hide()
            mainWindow.displayToast("📍 Vertice 1 salvato. Spostati e ripremi.")
            broadcastEvent("LINE_FIRST_VERTEX")
        } else if (layerDef.presets && layerDef.presets.length > 0) {
            // Layer con preset: mostra menu radial
            plugin.currentPresets = layerDef.presets
            plugin.lastRadialVoiceText = ""
            radialVoiceInput.text = ""
            radialMenu.visible = true
            radialFocusTimer.start()
            broadcastEvent("RADIAL_READY")
            emitVoiceReady()
        } else {
            overlay.visible = true
            focusTimer.start()
            broadcastEvent("FORM_READY")
            emitVoiceReady()
        }
    }

    function findLayer(name) {
        if (plugin.selectedLayer) return plugin.selectedLayer
        if (dashBoard && dashBoard.activeLayer) return dashBoard.activeLayer
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++)
            d[plugin.currentFields[i].key] = ""
        plugin.parsedData = d
        plugin.okCount = 0
        plugin.photo1Path = ""
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 250; repeat: false
        onTriggered: {
            inputArea.forceActiveFocus()
            Qt.inputMethod.show()
            focusRetry.start()
        }
    }
    Timer {
        id: focusRetry
        interval: 700; repeat: false
        onTriggered: {
            if (overlay.visible && !inputArea.activeFocus) {
                inputArea.forceActiveFocus()
                Qt.inputMethod.show()
            }
        }
    }
    Timer {
        id: layerFocusTimer
        interval: 300; repeat: false
        onTriggered: {
            layerVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }
    Timer {
        id: vertexFocusTimer
        interval: 250; repeat: false
        onTriggered: {
            vertexVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }
    Timer {
        id: radialFocusTimer
        interval: 250; repeat: false
        onTriggered: {
            radialVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    function processVoice(text) {
        var t = text.toLowerCase()

        if (t.indexOf("scatta foto") !== -1
                || t.indexOf("fai foto") !== -1
                || t.indexOf("fai una foto") !== -1
                || t.indexOf("scatta una foto") !== -1) {
            inputArea.text = ""
            plugin.lastParsedText = ""
            triggerPhotoCapture()
            return
        }

        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    function triggerPhotoCapture() {
        platformUtilities.createDir(qgisProject.homePath, "DCIM")
        broadcastEvent("FOTO_SCATTA")
        cameraLoader.active = true
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer (voce o tap)"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width; height: 44
                    color: "#22263a"; radius: 8
                    border.color: layerVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: layerVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#e8eaf0"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 Di' il nome del layer..."
                        placeholderTextColor: "#5a6378"
                    }
                }

                // Pulsante diagnostico (TEST FILE)
                Rectangle {
                    width: parent.width; height: 38; radius: 6
                    color: diagMA.pressed ? "#5a1a1a" : "#7a2a2a"
                    border.color: "#aa3a3a"; border.width: 1
                    Text {
                        anchors.centerIn: parent
                        text: "🔧 TEST FILE WRITE"
                        color: "#ffe0e0"; font.pixelSize: 13; font.bold: true
                    }
                    MouseArea {
                        id: diagMA; anchors.fill: parent
                        onClicked: runFileDiagnostic()
                    }
                }

                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#22405a" : "#1e3a52"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label +
                                      (modelData.geometryType === "line" ? "  ⟶" : "")
                                color: "#e8eaf0"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#5ba3ff"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── MODALE VERTICE / FINE TRATTA con voice input ────────────
    Rectangle {
        id: vertexChoice
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 460)
            height: vcCol.implicitHeight + 32
            color: "#1a1d27"; radius: 12

            Column {
                id: vcCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 12

                Text {
                    width: parent.width
                    text: "Disegno tratta"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    id: vertexCountText
                    width: parent.width
                    text: ""
                    color: "#a8f0c6"; font.pixelSize: 13
                    horizontalAlignment: Text.AlignHCenter
                }

                // Voice input per vertice
                Rectangle {
                    width: parent.width; height: 44
                    color: "#22263a"; radius: 8
                    border.color: vertexVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: vertexVoiceInput
                        anchors.fill: parent
                        anchors.leftMargin: 10; anchors.rightMargin: 10
                        color: "#e8eaf0"; background: null
                        font.pixelSize: 14
                        placeholderText: "🎤 'vertice' o 'fine tratta'"
                        placeholderTextColor: "#5a6378"
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: vM.pressed ? "#1a3a5a" : "#1e3a52"
                    border.color: "#2a5a8a"; border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "📍"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "VERTICE intermedio"
                               color: "#e8eaf0"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: vM; anchors.fill: parent
                        onClicked: addIntermediateVertex()
                    }
                }

                Rectangle {
                    width: parent.width; height: 60; radius: 10
                    color: fM.pressed ? "#178a3e" : "#1db954"
                    Row {
                        anchors.centerIn: parent; spacing: 12
                        Text { text: "🏁"; font.pixelSize: 22
                               anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "FINE TRATTA"
                               color: "white"; font.pixelSize: 16; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: fM; anchors.fill: parent
                        onClicked: endLineAndOpenForm()
                    }
                }

                Rectangle {
                    width: parent.width; height: 42; radius: 8
                    color: cancM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                    Text { anchors.centerIn: parent; text: "✕ Annulla tratta"
                           color: "#8890a8"; font.pixelSize: 14 }
                    MouseArea {
                        id: cancM; anchors.fill: parent
                        onClicked: {
                            vertexChoice.visible = false
                            closeAll()
                            mainWindow.displayToast("Tratta annullata")
                        }
                    }
                }
            }
        }
    }

    function addIntermediateVertex() {
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            Qt.inputMethod.hide()
            return
        }
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        // Nascondi tastiera: torniamo alla mappa fra un vertice e l'altro
        Qt.inputMethod.hide()
        mainWindow.displayToast("📍 Vertice " + plugin.lineVertices.length + " salvato")
    }

    function endLineAndOpenForm() {
        if (!plugin.pendingValid) {
            mainWindow.displayToast("⚠ GPS non valido")
            vertexChoice.visible = false
            return
        }
        plugin.lineVertices.push({ x: plugin.pendingX, y: plugin.pendingY })
        plugin.pendingValid = false
        vertexChoice.visible = false
        mainWindow.displayToast("🏁 Tratta chiusa con " +
                                plugin.lineVertices.length + " vertici")

        var def = plugin.selectedLayerDef
        if (def && def.lengthField) {
            var lengthM = calculateLineLength()
            var formatted = lengthM.toFixed(1)
            var d = plugin.parsedData
            d[def.lengthField] = formatted
            plugin.parsedData = d
            var n = 0
            for (var k in d) if (d[k] !== "") n++
            plugin.okCount = n
            fieldsModel.refresh()
        }

        overlay.visible = true
        focusTimer.start()
        broadcastEvent("FORM_READY")
        emitVoiceReady()
    }

    function calculateLineLength() {
        if (plugin.lineVertices.length < 2) return 0
        var total = 0
        var isGeographic = false
        try {
            isGeographic = qgisProject.crs && qgisProject.crs.isGeographic
        } catch(e) {
            var v = plugin.lineVertices[0]
            isGeographic = (Math.abs(v.x) <= 180 && Math.abs(v.y) <= 90)
        }
        for (var i = 1; i < plugin.lineVertices.length; i++) {
            var v1 = plugin.lineVertices[i-1]
            var v2 = plugin.lineVertices[i]
            if (isGeographic) {
                total += haversineDistance(v1.y, v1.x, v2.y, v2.x)
            } else {
                var dx = v2.x - v1.x
                var dy = v2.y - v1.y
                total += Math.sqrt(dx*dx + dy*dy)
            }
        }
        return total
    }

    function haversineDistance(lat1, lon1, lat2, lon2) {
        var R = 6371000
        var toRad = Math.PI / 180
        var dLat = (lat2 - lat1) * toRad
        var dLon = (lon2 - lon1) * toRad
        var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
        return R * c
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.90, 720)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = plugin.selectedLayerDef
                            if (!def) return "⚡ Voice Parser"
                            var suffix = (def.geometryType === "line")
                                ? "  (" + plugin.lineVertices.length + " vertici)"
                                : ""
                            return def.icon + " " + def.label + suffix
                        }
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#1a3a5a" : "#22263a"
                        border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#8890a8"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 56
                    color: "#22263a"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "🎤 Parla ora oppure digita..."
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            onTextChanged: { if (text.length > 2) processVoice(text) }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldType === "picker" ? "▾" : "✎"
                                color: "#5ba3ff"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = model.fieldOptions
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                Rectangle {
                    Layout.fillWidth: true
                    height: 52; radius: 8
                    color: fotoM.pressed ? "#1a3a5a" : (plugin.photo1Path !== "" ? "#0a2018" : "#22263a")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#3a3d50"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text {
                            text: plugin.photo1Path !== "" ? "✅" : "📷"
                            font.pixelSize: 20
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: plugin.photo1Path !== ""
                                  ? "Foto acquisita ✔"
                                  : "Scatta foto (di' 'scatta foto')"
                            color: plugin.photo1Path !== "" ? "#a8f0c6" : "#8890a8"
                            font.pixelSize: 14
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: triggerPhotoCapture()
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma\" per salvare · \"scatta foto\" per la foto"
                    color: "#5ba3ff"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#5ba3ff"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#e8eaf0"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = plugin.parsedData
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // ── CAMERA con auto-cattura via intent broadcast ────────────
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                id: cameraItem
                visible: false
                Component.onCompleted: {
                    open()
                    if (plugin.autoCaptureMs > 0) autoCapTimer.start()
                }

                Timer {
                    id: autoCapTimer
                    interval: plugin.autoCaptureMs
                    repeat: false
                    onTriggered: {
                        mainWindow.displayToast("📸 Scatto in corso...")
                        // Invia intent broadcast — MacroDroid intercetta e
                        // simula il tap sul tasto scatto via accessibility
                        broadcastEvent("AUTO_SHUTTER")
                        // Secondo intent dopo 1.5s per il tap di conferma
                        confirmCapTimer.start()
                    }
                }

                Timer {
                    id: confirmCapTimer
                    interval: 1500
                    repeat: false
                    onTriggered: broadcastEvent("AUTO_CONFIRM")
                }

                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    plugin.photo1Path = filename
                    mainWindow.displayToast("📷 Foto acquisita!")
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onCanceled: {
                    close()
                    broadcastEvent("PHOTO_DONE")
                    photoReturnTimer.start()
                }
                onClosed: cameraLoader.active = false
            }
        }
    }

    // ── MENU RADIAL (preset per layer con presets) ──────────────
    Rectangle {
        id: radialMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#dd000000"
        MouseArea { anchors.fill: parent }

        // Pannello centrale: ruota radiale con bottoni intorno
        Item {
            id: wheelArea
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.92, 660)
            height: width

            // Titolo
            Text {
                anchors.top: parent.top
                anchors.horizontalCenter: parent.horizontalCenter
                text: {
                    var def = plugin.selectedLayerDef
                    return (def ? def.icon + " " + def.label : "") + " - Preset"
                }
                color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
            }

            // Cerchio centrale con bottone X (annulla)
            Rectangle {
                anchors.centerIn: parent
                width: 100; height: 100; radius: 50
                color: cnclMA.pressed ? "#5a1a1a" : "#3a1a1a"
                border.color: "#8a3a3a"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 2
                    Text { text: "✕"; color: "white"; font.pixelSize: 24
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                    Text { text: "annulla"; color: "#bbb"; font.pixelSize: 10
                           horizontalAlignment: Text.AlignHCenter
                           anchors.horizontalCenter: parent.horizontalCenter }
                }
                MouseArea {
                    id: cnclMA; anchors.fill: parent
                    onClicked: { radialMenu.visible = false; closeAll() }
                }
            }

            // Bottoni preset disposti in cerchio
            Repeater {
                model: plugin.currentPresets
                delegate: Rectangle {
                    readonly property real myAngle: (index / Math.max(plugin.currentPresets.length, 1)) * 2 * Math.PI - Math.PI / 2
                    readonly property real distance: wheelArea.width * 0.38
                    width: 100; height: 100; radius: 50
                    x: wheelArea.width / 2 + Math.cos(myAngle) * distance - width / 2
                    y: wheelArea.height / 2 + Math.sin(myAngle) * distance - height / 2
                    color: presetMA.pressed ? "#2a5a8a" : "#1e3a52"
                    border.color: "#5ba3ff"; border.width: 2

                    Column {
                        anchors.centerIn: parent; spacing: 1
                        // Immagine (se preset ha "image") oppure emoji "icon"
                        Item {
                            width: 56; height: 56
                            anchors.horizontalCenter: parent.horizontalCenter
                            Image {
                                anchors.fill: parent
                                source: modelData.image
                                       ? Qt.resolvedUrl(modelData.image)
                                       : ""
                                fillMode: Image.PreserveAspectFit
                                smooth: true
                                visible: modelData.image ? true : false
                                asynchronous: true
                            }
                            Text {
                                anchors.centerIn: parent
                                visible: !modelData.image
                                text: modelData.icon || "•"
                                font.pixelSize: 28
                            }
                        }
                        Text {
                            text: "" + modelData.id
                            color: "#5ba3ff"; font.pixelSize: 13; font.bold: true
                            horizontalAlignment: Text.AlignHCenter
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                        Text {
                            text: modelData.label
                            color: "#a8b0c8"; font.pixelSize: 8
                            width: 90
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                    }

                    MouseArea {
                        id: presetMA; anchors.fill: parent
                        onClicked: selectPreset(modelData)
                    }
                }
            }
        }

        // Input vocale in basso (numero)
        Rectangle {
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 80
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(parent.width * 0.7, 360)
            height: 50
            color: "#22263a"; radius: 8
            border.color: radialVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
            border.width: 2
            TextField {
                id: radialVoiceInput
                anchors.fill: parent
                anchors.leftMargin: 12; anchors.rightMargin: 12
                color: "#e8eaf0"; background: null
                font.pixelSize: 16
                placeholderText: "🎤 di' il numero (uno, due, tre...)"
                placeholderTextColor: "#5a6378"
            }
        }
    }

    // ── DIALOG DIAGNOSTICA (persistente, leggibile con calma) ──
    Rectangle {
        id: diagDialog
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 11000; color: "#dd000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.95, 700)
            height: Math.min(parent.height * 0.85, 700)
            color: "#1a1d27"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                Text {
                    width: parent.width
                    text: "🔧 Risultato diagnostica"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width
                    height: parent.height - 90
                    color: "#0a0d17"; radius: 8
                    border.color: "#3a3d50"; border.width: 1
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        clip: true
                        TextArea {
                            id: diagLogArea
                            text: plugin.diagLog
                            color: "#a8f0c6"
                            font.family: "monospace"
                            font.pixelSize: 11
                            readOnly: true
                            wrapMode: TextArea.Wrap
                            background: null
                        }
                    }
                }

                Rectangle {
                    width: parent.width; height: 44; radius: 8
                    color: closeDiagMA.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ CHIUDI"
                           color: "white"; font.pixelSize: 14; font.bold: true }
                    MouseArea {
                        id: closeDiagMA; anchors.fill: parent
                        onClicked: diagDialog.visible = false
                    }
                }
            }
        }
    }

    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureForm.save()
            drawer.close()
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            closeAll()
        }
    }

    // Dopo chiusura camera, riporta focus al form ed emette VOICE_INPUT_READY
    Timer {
        id: photoReturnTimer
        interval: 350
        repeat: false
        onTriggered: {
            if (overlay.visible) {
                inputArea.forceActiveFocus()
                Qt.inputMethod.show()
                emitVoiceReady()
            }
        }
    }

    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                var val = plugin.parsedData[fd.key] || ""
                append({
                    fieldLabel:   fd.label,
                    fieldKey:     fd.key,
                    fieldValue:   val,
                    fieldOk:      val !== "",
                    fieldType:    fd.type,
                    fieldOptions: fd.options || []
                })
            }
        }
        Component.onCompleted: refresh()
    }

    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function parseText(raw) {
        var t = raw.toLowerCase()
        var d = {}

        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""

            if (fd.type === "picker" && fd.options) {
                for (var j = 0; j < fd.options.length; j++) {
                    if (t.indexOf(fd.options[j].toLowerCase()) !== -1) {
                        d[fd.key] = fd.options[j]; break
                    }
                }
                if (fd.key === "STATO_1") {
                    if (t.indexOf("non realizzato") !== -1 || t.indexOf("non fatto") !== -1)
                        d[fd.key] = "NON Realizzato"
                    else if (t.indexOf("realizzato") !== -1 || t.indexOf("nuovo") !== -1)
                        d[fd.key] = "Realizzato"
                    else if (t.indexOf("esistente") !== -1 || t.indexOf("presente") !== -1)
                        d[fd.key] = "Esistente"
                }
                if (fd.key === "DESCRIPTIO" && plugin.selectedLayerName === "PTE") {
                    if (t.indexOf("muro esterno") !== -1 || t.indexOf("palifica") !== -1)
                        d[fd.key] = "PTE Muro Esterno/Palifica"
                    else if (t.indexOf("sotterraneo") !== -1)
                        d[fd.key] = "PTE Sotterraneo"
                    else if (t.indexOf("colonnina") !== -1)
                        d[fd.key] = "PTE Colonnina"
                    else if (t.indexOf("interno") !== -1)
                        d[fd.key] = "PTE Interno"
                }
            } else if (fd.type === "text") {
                if (fd.auto === "length") {
                    var lm = t.match(/lunghezza\s+(\d+(?:[,.]\d+)?)/)
                    if (lm) d[fd.key] = lm[1].replace(",", ".")
                } else {
                    var kw = fd.label.toLowerCase()
                    var m  = t.match(new RegExp(kw + "\\s+(\\d+)"))
                    if (m) d[fd.key] = m[1]
                }
            }
        }

        plugin.parsedData = d
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    function buildLineWkt() {
        var coords = []
        for (var i = 0; i < plugin.lineVertices.length; i++) {
            var v = plugin.lineVertices[i]
            coords.push(v.x + " " + v.y)
        }
        return "MULTILINESTRING((" + coords.join(", ") + "))"
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        var def = plugin.selectedLayerDef
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }

        try {
            var wkt
            if (def && def.geometryType === "line") {
                if (plugin.lineVertices.length < 2) {
                    mainWindow.displayToast("⚠ Servono almeno 2 vertici per la tratta")
                    return
                }
                wkt = buildLineWkt()
            } else {
                if (!positionSource || !positionSource.active) {
                    mainWindow.displayToast("⚠ GPS non attivo!"); return
                }
                var pos = positionSource.projectedPosition
                wkt = "POINT(" + pos.x + " " + pos.y + ")"
            }

            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            if (plugin.photo1Path !== "") {
                var photoFieldName = (def && def.photoField) ? def.photoField : "Foto_1"
                var fi = fieldNames.indexOf(photoFieldName)
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }

            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}
