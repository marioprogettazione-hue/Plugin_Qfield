import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property int okCount: 0
    property var parsedData: ({
        stato:"", tipologia:"", quartina:"",
        armadio:"", tipo:"", cavi_attestati:"",
        ubicazione:"", note:""
    })

    property var fieldOptions: ({
        "stato":          ["realizzato","esistente","non realizzato","da progettare"],
        "tipologia":      ["muro esterno","interno edificio","muro interno","colonnina","sotterraneo"],
        "tipo":           ["transito","terminale"],
        "ubicazione":     ["androne","centralino","colonnina","cortile","incassato",
                           "intercapedine","interno cantine","interno garage",
                           "interno ingresso","marciapiede","muro esterno",
                           "palo","seminterrato","pozzetto","sottoscala"],
        "cavi_attestati": ["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"]
    })

    property var fieldDefs: [
        { key:"stato",          label:"STATO" },
        { key:"tipologia",      label:"TIPOLOGIA" },
        { key:"quartina",       label:"QUARTINA" },
        { key:"armadio",        label:"ARMADIO" },
        { key:"tipo",           label:"TIPO" },
        { key:"cavi_attestati", label:"CAVI" },
        { key:"ubicazione",     label:"UBICAZIONE" },
        { key:"note",           label:"NOTE" }
    ]

    property string activeFieldKey: ""
    property var activeFieldOptions: []

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        overlay.parent = mainWindow.contentItem
        picker.parent  = mainWindow.contentItem
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            resetData()
            updateGPS()
            overlay.visible = true
        }
    }

    function resetData() {
        inputArea.text = ""
        plugin.parsedData = { stato:"",tipologia:"",quartina:"",
            armadio:"",tipo:"",cavi_attestati:"",ubicazione:"",note:"" }
        plugin.okCount = 0
        fieldsModel.refresh()
    }

    // ── OVERLAY ─────────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false
        x: 0; y: 0
        width:  parent ? parent.width  : 0
        height: parent ? parent.height : 0
        z: 9999
        color: "#bb000000"

        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.92, 760)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "⚡ PTE Voice Parser"; color: "#5ba3ff"
                           font.pixelSize: 17; font.bold: true; Layout.fillWidth: true }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: overlay.visible = false }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 74
                    color: "#22263a"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Usa 🎤 tastiera: realizzato muro esterno quartina 14 armadio 6 terminale zero cavi palo"
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            onTextChanged: if (text.length > 2) plugin.parseText(text)
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / 8 campi ✔"
                    color: plugin.okCount >= 6 ? "#2ecc71" : plugin.okCount >= 3 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: plugin.fieldOptions[model.fieldKey] ? "▾" : ""
                                color: "#5ba3ff"; font.pixelSize: 14
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    var opts = plugin.fieldOptions[model.fieldKey]
                                    if (opts) {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = opts
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"; color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent; enabled: plugin.okCount > 0
                            onClicked: applyToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 400)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.7)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.pixelSize: 14
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── MODEL ───────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.fieldDefs.length; i++) {
                var fd = plugin.fieldDefs[i]
                var val = plugin.parsedData[fd.key] || ""
                append({ fieldLabel:fd.label, fieldKey:fd.key, fieldValue:val, fieldOk:val !== "" })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── FUNZIONI ────────────────────────────────────────────────
    function updateGPS() {
        var pos = iface.findItemByObjectName("positionSource")
        if (pos && pos.active) {
            var info = pos.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"
                return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function normalize(t) {
        t = t.toLowerCase()
        var fixes = [["muore esterno","muro esterno"],["moresterno","muro esterno"],
                     ["cavie","cavi"],["zero cavi","0 cavi"],["nessun cavo","0 cavi"]]
        for (var i = 0; i < fixes.length; i++) t = t.split(fixes[i][0]).join(fixes[i][1])
        return t
    }

    function findValue(text, key) {
        var map = {
            "stato": [["realizzato",["realizzato","realizzata","nuovo","nuova"]],
                      ["esistente",["esistente","presente"]],
                      ["non realizzato",["non realizzato","non fatto"]],
                      ["da progettare",["da progettare"]]],
            "tipologia": [["muro esterno",["muro esterno","facciata","su muro"]],
                          ["interno edificio",["interno edificio"]],
                          ["muro interno",["muro interno"]],
                          ["colonnina",["colonnina"]],
                          ["sotterraneo",["sotterraneo","sottoterra"]]],
            "tipo": [["transito",["transito","passante"]],["terminale",["terminale","finale"]]],
            "ubicazione": [["palo",["palo","su palo"]],["pozzetto",["pozzetto"]],
                           ["marciapiede",["marciapiede"]],["androne",["androne"]],
                           ["cortile",["cortile"]],["incassato",["incassato"]],
                           ["intercapedine",["intercapedine"]],["sottoscala",["sottoscala"]],
                           ["seminterrato",["seminterrato"]],["centralino",["centralino"]],
                           ["interno cantine",["cantine","interno cantine"]],
                           ["interno garage",["garage","interno garage"]],
                           ["interno ingresso",["ingresso","interno ingresso"]]]
        }
        var list = map[key] || []
        for (var i = 0; i < list.length; i++) {
            var syns = list[i][1]
            for (var j = 0; j < syns.length; j++)
                if (text.indexOf(syns[j]) !== -1) return list[i][0]
        }
        return ""
    }

    function extractQuartina(text) {
        var m = text.match(/da\s+(\d+)\s+a\s+(\d+)/)
        if (m) return m[1] + ":" + m[2]
        m = text.match(/quartina\s+(\d+)/)
        return m ? m[1] : ""
    }

    function extractNumber(text, keyword) {
        var m = text.match(new RegExp(keyword + "\\s+(\\d+)"))
        return m ? m[1] : ""
    }

    function extractCavi(text) {
        var numeri = {"zero":0,"uno":1,"una":1,"due":2,"tre":3,"quattro":4,
                      "cinque":5,"sei":6,"sette":7,"otto":8,"nove":9,"dieci":10,
                      "undici":11,"dodici":12,"tredici":13,"quattordici":14,"quindici":15}
        var m = text.match(/(\d+)\s+cavi/)
        if (m) return m[1]
        for (var k in numeri)
            if (text.indexOf(k + " cavi") !== -1) return String(numeri[k])
        return ""
    }

    function extractNote(text) {
        var m = text.match(/note[:\s]+(.+)/)
        return m ? m[1].trim() : ""
    }

    function parseText(raw) {
        var t = normalize(raw)
        var result = {
            stato: findValue(t,"stato"), tipologia: findValue(t,"tipologia"),
            quartina: extractQuartina(t), armadio: extractNumber(t,"armadio"),
            tipo: findValue(t,"tipo"), cavi_attestati: extractCavi(t),
            ubicazione: findValue(t,"ubicazione"), note: extractNote(t)
        }
        plugin.parsedData = result
        var n = 0
        for (var k in result) if (result[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    function getLayer() {
        // 1. dashBoard.activeLayer
        if (dashBoard && dashBoard.activeLayer)
            return dashBoard.activeLayer

        // 2. Cerca per nome nel progetto
        var mc = iface.mapCanvas()
        if (mc && mc.layers) {
            var layers = mc.layers()
            for (var i = 0; i < layers.length; i++) {
                if (layers[i].name && layers[i].name.toUpperCase().indexOf("STRUCTURE") >= 0)
                    return layers[i]
            }
        }
        return null
    }

    function applyToLayer() {
        var layer = getLayer()

        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona layer STRUCTURE nel pannello laterale!")
            return
        }

        // Debug: mostra nome layer trovato
        mainWindow.displayToast("Layer: " + layer.name + " — salvo attributi...")

        if (!layer.isEditable()) layer.startEditing()

        var flds = layer.fields()
        var d = plugin.parsedData
        var keys = ["stato","tipologia","quartina","armadio","tipo","cavi_attestati","ubicazione","note"]
        var saved = 0

        for (var i = 0; i < keys.length; i++) {
            var val = d[keys[i]]
            if (val !== undefined && val !== "") {
                var idx = flds.indexFromName(keys[i])
                if (idx >= 0) {
                    layer.setDefaultValueDefinition(idx, val)
                    saved++
                } else {
                    // campo non trovato — mostra warning
                    mainWindow.displayToast("Campo '" + keys[i] + "' non trovato nel layer!")
                }
            }
        }

        mainWindow.displayToast("✅ " + saved + " attributi salvati come default — premi + per il punto")
        overlay.visible = false
        resetData()
    }
}
