import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    property int okCount: 0
    property bool isListening: false
    property var parsedData: ({
        STATO_1:"", DESCRIPTIO:"", Label:"", ArmadioId:"", Posizione:""
    })

    property var fieldOptions: ({
        "STATO_1":   ["Realizzato","NON Realizzato","Esistente"],
        "DESCRIPTIO":["PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"],
        "Posizione": ["Androne","Centralino","Colonnina","Cortile","Divisorio","Incassato",
                      "Intercapedine","Interno Garage","Interno Ingresso","Marciapiede",
                      "Muro Esterno","Palo","Pontile","Pozzetto","Seminterrato","Sottoscala"]
    })

    property var fieldDefs: [
        { key:"STATO_1",    label:"STATO" },
        { key:"DESCRIPTIO", label:"TIPOLOGIA" },
        { key:"Label",      label:"QUARTINA" },
        { key:"ArmadioId",  label:"ARMADIO" },
        { key:"Posizione",  label:"UBICAZIONE" }
    ]

    property string activeFieldKey: ""
    property var activeFieldOptions: []

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        overlay.parent = mainWindow.contentItem
        picker.parent  = mainWindow.contentItem
        freeTextEditor.parent = mainWindow.contentItem
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            resetData()
            updateGPS()
            overlay.visible = true
            // Avvia microfono automaticamente dopo 600ms
            micTimer.start()
        }
    }

    // Timer per avviare il mic dopo che l'overlay è visibile
    Timer {
        id: micTimer
        interval: 600
        repeat: false
        onTriggered: startListening()
    }

    // Timer per riavviare ascolto continuo
    Timer {
        id: restartTimer
        interval: 300
        repeat: false
        onTriggered: {
            if (overlay.visible) startListening()
        }
    }

    function resetData() {
        plugin.parsedData = { STATO_1:"", DESCRIPTIO:"", Label:"", ArmadioId:"", Posizione:"" }
        plugin.okCount = 0
        plugin.isListening = false
        fieldsModel.refresh()
    }

    // ── RICONOSCIMENTO VOCALE ────────────────────────────────────
    // Usa SpeechRecognition via android intent attraverso platformUtilities
    function startListening() {
        plugin.isListening = true
        micStatusText.text = "🔴 In ascolto..."
        micStatusText.color = "#e74c3c"
        // Apre il riconoscimento vocale Android nativo
        Qt.openUrlExternally("android.speech.action.RECOGNIZE_SPEECH")
    }

    function stopListening() {
        plugin.isListening = false
        micStatusText.text = "🎤 Tocca per parlare"
        micStatusText.color = "#8890a8"
    }

    function processVoice(text) {
        var t = text.toLowerCase()

        // Comando "conferma modulo"
        if (t.indexOf("conferma modulo") !== -1 || t.indexOf("conferma") !== -1) {
            if (plugin.okCount > 0) {
                saveToLayer()
                return
            }
        }

        // Comando "cancella"
        if (t.indexOf("cancella tutto") !== -1) {
            resetData()
            return
        }

        // Parser normale
        parseText(text)

        // Riavvia ascolto per input continuo
        restartTimer.start()
    }

    // ── OVERLAY PRINCIPALE ───────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.90, 720)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                // Header
                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "⚡ PTE Voice Parser"; color: "#5ba3ff"
                           font.pixelSize: 17; font.bold: true; Layout.fillWidth: true }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent
                            onClicked: { stopListening(); overlay.visible = false } }
                    }
                }

                // GPS
                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                // Stato microfono + bottone
                Rectangle {
                    Layout.fillWidth: true; height: 52
                    color: "#22263a"; radius: 8
                    border.color: plugin.isListening ? "#e74c3c" : "#3a3d50"
                    border.width: plugin.isListening ? 2 : 1

                    RowLayout {
                        anchors.fill: parent; anchors.margins: 10; spacing: 10

                        Text {
                            id: micStatusText
                            text: "🎤 Tocca per parlare"
                            color: "#8890a8"; font.pixelSize: 13
                            Layout.fillWidth: true
                        }

                        Rectangle {
                            width: 36; height: 36; radius: 18
                            color: plugin.isListening ? "#e74c3c" : "#3d8ef0"
                            Text { anchors.centerIn: parent; text: "🎤"; font.pixelSize: 16 }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (plugin.isListening) stopListening()
                                    else startListening()
                                }
                            }
                        }
                    }
                }

                // Campo testo trascrizione (mostra quello che ha capito)
                Rectangle {
                    Layout.fillWidth: true; height: 54
                    color: "#22263a"; radius: 8
                    border.color: "#3a3d50"; border.width: 1
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Trascrizione vocale apparirà qui..."
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            readOnly: false
                            onTextChanged: if (text.length > 2) plugin.parseText(text)
                        }
                    }
                }

                // Contatore
                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / 5 campi ✔"
                    color: plugin.okCount >= 4 ? "#2ecc71" : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                // Griglia campi
                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: plugin.fieldOptions[model.fieldKey] ? "▾" : "✎"
                                color: "#5ba3ff"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    stopListening()
                                    var opts = plugin.fieldOptions[model.fieldKey]
                                    if (opts) {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = opts
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Istruzioni vocali
                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma modulo\" per salvare"
                    color: "#5ba3ff"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                // Bottoni
                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"; color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent
                            onClicked: { resetData(); inputArea.text = "" } }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent; enabled: plugin.okCount > 0
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.pixelSize: 14
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#5ba3ff"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#e8eaf0"; background: null; font.pixelSize: 16
                        inputMethodHints: Qt.ImhNone
                        Component.onCompleted: forceActiveFocus()
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = plugin.parsedData
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // ── MODEL ───────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.fieldDefs.length; i++) {
                var fd = plugin.fieldDefs[i]
                var val = plugin.parsedData[fd.key] || ""
                append({ fieldLabel:fd.label, fieldKey:fd.key, fieldValue:val, fieldOk:val !== "" })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── FUNZIONI ────────────────────────────────────────────────
    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function normalize(t) {
        t = t.toLowerCase()
        var fixes = [
            ["muro esterno palifica", "PTE Muro Esterno/Palifica"],
            ["muro esterno",          "PTE Muro Esterno/Palifica"],
            ["pte interno",           "PTE Interno"],
            ["sotterraneo",           "PTE Sotterraneo"],
            ["pte colonnina",         "PTE Colonnina"],
            ["non realizzato",        "NON Realizzato"],
            ["non fatto",             "NON Realizzato"]
        ]
        for (var i = 0; i < fixes.length; i++)
            t = t.split(fixes[i][0]).join(fixes[i][1])
        return t
    }

    function findStato(t) {
        if (t.indexOf("NON Realizzato") !== -1) return "NON Realizzato"
        if (t.indexOf("realizzato") !== -1)     return "Realizzato"
        if (t.indexOf("esistente") !== -1 || t.indexOf("presente") !== -1) return "Esistente"
        return ""
    }

    function findTipologia(t) {
        if (t.indexOf("PTE Muro Esterno/Palifica") !== -1) return "PTE Muro Esterno/Palifica"
        if (t.indexOf("PTE Sotterraneo") !== -1)           return "PTE Sotterraneo"
        if (t.indexOf("PTE Colonnina") !== -1)             return "PTE Colonnina"
        if (t.indexOf("PTE Interno") !== -1)               return "PTE Interno"
        return ""
    }

    function findPosizione(t) {
        var opts = ["Androne","Centralino","Colonnina","Cortile","Divisorio","Incassato",
                    "Intercapedine","Interno Garage","Interno Ingresso","Marciapiede",
                    "Muro Esterno","Palo","Pontile","Pozzetto","Seminterrato","Sottoscala"]
        var tl = t.toLowerCase()
        for (var i = 0; i < opts.length; i++)
            if (tl.indexOf(opts[i].toLowerCase()) !== -1) return opts[i]
        return ""
    }

    function extractNumber(text, keyword) {
        var m = text.toLowerCase().match(new RegExp(keyword + "\\s+(\\d+)"))
        return m ? m[1] : ""
    }

    function parseText(raw) {
        var t = normalize(raw)
        var result = {
            STATO_1:    findStato(t),
            DESCRIPTIO: findTipologia(t),
            Label:      extractNumber(raw, "quartina"),
            ArmadioId:  extractNumber(raw, "armadio"),
            Posizione:  findPosizione(t)
        }
        plugin.parsedData = result
        var n = 0
        for (var k in result) if (result[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()

        // aggiorna il campo testo con il riconosciuto
        inputArea.text = raw
    }

    function saveToLayer() {
        stopListening()

        var layer = dashBoard ? dashBoard.activeLayer : null
        if (!layer) { mainWindow.displayToast("⚠ Seleziona layer PTE!"); return }

        if (!positionSource || !positionSource.active ||
            !positionSource.positionInformation.latitudeValid) {
            mainWindow.displayToast("⚠ GPS non attivo!"); return
        }

        // Crea geometria punto
        var pos = GeometryUtils.reprojectPoint(
            positionSource.projectedPosition,
            positionSource.coordinateTransformer.destinationCrs,
            layer.crs
        )
        var geometry = GeometryUtils.createGeometryFromWkt('POINT(' + pos.x + ' ' + pos.y + ')')
        var feature  = FeatureUtils.createBlankFeature(layer.fields, geometry)

        // Applica attributi
        var d = plugin.parsedData
        var keys = ["STATO_1","DESCRIPTIO","Label","ArmadioId","Posizione"]
        var saved = 0
        for (var i = 0; i < keys.length; i++) {
            var val = d[keys[i]]
            if (val && val !== "") {
                var idx = feature.fields.names.indexOf(keys[i])
                if (idx >= 0) { feature.setAttribute(idx, val); saved++ }
            }
        }

        // Salva DIRETTAMENTE nel layer — niente form QField
        if (!layer.isEditable()) layer.startEditing()
        layer.addFeature(feature)
        layer.commitChanges()

        mainWindow.displayToast("✅ Punto PTE salvato con " + saved + " attributi!")
        overlay.visible = false

        // Reset per prossimo rilievo
        inputArea.text = ""
        resetData()
    }
}
