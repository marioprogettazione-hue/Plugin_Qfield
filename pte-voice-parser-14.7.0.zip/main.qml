import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null

    property int okCount: 0
    property var parsedData: ({})

    // ── DEFINIZIONE LAYER E CAMPI ────────────────────────────────
    // Ogni layer ha: name (nome nel gpkg), label (etichetta), icon, fields
    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            fields: [
                { key:"Label",      label:"QUARTINA",   type:"text" },
                { key:"DESCRIPTIO", label:"TIPOLOGIA",  type:"picker",
                  options:["PTE Muro Esterno","PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"] },
                { key:"ArmadioId",  label:"ARMADIO",    type:"text" },
                { key:"Posizione",  label:"UBICAZIONE", type:"picker",
                  options:["Muro Esterno","Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Palo","Pontile","Pozzetto","Seminterrato","Sottoscala"] },
                { key:"STATO_1",    label:"STATO",      type:"picker",
                  options:["Esistente","Realizzato","NON Realizzato"] }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄️",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"Label",      label:"LABEL",    type:"text" },
                { key:"DESCRIPTIO", label:"NOTE",     type:"text" }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰️",
            fields: [{ key:"OBJECTID", label:"OBJECT ID", type:"text" }]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte", icon: "⛏️",
            fields: [{ key:"OBJECTID", label:"OBJECT ID", type:"text" }]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"DESCRIPTIO", label:"TIPO",     type:"text" },
                { key:"Label",      label:"LABEL",    type:"text" }
            ]
        },
        {
            name: "STRUCTURE", label: "Structure", icon: "🏗️",
            fields: [
                { key:"OBJECTID",   label:"OBJECT ID",  type:"text" },
                { key:"MAIN_SUB_1", label:"MAIN SUB",   type:"text" }
            ]
        }
    ]

    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []
    property string lastParsedText: ""
    property string photo1Path: ""
    property bool lineMode: false
    property var linePoints: []
    property var lineLayerNames: ["RACCORDI", "TRATTE INTERRATE"]

    property var ptePresets: [
        { num:1, label:"PTE Interno",      icon:Qt.resolvedUrl("pte_1.png"), values:{"DESCRIPTIO":"PTE Interno Edificio",       "STATO_1":"Realizzato"} },
        { num:2, label:"PTE Muro Esterno", icon:Qt.resolvedUrl("pte_2.png"), values:{"DESCRIPTIO":"PTE Muro Esterno/Palifica",  "STATO_1":"Realizzato"} },
        { num:3, label:"PTE Sotterraneo",  icon:Qt.resolvedUrl("pte_3.png"), values:{"DESCRIPTIO":"PTE Sotterraneo",            "STATO_1":"Realizzato"} },
        { num:4, label:"PTE Colonnina",    icon:Qt.resolvedUrl("pte_4.png"), values:{"DESCRIPTIO":"PTE Colonnina",              "STATO_1":"Realizzato"} }
    ]

    // Timer polling: controlla ogni 500ms se il testo è cambiato
    // Necessario perché la tastiera vocale Android non sempre
    // trigghera onTextChanged correttamente
    Timer {
        id: pollTimer
        interval: 500
        repeat: true
        running: overlay.visible
        onTriggered: {
            if (inputArea.text !== plugin.lastParsedText && inputArea.text.length > 2) {
                plugin.lastParsedText = inputArea.text
                processVoice(inputArea.text)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        layerPicker.parent = mainWindow.contentItem
        overlay.parent        = mainWindow.contentItem
        picker.parent         = mainWindow.contentItem
        presetMenu.parent     = mainWindow.contentItem
        lineChoiceOverlay.parent = mainWindow.contentItem
        freeTextEditor.parent = mainWindow.contentItem
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    // ── TASTO BT ────────────────────────────────────────────────
    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible) {
            closeAll()
        } else if (layerPicker.visible) {
            closeAll()
        } else {
            // Mostra prima il selettore layer
            updateGPS()
            layerPicker.visible = true
        }
    }

    function closeAll() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        resetData()
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: togglePanel()
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        // Metodo corretto da VocalField:
        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            plugin.selectedLayer = layer
            dashBoard.activeLayer = layer
            mainWindow.displayToast("✅ Layer attivo: " + layerDef.name)
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        resetData()
        layerPicker.visible = false

        if (plugin.lineLayerNames.indexOf(layerDef.name) !== -1) {
            // Layer lineare
            plugin.lineMode = true
            plugin.linePoints = []
            if (positionSource && positionSource.active) {
                var pos = positionSource.projectedPosition
                plugin.linePoints = [{ x: pos.x, y: pos.y }]
                mainWindow.displayToast("🟢 Punto 1 salvato — spostati e premi BT")
            } else {
                mainWindow.displayToast("⚠ GPS non attivo!")
                plugin.lineMode = false
            }
        } else if (layerDef.name === "PTE") {
            // PTE: mostra menu preset
            plugin.lineMode = false
            presetMenu.visible = true
            presetFocusTimer.start()
        } else {
            // Altri layer puntuali
            plugin.lineMode = false
            overlay.visible = true
            focusTimer.start()
        }
    }

    function findLayer(name) {
        // Usa il layer trovato e impostato in selectLayer
        if (plugin.selectedLayer) return plugin.selectedLayer
        if (dashBoard && dashBoard.activeLayer)
            return dashBoard.activeLayer
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++)
            d[plugin.currentFields[i].key] = ""
        plugin.parsedData = d
        plugin.okCount = 0
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 400; repeat: false
        onTriggered: { inputArea.forceActiveFocus(); Qt.inputMethod.show() }
    }

    function processVoice(text) {
        var t = text.toLowerCase()
        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                // Bottoni layer
                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#22405a" : "#1e3a52"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label
                                color: "#e8eaf0"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#5ba3ff"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.90, 720)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = null
                            for (var i = 0; i < plugin.layerDefs.length; i++)
                                if (plugin.layerDefs[i].name === plugin.selectedLayerName)
                                    def = plugin.layerDefs[i]
                            return def ? def.icon + " " + def.label : "⚡ Voice Parser"
                        }
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    // Bottone cambia layer
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#1a3a5a" : "#22263a"
                        border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#8890a8"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 56
                    color: "#22263a"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Usa 🎤 tastiera oppure digita..."
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            // onTextChanged per digitazione normale
                            onTextChanged: {
                                if (text.length > 2) processVoice(text)
                            }
                            // onEditingFinished per input vocale Android
                            // (la tastiera vocale scrive tutto in un colpo)
                            Component.onCompleted: {
                                inputArea.textChanged.connect(function() {
                                    parseTimer.restart()
                                })
                            }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldType === "picker" ? "▾" : "✎"
                                color: "#5ba3ff"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = model.fieldOptions
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Bottone foto
                Rectangle {
                    Layout.fillWidth: true
                    height: 52; radius: 8
                    color: fotoM.pressed ? "#1a3a5a" : (plugin.photo1Path !== "" ? "#0a2018" : "#22263a")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#3a3d50"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text {
                            text: plugin.photo1Path !== "" ? "✅" : "📷"
                            font.pixelSize: 20
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: plugin.photo1Path !== "" ? "Foto acquisita ✔" : "Scatta foto"
                            color: plugin.photo1Path !== "" ? "#a8f0c6" : "#8890a8"
                            font.pixelSize: 14
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: {
                            platformUtilities.createDir(qgisProject.homePath, "DCIM")
                            // Invia broadcast Android che MacroDroid intercetta
                            // come trigger "Intento ricevuto"
                            Qt.openUrlExternally("intent://pte.plugin.FOTO_SCATTA#Intent;scheme=pte;end")
                            cameraLoader.active = true
                        }
                    }
                }

                                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma\" per salvare"
                    color: "#5ba3ff"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── MENU PRESET PTE ─────────────────────────────────────────
    Rectangle {
        id: presetMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.95, 620)
            height: presetCol.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: presetCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                // Header
                RowLayout {
                    width: parent.width
                    Text {
                        text: "📡 Seleziona tipo PTE"
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true
                        Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: skipM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea {
                            id: skipM; anchors.fill: parent
                            onClicked: {
                                presetMenu.visible = false
                                overlay.visible = true
                                focusTimer.start()
                            }
                        }
                    }
                }

                // Campo vocale numero
                Rectangle {
                    width: parent.width; height: 44
                    color: "#22263a"; radius: 8
                    border.color: presetVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextArea {
                        id: presetVoiceInput
                        anchors.fill: parent; anchors.margins: 8
                        placeholderText: "🎤 Di' il numero (1,2,3,4)..."
                        color: "#e8eaf0"; font.pixelSize: 13; background: null
                        onTextChanged: {
                            var n = parseInt(text.trim())
                            if (n >= 1 && n <= plugin.ptePresets.length) {
                                presetVoiceTimer.restart()
                            }
                        }
                    }
                }

                Timer {
                    id: presetVoiceTimer
                    interval: 600; repeat: false
                    onTriggered: {
                        var n = parseInt(presetVoiceInput.text.trim())
                        if (n >= 1 && n <= plugin.ptePresets.length) {
                            applyPreset(n - 1)
                        }
                    }
                }

                Timer {
                    id: presetPollTimer
                    interval: 500; repeat: true
                    running: presetMenu.visible
                    onTriggered: {
                        if (presetVoiceInput.text.length > 0) presetVoiceTimer.restart()
                    }
                }

                // Griglia preset 2 colonne
                GridLayout {
                    width: parent.width
                    columns: 2; columnSpacing: 8; rowSpacing: 8

                    Repeater {
                        model: plugin.ptePresets
                        delegate: Rectangle {
                            Layout.fillWidth: true
                            height: 130; radius: 10
                            color: presetItemM.pressed ? "#22405a" : "#1e3a52"
                            border.color: "#2a5a8a"; border.width: 1.5

                            Column {
                                anchors.fill: parent; anchors.margins: 8
                                spacing: 6

                                // Numero
                                Rectangle {
                                    width: 28; height: 28; radius: 14
                                    color: "#3d8ef0"
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    Text {
                                        anchors.centerIn: parent
                                        text: modelData.num
                                        color: "white"; font.pixelSize: 14; font.bold: true
                                    }
                                }

                                // Icona
                                Image {
                                    width: 64; height: 64
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    source: modelData.icon
                                    fillMode: Image.PreserveAspectFit
                                }

                                // Label
                                Text {
                                    width: parent.width
                                    text: modelData.label
                                    color: "#e8eaf0"; font.pixelSize: 11
                                    horizontalAlignment: Text.AlignHCenter
                                    wrapMode: Text.Wrap
                                }
                            }

                            MouseArea {
                                id: presetItemM; anchors.fill: parent
                                onClicked: applyPreset(index)
                            }
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── SCELTA VERTICE / FINE TRATTA ────────────────────────────
    Rectangle {
        id: lineChoiceOverlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#cc000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 480)
            height: 190; color: "#1a1d27"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 16; spacing: 12

                Text {
                    width: parent.width
                    text: "Punto " + plugin.linePoints.length + " salvato"
                    color: "#5ba3ff"; font.pixelSize: 16; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width; height: 54; radius: 8
                    color: verticeM.pressed ? "#1a3a5a" : "#1e3a52"
                    border.color: "#2a5a8a"; border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 10
                        Text { text: "🔵"; font.pixelSize: 22; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "Vertice — continua tratta"
                               color: "#e8eaf0"; font.pixelSize: 15; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: verticeM; anchors.fill: parent
                        onClicked: {
                            lineChoiceOverlay.visible = false
                            mainWindow.displayToast("🔵 Vertice salvato — spostati e premi BT")
                        }
                    }
                }

                Rectangle {
                    width: parent.width; height: 54; radius: 8
                    color: fineM.pressed ? "#178a3e" : "#1db954"
                    Row {
                        anchors.centerIn: parent; spacing: 10
                        Text { text: "🔴"; font.pixelSize: 22; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: "Fine tratta — compila e salva"
                               color: "white"; font.pixelSize: 15; font.bold: true
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: fineM; anchors.fill: parent
                        onClicked: saveLineFeature()
                    }
                }
            }
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#5ba3ff"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#e8eaf0"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = plugin.parsedData
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // Camera loader - metodo esatto plugin snap ufficiale
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                visible: false
                Component.onCompleted: open()
                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    plugin.photo1Path = filename
                    mainWindow.displayToast("📷 Foto acquisita!")
                }
                onCanceled: close()
                onClosed: cameraLoader.active = false
            }
        }
    }

    // Timer per auto-salvataggio e chiusura form
    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureForm.save()
            drawer.close()
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            closeAll()
        }
    }

    // ── MODEL ───────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                var val = plugin.parsedData[fd.key] || ""
                append({
                    fieldLabel:   fd.label,
                    fieldKey:     fd.key,
                    fieldValue:   val,
                    fieldOk:      val !== "",
                    fieldType:    fd.type,
                    fieldOptions: fd.options || []
                })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── FUNZIONI ────────────────────────────────────────────────
    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function parseText(raw) {
        var t = raw.toLowerCase()
        var d = {}

        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""

            if (fd.type === "picker" && fd.options) {
                // Cerca corrispondenza tra le opzioni
                for (var j = 0; j < fd.options.length; j++) {
                    if (t.indexOf(fd.options[j].toLowerCase()) !== -1) {
                        d[fd.key] = fd.options[j]; break
                    }
                }
                // Sinonimi speciali per PTE
                if (fd.key === "STATO_1") {
                    if (t.indexOf("non realizzato") !== -1 || t.indexOf("non fatto") !== -1)
                        d[fd.key] = "NON Realizzato"
                    else if (t.indexOf("realizzato") !== -1 || t.indexOf("nuovo") !== -1)
                        d[fd.key] = "Realizzato"
                    else if (t.indexOf("esistente") !== -1 || t.indexOf("presente") !== -1)
                        d[fd.key] = "Esistente"
                }
                if (fd.key === "DESCRIPTIO" && plugin.selectedLayerName === "PTE") {
                    if (t.indexOf("muro esterno") !== -1 || t.indexOf("palifica") !== -1)
                        d[fd.key] = "PTE Muro Esterno/Palifica"
                    else if (t.indexOf("sotterraneo") !== -1)
                        d[fd.key] = "PTE Sotterraneo"
                    else if (t.indexOf("colonnina") !== -1)
                        d[fd.key] = "PTE Colonnina"
                    else if (t.indexOf("interno") !== -1)
                        d[fd.key] = "PTE Interno"
                }
            } else if (fd.type === "text") {
                // Estrai numero dopo keyword
                var kw = fd.label.toLowerCase()
                var m  = t.match(new RegExp(kw + "\\s+(\\d+)"))
                if (m) d[fd.key] = m[1]
            }
        }

        plugin.parsedData = d
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    Timer {
        id: presetFocusTimer
        interval: 400; repeat: false
        onTriggered: {
            presetVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    function applyPreset(index) {
        presetMenu.visible = false
        presetVoiceInput.text = ""
        var preset = plugin.ptePresets[index]
        // Precompila i campi con i valori del preset
        var d = plugin.parsedData
        for (var key in preset.values) {
            d[key] = preset.values[key]
        }
        plugin.parsedData = d
        // Conta campi compilati
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
        // Apri form vocale
        overlay.visible = true
        focusTimer.start()
        mainWindow.displayToast("✅ " + preset.label + " — modifica o conferma")
    }

    function saveLineFeature() {
        lineChoiceOverlay.visible = false
        var layer = plugin.selectedLayer
        if (!layer) layer = dashBoard ? dashBoard.activeLayer : null
        if (!layer) { mainWindow.displayToast("⚠ Layer non trovato!"); return }
        try {
            var wktPts = []
            for (var i = 0; i < plugin.linePoints.length; i++)
                wktPts.push(plugin.linePoints[i].x + " " + plugin.linePoints[i].y)
            var wkt = "LINESTRING(" + wktPts.join(", ") + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var fieldNames = feature.fields.names
            // Lunghezza automatica
            var total = 0
            for (var j = 1; j < plugin.linePoints.length; j++) {
                var dx = plugin.linePoints[j].x - plugin.linePoints[j-1].x
                var dy = plugin.linePoints[j].y - plugin.linePoints[j-1].y
                total += Math.sqrt(dx*dx + dy*dy)
            }
            var lIdx = fieldNames.indexOf("LUNGHEZZA")
            if (lIdx < 0) lIdx = fieldNames.indexOf("lunghezza")
            if (lIdx < 0) lIdx = fieldNames.indexOf("LENGTH")
            if (lIdx >= 0) feature.setAttribute(lIdx, Math.round(total * 100) / 100)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            plugin.lineMode = false
            plugin.linePoints = []
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }
        if (!positionSource || !positionSource.active) {
            mainWindow.displayToast("⚠ GPS non attivo!"); return
        }
        try {
            var pos = positionSource.projectedPosition
            var wkt = "POINT(" + pos.x + " " + pos.y + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            // Aggiungi foto se presente
            if (plugin.photo1Path !== "") {
                var fi = fieldNames.indexOf("Foto_1")
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            // Salva tramite drawer (metodo che funziona)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}    // ── MENU PRESET PTE RADIALE ────────────────────────────────
    Rectangle {
        id: presetMenu
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: presetMenu.visible = false }

        // Titolo
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 30
            text: "📡 Seleziona tipo PTE"
            color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
        }

        // Container radiale centrato
        Item {
            id: radialContainer
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height) * 0.9
            height: width

            // Cerchio di sfondo
            Rectangle {
                anchors.centerIn: parent
                width: parent.width; height: parent.width
                radius: parent.width / 2
                color: "#0d1020"
                border.color: "#2a2d40"; border.width: 2
            }

            // 4 settori — posizionati a 0°, 90°, 180°, 270°
            // Settore 1 — Alto (0°)
            Rectangle {
                id: sector1
                width: radialContainer.width * 0.42
                height: radialContainer.width * 0.42
                radius: 12
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.top: parent.top; anchors.topMargin: 8
                color: s1M.pressed ? "#22405a" : "#1e3a52"
                border.color: "#3d8ef0"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 4
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 28; height: 28; radius: 14; color: "#3d8ef0"
                        Text { anchors.centerIn: parent; text: "1"; color: "white"; font.pixelSize: 13; font.bold: true }
                    }
                    Image {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 50; height: 50
                        source: plugin.ptePresets[0].icon
                        fillMode: Image.PreserveAspectFit
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "Interno"
                        color: "#e8eaf0"; font.pixelSize: 10
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
                MouseArea { id: s1M; anchors.fill: parent; onClicked: applyPreset(0) }
            }

            // Settore 2 — Destra (90°)
            Rectangle {
                id: sector2
                width: radialContainer.width * 0.42
                height: radialContainer.width * 0.42
                radius: 12
                anchors.right: parent.right; anchors.rightMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                color: s2M.pressed ? "#22405a" : "#1e3a52"
                border.color: "#2ecc71"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 4
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 28; height: 28; radius: 14; color: "#2ecc71"
                        Text { anchors.centerIn: parent; text: "2"; color: "white"; font.pixelSize: 13; font.bold: true }
                    }
                    Image {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 50; height: 50
                        source: plugin.ptePresets[1].icon
                        fillMode: Image.PreserveAspectFit
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "Muro Est."
                        color: "#e8eaf0"; font.pixelSize: 10
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
                MouseArea { id: s2M; anchors.fill: parent; onClicked: applyPreset(1) }
            }

            // Settore 3 — Basso (180°)
            Rectangle {
                id: sector3
                width: radialContainer.width * 0.42
                height: radialContainer.width * 0.42
                radius: 12
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom; anchors.bottomMargin: 8
                color: s3M.pressed ? "#22405a" : "#1e3a52"
                border.color: "#e67e22"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 4
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 28; height: 28; radius: 14; color: "#e67e22"
                        Text { anchors.centerIn: parent; text: "3"; color: "white"; font.pixelSize: 13; font.bold: true }
                    }
                    Image {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 50; height: 50
                        source: plugin.ptePresets[2].icon
                        fillMode: Image.PreserveAspectFit
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "Sotterr."
                        color: "#e8eaf0"; font.pixelSize: 10
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
                MouseArea { id: s3M; anchors.fill: parent; onClicked: applyPreset(2) }
            }

            // Settore 4 — Sinistra (270°)
            Rectangle {
                id: sector4
                width: radialContainer.width * 0.42
                height: radialContainer.width * 0.42
                radius: 12
                anchors.left: parent.left; anchors.leftMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                color: s4M.pressed ? "#22405a" : "#1e3a52"
                border.color: "#9b59b6"; border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 4
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 28; height: 28; radius: 14; color: "#9b59b6"
                        Text { anchors.centerIn: parent; text: "4"; color: "white"; font.pixelSize: 13; font.bold: true }
                    }
                    Image {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 50; height: 50
                        source: plugin.ptePresets[3].icon
                        fillMode: Image.PreserveAspectFit
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "Colonnina"
                        color: "#e8eaf0"; font.pixelSize: 10
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
                MouseArea { id: s4M; anchors.fill: parent; onClicked: applyPreset(3) }
            }

            // Centro — campo voce
            Rectangle {
                anchors.centerIn: parent
                width: radialContainer.width * 0.28
                height: width; radius: width / 2
                color: "#1a1d27"
                border.color: presetVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                border.width: 2
                Column {
                    anchors.centerIn: parent; spacing: 2
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "🎤"; font.pixelSize: 16 }
                    TextInput {
                        id: presetVoiceInput
                        width: radialContainer.width * 0.22
                        horizontalAlignment: TextInput.AlignHCenter
                        color: "#e8eaf0"; font.pixelSize: 13
                        onTextChanged: { if (text.length > 0) presetVoiceTimer.restart() }
                    }
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "1-4"; color: "#8890a8"; font.pixelSize: 10 }
                }
            }
        }

        Timer {
            id: presetVoiceTimer
            interval: 500; repeat: false
            onTriggered: {
                var t = presetVoiceInput.text.trim().toLowerCase()
                var n = -1
                if (t === "1" || t.indexOf("uno") !== -1 || t.indexOf("intern") !== -1) n = 1
                else if (t === "2" || t.indexOf("due") !== -1 || t.indexOf("muro") !== -1 || t.indexOf("esterno") !== -1) n = 2
                else if (t === "3" || t.indexOf("tre") !== -1 || t.indexOf("sotterr") !== -1) n = 3
                else if (t === "4" || t.indexOf("quattro") !== -1 || t.indexOf("colonn") !== -1) n = 4
                else { var p = parseInt(t); if (!isNaN(p) && p >= 1 && p <= 4) n = p }
                presetVoiceInput.text = ""
                if (n >= 1 && n <= 4) applyPreset(n - 1)
            }
        }

        Timer {
            id: presetPollTimer
            interval: 500; repeat: true
            running: presetMenu.visible
            onTriggered: { if (presetVoiceInput.text.length > 0) presetVoiceTimer.restart() }
        }
    }

    Timer {
        id: presetFocusTimer
        interval: 400; repeat: false
        onTriggered: {
            presetVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    function applyPreset(index) {
        presetMenu.visible = false
        presetVoiceInput.text = ""
        var preset = plugin.ptePresets[index]
        // Precompila i campi con i valori del preset
        var d = plugin.parsedData
        for (var key in preset.values) {
            d[key] = preset.values[key]
        }
        plugin.parsedData = d
        // Conta campi compilati
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
        // Apri form vocale
        overlay.visible = true
        focusTimer.start()
        mainWindow.displayToast("✅ " + preset.label + " — modifica o conferma")
    }

    function saveLineFeature() {
        lineChoiceOverlay.visible = false
        var layer = plugin.selectedLayer
        if (!layer) layer = dashBoard ? dashBoard.activeLayer : null
        if (!layer) { mainWindow.displayToast("⚠ Layer non trovato!"); return }
        try {
            var wktPts = []
            for (var i = 0; i < plugin.linePoints.length; i++)
                wktPts.push(plugin.linePoints[i].x + " " + plugin.linePoints[i].y)
            var wkt = "LINESTRING(" + wktPts.join(", ") + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var fieldNames = feature.fields.names
            // Lunghezza automatica
            var total = 0
            for (var j = 1; j < plugin.linePoints.length; j++) {
                var dx = plugin.linePoints[j].x - plugin.linePoints[j-1].x
                var dy = plugin.linePoints[j].y - plugin.linePoints[j-1].y
                total += Math.sqrt(dx*dx + dy*dy)
            }
            var lIdx = fieldNames.indexOf("LUNGHEZZA")
            if (lIdx < 0) lIdx = fieldNames.indexOf("lunghezza")
            if (lIdx < 0) lIdx = fieldNames.indexOf("LENGTH")
            if (lIdx >= 0) feature.setAttribute(lIdx, Math.round(total * 100) / 100)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            plugin.lineMode = false
            plugin.linePoints = []
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }
        if (!positionSource || !positionSource.active) {
            mainWindow.displayToast("⚠ GPS non attivo!"); return
        }
        try {
            var pos = positionSource.projectedPosition
            var wkt = "POINT(" + pos.x + " " + pos.y + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            // Aggiungi foto se presente
            if (plugin.photo1Path !== "") {
                var fi = fieldNames.indexOf("Foto_1")
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            // Salva tramite drawer (metodo che funziona)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}
