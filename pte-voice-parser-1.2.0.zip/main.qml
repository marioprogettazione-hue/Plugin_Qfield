import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import Theme

Item {
    id: plugin

    QfToolButton {
        id: micBtn
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: {
            iface.mainWindow().displayToast("QtQuick.Controls e Layouts OK!")
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
    }
}
