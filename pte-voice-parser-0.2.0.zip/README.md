# PTE Voice Parser — Plugin QField

## Installazione

1. Apri **QField** sul tablet
2. Vai in **Impostazioni → Plugin → Install plugin from URL**
3. Incolla l'URL del file ZIP oppure carica direttamente il file
4. Abilita il plugin dall'elenco
5. Riavvia QField

## Come si usa

1. Seleziona il layer PTE come layer attivo (evidenziato in verde)
2. Metti il layer in **modalità modifica** (icona matita)
3. Premi il **tasto microfono** nella toolbar oppure il tasto fisico BT
4. Il GPS acquisisce automaticamente la posizione corrente
5. Si apre il pannello vocale — parla normalmente:
   ```
   realizzato muro esterno quartina 14 armadio 6 transito due cavi ubicazione palo note etichetta sbiadita
   ```
6. I campi si colorano di **verde** man mano che vengono riconosciuti
7. Premi **✔ CONFERMA** per salvare il punto con gli attributi

## Campi riconosciuti

| Campo | Esempi vocali |
|-------|---------------|
| Stato | "realizzato", "esistente", "da progettare" |
| Tipologia | "muro esterno", "facciata", "colonnina" |
| Quartina | "quartina 14", "da 3 a 7" |
| Armadio | "armadio 6" |
| Tipo | "transito", "terminale" |
| Cavi attestati | "due cavi", "3 cavi" |
| Ubicazione | "palo", "pozzetto", "marciapiede"... |
| Note | "note etichetta sbiadita" (tutto dopo "note") |

## Adattare al tuo layer

Nel file `main.qml`, cerca `fieldMap` e adatta i nomi dei campi
a quelli reali del tuo GeoPackage:

```qml
var fieldMap = {
    "stato":          "nome_campo_nel_gpkg",
    "tipologia":      "tipologia",
    // ...
}
```

## Tasto Bluetooth microfono

Il plugin intercetta automaticamente i tasti:
- `Qt.Key_MediaRecord`
- `Qt.Key_Microphone`
- `Qt.Key_Camera`

Associa il tasto del microfono BT a uno di questi keycode
dalle impostazioni del dispositivo/microfono.

## Requisiti

- QField 3.3 o superiore
- Android con Chrome WebView (standard su tutti i dispositivi moderni)
- Permesso microfono (richiesto automaticamente al primo uso)
