import QtQuick
import QtQuick.Controls
import org.qfield 1.0

Item {
    id: root

    // Coordinate GPS catturate
    property double capturedLat: 0
    property double capturedLon: 0

    // Stato parser
    property var parsedData: ({})
    property int okCount: 0

    // Definizione campi
    property var fieldDefs: [
        { key: "stato",          label: "Stato" },
        { key: "tipologia",      label: "Tipologia" },
        { key: "quartina",       label: "Quartina" },
        { key: "armadio",        label: "Armadio" },
        { key: "tipo",           label: "Tipo" },
        { key: "cavi_attestati", label: "Cavi" },
        { key: "ubicazione",     label: "Ubicazione" },
        { key: "note",           label: "Note" }
    ]

    // ─── INIT ────────────────────────────────────────────────────
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micButton)
    }

    // ─── BOTTONE TOOLBAR ─────────────────────────────────────────
    QfToolButton {
        id: micButton
        iconSource: Qt.resolvedUrl("mic.svg")
        text: "PTE"
        toolTip: "PTE Voice Parser"
        onClicked: {
            captureGPS()
            mainDialog.open()
        }
    }

    // ─── GPS ─────────────────────────────────────────────────────
    function captureGPS() {
        var posSource = iface.findItemByObjectName("positionSource")
        if (posSource && posSource.active) {
            root.capturedLat = posSource.positionInformation.latitude  || 0
            root.capturedLon = posSource.positionInformation.longitude || 0
            iface.mainWindow().displayToast(
                "📍 " + root.capturedLat.toFixed(5) + ", " + root.capturedLon.toFixed(5)
            )
        } else {
            iface.mainWindow().displayToast("⚠ GPS non attivo")
        }
    }

    // ─── PARSER ──────────────────────────────────────────────────
    function normalize(t) {
        t = t.toLowerCase()
        var repl = {
            "muore esterno": "muro esterno",
            "moresterno":    "muro esterno",
            "cavie":         "cavi",
            "quattor dici":  "quattordici"
        }
        for (var k in repl) {
            while (t.indexOf(k) !== -1)
                t = t.replace(k, repl[k])
        }
        return t
    }

    function findValue(text, key) {
        var allowed = {
            "stato":      ["realizzato","esistente","non realizzato","da progettare"],
            "tipologia":  ["muro esterno","interno edificio","muro interno","colonnina","sotterraneo"],
            "tipo":       ["transito","terminale"],
            "ubicazione": ["androne","centralino","colonnina","cortile","incassato",
                           "intercapedine","interno cantine","interno garage",
                           "interno ingresso","marciapiede","muro esterno",
                           "palo","seminterrato","pozzetto","sottoscala"]
        }
        var syn = {
            "muro esterno":     ["muro esterno","facciata","su muro"],
            "realizzato":       ["realizzato","realizzata","nuova posa","nuovo"],
            "esistente":        ["esistente","presente"],
            "non realizzato":   ["non realizzato","non fatta","non fatto"],
            "da progettare":    ["da progettare"],
            "transito":         ["transito","passante"],
            "terminale":        ["terminale","finale"],
            "palo":             ["palo","su palo"],
            "pozzetto":         ["pozzetto"],
            "marciapiede":      ["marciapiede"],
            "colonnina":        ["colonnina"],
            "sotterraneo":      ["sotterraneo","sottoterra"],
            "cortile":          ["cortile"],
            "androne":          ["androne"]
        }
        var list = allowed[key] || []
        for (var i = 0; i < list.length; i++) {
            var val = list[i]
            var vars = syn[val] || [val]
            for (var j = 0; j < vars.length; j++) {
                if (text.indexOf(vars[j]) !== -1) return val
            }
        }
        return ""
    }

    function extractQuartina(text) {
        // "quartina 14" o "da 3 a 7"
        var m
        m = text.match(/quartina\s+(\d+)/)
        if (m) return m[1]
        m = text.match(/da\s+(\d+)\s+a\s+(\d+)/)
        if (m) return m[1] + ":" + m[2]
        return ""
    }

    function extractArmadio(text) {
        var m = text.match(/armadio\s+(\d+)/)
        return m ? m[1] : ""
    }

    function extractCavi(text) {
        var numeri = {"uno":1,"una":1,"due":2,"tre":3,"quattro":4,
                      "cinque":5,"sei":6,"sette":7,"otto":8,"nove":9,"dieci":10}
        var m = text.match(/(\d+)\s+cavi/)
        if (m) return m[1]
        for (var k in numeri) {
            if (text.indexOf(k + " cavi") !== -1) return String(numeri[k])
        }
        return ""
    }

    function extractNote(text) {
        var m = text.match(/note[:\s]+(.+)/)
        return m ? m[1].trim() : ""
    }

    function parseText(text) {
        var t = normalize(text)
        var result = {
            stato:          findValue(t, "stato"),
            tipologia:      findValue(t, "tipologia"),
            quartina:       extractQuartina(t),
            armadio:        extractArmadio(t),
            tipo:           findValue(t, "tipo"),
            cavi_attestati: extractCavi(t),
            ubicazione:     findValue(t, "ubicazione"),
            note:           extractNote(t)
        }
        root.parsedData = result
        // conta campi ok
        var n = 0
        for (var k in result) { if (result[k] !== "") n++ }
        root.okCount = n
        fieldsModel.refresh()
    }

    // ─── MODEL CAMPI ─────────────────────────────────────────────
    ListModel {
        id: fieldsModel

        function refresh() {
            clear()
            for (var i = 0; i < root.fieldDefs.length; i++) {
                var fd  = root.fieldDefs[i]
                var val = root.parsedData[fd.key] || ""
                append({ label: fd.label, key: fd.key, value: val, ok: val !== "" })
            }
        }

        Component.onCompleted: refresh()
    }

    // ─── DIALOG PRINCIPALE ───────────────────────────────────────
    QfDialog {
        id: mainDialog
        parent: iface.mainWindow()
        title: "⚡ PTE Voice Parser"
        width: Math.min(parent.width * 0.96, 640)
        height: parent.height * 0.88

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 10

            // ── Campo testo trascrizione ──
            Rectangle {
                Layout.fillWidth: true
                height: 72
                color: "#1a1d27"
                radius: 8
                border.color: transcriptField.activeFocus ? "#3d8ef0" : "#2a2d3a"
                border.width: 2

                TextArea {
                    id: transcriptField
                    anchors.fill: parent
                    anchors.margins: 8
                    placeholderText: "Parla o digita: stato realizzato muro esterno quartina 14..."
                    color: "#e8eaf0"
                    placeholderTextColor: "#6670a0"
                    background: null
                    wrapMode: TextArea.Wrap
                    font.pixelSize: 14

                    onTextChanged: {
                        if (text.length > 2) root.parseText(text)
                    }
                }
            }

            // ── Contatore ──
            Text {
                Layout.fillWidth: true
                text: "Campi compilati: " + root.okCount + " / " + root.fieldDefs.length
                color: root.okCount >= 4 ? "#1db954" : "#8890a8"
                font.pixelSize: 12
                horizontalAlignment: Text.AlignRight
            }

            // ── Griglia campi ──
            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 8
                rowSpacing: 8

                Repeater {
                    model: fieldsModel

                    delegate: Rectangle {
                        Layout.fillWidth: true
                        height: 58
                        radius: 8
                        color:  model.ok ? "#0d2b1a" : "#1a0d0d"
                        border.color: model.ok ? "#1db954" : "#6a1a1a"
                        border.width: 1.5

                        Column {
                            anchors.fill: parent
                            anchors.margins: 8
                            spacing: 2

                            Text {
                                text: model.label.toUpperCase()
                                font.pixelSize: 9
                                font.bold: true
                                color: model.ok ? "#1db954" : "#a04040"
                                letterSpacing: 0.8
                            }
                            Text {
                                text: model.value !== "" ? model.value : "mancante"
                                font.pixelSize: 14
                                font.bold: true
                                color: model.ok ? "#7fffb0" : "#ff8080"
                                font.italic: model.value === ""
                                elide: Text.ElideRight
                                width: parent.width
                            }
                        }
                    }
                }
            }

            // ── Bottoni ──
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                // Cancella
                Button {
                    text: "✕ Cancella"
                    onClicked: {
                        transcriptField.text = ""
                        root.parsedData = {}
                        root.okCount = 0
                        fieldsModel.refresh()
                    }
                }

                Item { Layout.fillWidth: true }

                // Conferma
                Button {
                    text: "✔ CONFERMA"
                    enabled: root.okCount > 0
                    highlighted: true
                    onClicked: {
                        applyToLayer()
                        mainDialog.close()
                    }
                }
            }
        }
    }

    // ─── APPLICA AL LAYER ────────────────────────────────────────
    function applyToLayer() {
        var layer = iface.mapCanvas().currentLayer
        if (!layer) {
            iface.mainWindow().displayToast("⚠ Seleziona un layer prima!")
            return
        }
        if (!layer.isEditable()) {
            layer.startEditing()
        }

        var fields = layer.fields()
        var feature = iface.findItemByObjectName("digitizingFeature")

        if (!feature) {
            iface.mainWindow().displayToast("⚠ Avvia prima la digitalizzazione (+)")
            return
        }

        var data = root.parsedData
        var fieldMap = {
            "stato": "stato", "tipologia": "tipologia",
            "quartina": "quartina", "armadio": "armadio",
            "tipo": "tipo", "cavi_attestati": "cavi_attestati",
            "ubicazione": "ubicazione", "note": "note"
        }

        for (var jsonKey in fieldMap) {
            var layerField = fieldMap[jsonKey]
            var val = data[jsonKey]
            if (val !== undefined && val !== "") {
                var idx = fields.indexFromName(layerField)
                if (idx >= 0) feature.setAttribute(idx, val)
            }
        }

        iface.mainWindow().displayToast(
            "✅ Attributi PTE compilati: " + root.okCount + " campi"
        )
    }

    // ─── TASTO HARDWARE BT ───────────────────────────────────────
    Item {
        focus: true
        Keys.onPressed: function(event) {
            if (event.key === Qt.Key_MediaRecord ||
                event.key === Qt.Key_Microphone) {
                if (!mainDialog.visible) {
                    captureGPS()
                    mainDialog.open()
                }
                event.accepted = true
            }
        }
    }
}
