import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import org.qfield 1.0

Item {
    id: root

    property double capturedLat: 0
    property double capturedLon: 0
    property int okCount: 0
    property var parsedData: ({
        stato: "", tipologia: "", quartina: "",
        armadio: "", tipo: "", cavi_attestati: "",
        ubicazione: "", note: ""
    })

    property var fieldDefs: [
        { key: "stato",          label: "STATO" },
        { key: "tipologia",      label: "TIPOLOGIA" },
        { key: "quartina",       label: "QUARTINA" },
        { key: "armadio",        label: "ARMADIO" },
        { key: "tipo",           label: "TIPO" },
        { key: "cavi_attestati", label: "CAVI" },
        { key: "ubicazione",     label: "UBICAZIONE" },
        { key: "note",           label: "NOTE" }
    ]

    // ── Init con timer ──────────────────────────────────────────
    Timer {
        interval: 1500
        running: true
        repeat: false
        onTriggered: {
            iface.addItemToPluginsToolbar(micBtn)
        }
    }

    // ── Bottone toolbar ─────────────────────────────────────────
    QfToolButton {
        id: micBtn
        text: "PTE"
        toolTip: "PTE Voice Parser"
        onClicked: {
            captureGPS()
            dialog.open()
        }
    }

    // ── GPS ─────────────────────────────────────────────────────
    function captureGPS() {
        var pos = iface.findItemByObjectName("positionSource")
        if (pos && pos.active) {
            var info = pos.positionInformation
            root.capturedLat = info.latitude  || 0
            root.capturedLon = info.longitude || 0
            iface.mainWindow().displayToast(
                "📍 " + root.capturedLat.toFixed(5) +
                " , " + root.capturedLon.toFixed(5)
            )
        } else {
            iface.mainWindow().displayToast("⚠ GPS non attivo")
        }
    }

    // ── Parser ──────────────────────────────────────────────────
    function normalize(t) {
        t = t.toLowerCase()
        var fixes = [
            ["muore esterno",  "muro esterno"],
            ["moresterno",     "muro esterno"],
            ["muro a sterno",  "muro esterno"],
            ["cavie",          "cavi"],
            ["quattor dici",   "quattordici"],
            ["arm adio",       "armadio"]
        ]
        for (var i = 0; i < fixes.length; i++)
            t = t.split(fixes[i][0]).join(fixes[i][1])
        return t
    }

    function findValue(text, key) {
        var map = {
            "stato": [
                ["realizzato",     ["realizzato","realizzata","nuovo","nuova","nuova posa"]],
                ["esistente",      ["esistente","presente","già presente"]],
                ["non realizzato", ["non realizzato","non fatto","non fatta"]],
                ["da progettare",  ["da progettare"]]
            ],
            "tipologia": [
                ["muro esterno",     ["muro esterno","facciata","su muro"]],
                ["interno edificio", ["interno edificio","int edificio"]],
                ["muro interno",     ["muro interno"]],
                ["colonnina",        ["colonnina"]],
                ["sotterraneo",      ["sotterraneo","sottoterra"]]
            ],
            "tipo": [
                ["transito",  ["transito","passante","in transito"]],
                ["terminale", ["terminale","finale"]]
            ],
            "ubicazione": [
                ["palo",              ["palo","su palo"]],
                ["pozzetto",          ["pozzetto"]],
                ["marciapiede",       ["marciapiede"]],
                ["androne",           ["androne"]],
                ["cortile",           ["cortile"]],
                ["colonnina",         ["colonnina"]],
                ["incassato",         ["incassato","a incasso"]],
                ["intercapedine",     ["intercapedine"]],
                ["sottoscala",        ["sottoscala","sotto scala"]],
                ["seminterrato",      ["seminterrato"]],
                ["centralino",        ["centralino"]],
                ["interno cantine",   ["interno cantine","cantine"]],
                ["interno garage",    ["interno garage","garage"]],
                ["interno ingresso",  ["interno ingresso"]],
                ["muro esterno",      ["ubicazione muro esterno"]]
            ]
        }
        var list = map[key] || []
        for (var i = 0; i < list.length; i++) {
            var val  = list[i][0]
            var syns = list[i][1]
            for (var j = 0; j < syns.length; j++) {
                if (text.indexOf(syns[j]) !== -1) return val
            }
        }
        return ""
    }

    function extractNumber(text, keyword) {
        // cerca "keyword NUMBER" es "quartina 14", "armadio 6"
        var re = new RegExp(keyword + "\\s+(\\d+)")
        var m  = text.match(re)
        if (m) return m[1]
        return ""
    }

    function extractQuartina(text) {
        var m
        m = text.match(/da\s+(\d+)\s+a\s+(\d+)/)
        if (m) return m[1] + ":" + m[2]
        m = text.match(/quartina\s+(\d+)\s+e\s+(\d+)/)
        if (m) return m[1] + "-" + m[2]
        m = text.match(/quartina\s+(\d+)/)
        if (m) return m[1]
        return ""
    }

    function extractCavi(text) {
        var numeri = {
            "uno":1,"una":1,"due":2,"tre":3,"quattro":4,
            "cinque":5,"sei":6,"sette":7,"otto":8,"nove":9,
            "dieci":10,"undici":11,"dodici":12
        }
        var m = text.match(/(\d+)\s+cavi/)
        if (m) return m[1]
        for (var k in numeri) {
            if (text.indexOf(k + " cavi") !== -1)
                return String(numeri[k])
        }
        return ""
    }

    function extractNote(text) {
        var m = text.match(/note[:\s]+(.+)/)
        return m ? m[1].trim() : ""
    }

    function parseText(raw) {
        var t = normalize(raw)
        var result = {
            stato:          findValue(t, "stato"),
            tipologia:      findValue(t, "tipologia"),
            quartina:       extractQuartina(t),
            armadio:        extractNumber(t, "armadio"),
            tipo:           findValue(t, "tipo"),
            cavi_attestati: extractCavi(t),
            ubicazione:     findValue(t, "ubicazione"),
            note:           extractNote(t)
        }
        root.parsedData = result
        var n = 0
        for (var k in result) { if (result[k] !== "") n++ }
        root.okCount = n
        fieldsModel.refresh()
    }

    // ── Model ────────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < root.fieldDefs.length; i++) {
                var fd  = root.fieldDefs[i]
                var val = root.parsedData[fd.key] || ""
                append({ fieldLabel: fd.label, fieldKey: fd.key,
                         fieldValue: val, fieldOk: val !== "" })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── Dialog ───────────────────────────────────────────────────
    QfDialog {
        id: dialog
        parent: iface.mainWindow()
        title: "PTE Voice Parser"
        width:  Math.min(parent.width  * 0.95, 620)
        height: Math.min(parent.height * 0.90, 750)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            // Trascrizione
            Rectangle {
                Layout.fillWidth: true
                height: 70
                color: "#1e2030"
                radius: 8
                border.color: inputArea.activeFocus ? "#4a90d9" : "#3a3d50"
                border.width: 2

                TextArea {
                    id: inputArea
                    anchors.fill: parent
                    anchors.margins: 8
                    placeholderText: "Digita o usa il microfono della tastiera:\n\"realizzato muro esterno quartina 14 armadio 6 transito due cavi palo\""
                    wrapMode: TextArea.Wrap
                    font.pixelSize: 13
                    background: null
                    onTextChanged: {
                        if (text.length > 3) root.parseText(text)
                    }
                }
            }

            // Contatore
            Text {
                Layout.fillWidth: true
                text: "✔ " + root.okCount + " / 8 campi compilati"
                color: root.okCount >= 5 ? "#2ecc71" : root.okCount >= 2 ? "#f39c12" : "#95a5a6"
                font.pixelSize: 12
                font.bold: true
                horizontalAlignment: Text.AlignRight
            }

            // Griglia campi
            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 6
                rowSpacing: 6

                Repeater {
                    model: fieldsModel
                    delegate: Rectangle {
                        Layout.fillWidth: true
                        height: 54
                        radius: 7
                        color:  model.fieldOk ? "#0a2018" : "#200a0a"
                        border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                        border.width: 1.5

                        Column {
                            anchors.fill: parent
                            anchors.margins: 7
                            spacing: 2
                            Text {
                                text: model.fieldLabel
                                font.pixelSize: 9
                                font.bold: true
                                color: model.fieldOk ? "#27ae60" : "#c0392b"
                                letterSpacing: 1
                            }
                            Text {
                                text: model.fieldValue !== "" ? model.fieldValue : "—"
                                font.pixelSize: 14
                                font.bold: model.fieldOk
                                color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                elide: Text.ElideRight
                                width: parent.width
                            }
                        }
                    }
                }
            }

            // Bottoni
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    text: "✕ Cancella"
                    flat: true
                    onClicked: {
                        inputArea.text = ""
                        root.parsedData = {
                            stato:"", tipologia:"", quartina:"",
                            armadio:"", tipo:"", cavi_attestati:"",
                            ubicazione:"", note:""
                        }
                        root.okCount = 0
                        fieldsModel.refresh()
                    }
                }

                Item { Layout.fillWidth: true }

                Button {
                    text: "✔ CONFERMA"
                    enabled: root.okCount > 0
                    highlighted: true
                    onClicked: {
                        applyToLayer()
                        dialog.close()
                    }
                }
            }
        }
    }

    // ── Applica al layer ─────────────────────────────────────────
    function applyToLayer() {
        var layer = iface.mapCanvas().currentLayer
        if (!layer) {
            iface.mainWindow().displayToast("⚠ Nessun layer selezionato!")
            return
        }
        if (!layer.isEditable()) layer.startEditing()

        var flds = layer.fields()
        var d    = root.parsedData
        var keys = ["stato","tipologia","quartina","armadio",
                    "tipo","cavi_attestati","ubicazione","note"]
        var saved = 0
        for (var i = 0; i < keys.length; i++) {
            var k   = keys[i]
            var val = d[k]
            if (val && val !== "") {
                var idx = flds.indexFromName(k)
                if (idx >= 0) {
                    // set default value sul layer così viene usato alla prossima feature
                    layer.setDefaultValueDefinition(idx, val)
                    saved++
                }
            }
        }
        iface.mainWindow().displayToast(
            "✅ " + saved + " attributi pronti — ora piazza il punto con +"
        )
    }
}
