import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var positionSource: iface.findItemByObjectName('positionSource')

    // Layer selezionato
    property string selectedLayerName: ""
    property var selectedLayer: null

    property int okCount: 0
    property var parsedData: ({})

    // ── DEFINIZIONE LAYER E CAMPI ────────────────────────────────
    // Ogni layer ha: name (nome nel gpkg), label (etichetta), icon, fields
    property var layerDefs: [
        {
            name: "PTE", label: "PTE", icon: "📡",
            fields: [
                { key:"Label",      label:"QUARTINA",   type:"text" },
                { key:"DESCRIPTIO", label:"TIPOLOGIA",  type:"picker",
                  options:["PTE Muro Esterno","PTE Interno","PTE Muro Esterno/Palifica","PTE Sotterraneo","PTE Colonnina"] },
                { key:"ArmadioId",  label:"ARMADIO",    type:"text" },
                { key:"Posizione",  label:"UBICAZIONE", type:"picker",
                  options:["Muro Esterno","Androne","Centralino","Colonnina","Cortile","Divisorio",
                           "Incassato","Intercapedine","Interno Garage","Interno Ingresso",
                           "Marciapiede","Palo","Pontile","Pozzetto","Seminterrato","Sottoscala"] },
                { key:"STATO_1",    label:"STATO",      type:"picker",
                  options:["Esistente","Realizzato","NON Realizzato"] }
            ]
        },
        {
            name: "ARMADIO", label: "Armadio", icon: "🗄️",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"Label",      label:"LABEL",    type:"text" },
                { key:"DESCRIPTIO", label:"NOTE",     type:"text" }
            ]
        },
        {
            name: "RACCORDI", label: "Raccordi", icon: "〰️",
            lineLayer: true,
            fields: [
                { key:"OBJECTID", label:"OBJECT ID", type:"text" }
            ]
        },
        {
            name: "TRATTE INTERRATE", label: "Tratte Interrate", icon: "⛏️",
            lineLayer: true,
            fields: [
                { key:"OBJECTID", label:"OBJECT ID", type:"text" }
            ]
        },
        {
            name: "EXTRA", label: "Extra", icon: "➕",
            fields: [
                { key:"STATO_1",    label:"STATO",    type:"picker",
                  options:["Realizzato","NON Realizzato","Esistente"] },
                { key:"DESCRIPTIO", label:"TIPO",     type:"text" },
                { key:"Label",      label:"LABEL",    type:"text" }
            ]
        },
        {
            name: "STRUCTURE", label: "Structure", icon: "🏗️",
            fields: [
                { key:"OBJECTID",   label:"OBJECT ID",  type:"text" },
                { key:"MAIN_SUB_1", label:"MAIN SUB",   type:"text" }
            ]
        }
    ]

    property var currentFields: []
    property string activeFieldKey: ""
    property var activeFieldOptions: []
    property string lastParsedText: ""
    property string photo1Path: ""

    // Polilinea
    property bool lineMode: false
    property var linePoints: []
    property int lineState: 0  // 0=idle 1=started 2=collecting
    property var currentLineDef: null

    // Timer polling: controlla ogni 500ms se il testo è cambiato
    // Necessario perché la tastiera vocale Android non sempre
    // trigghera onTextChanged correttamente
    Timer {
        id: pollTimer
        interval: 500
        repeat: true
        running: overlay.visible
        onTriggered: {
            if (inputArea.text !== plugin.lastParsedText && inputArea.text.length > 2) {
                plugin.lastParsedText = inputArea.text
                processVoice(inputArea.text)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
        layerPicker.parent = mainWindow.contentItem
        overlay.parent     = mainWindow.contentItem
        picker.parent      = mainWindow.contentItem
        freeTextEditor.parent = mainWindow.contentItem
        mainWindow.contentItem.Keys.onPressed.connect(handleKeyPress)
    }

    // ── TASTO BT ────────────────────────────────────────────────
    function handleKeyPress(event) {
        var btKeys = [
            Qt.Key_MediaRecord, Qt.Key_Microphone,
            Qt.Key_Call, Qt.Key_Camera, Qt.Key_ToggleCallHangup,
            Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause,
            179, 164, 226
        ]
        if (btKeys.indexOf(event.key) !== -1) {
            togglePanel()
            event.accepted = true
        }
    }

    function togglePanel() {
        if (overlay.visible) {
            closeAll()
        } else if (layerPicker.visible) {
            closeAll()
        } else {
            // Mostra prima il selettore layer
            updateGPS()
            layerPicker.visible = true
            // Focus automatico sul campo vocale
            layerFocusTimer.start()
        }
    }

    property string lastLayerText: ""

    Timer {
        id: layerFocusTimer
        interval: 400; repeat: false
        onTriggered: {
            // Apre direttamente il riconoscimento vocale Android
            // senza che l'utente prema nulla
            layerVoiceInput.forceActiveFocus()
            // Simula il click sul tasto mic della tastiera
            // tramite inputMethod
            Qt.inputMethod.show()
            layerSpeechTimer.start()
        }
    }

    // Apre direttamente il riconoscimento vocale Android
    Timer {
        id: layerSpeechTimer
        interval: 600; repeat: false
        onTriggered: {
            // Usa il SpeechRecognizer Android tramite intent
            // Questo apre il mic senza che l'utente prema nulla
            iface.startSpeechToText(function(text) {
                if (text && text !== "") {
                    layerVoiceInput.text = text
                }
            })
        }
    }

    // Polling per layer picker — controlla testo ogni 500ms
    Timer {
        id: layerPollTimer
        interval: 500; repeat: true
        running: layerPicker.visible
        onTriggered: {
            if (layerVoiceInput.text !== plugin.lastLayerText &&
                layerVoiceInput.text.length > 1) {
                plugin.lastLayerText = layerVoiceInput.text
                layerVoiceTimer.restart()
            }
        }
    }

    function closeAll() {
        Qt.inputMethod.hide()
        layerPicker.visible = false
        overlay.visible = false
        resetData()
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: togglePanel()
    }

    function selectLayer(layerDef) {
        plugin.selectedLayerName = layerDef.name
        plugin.currentFields = layerDef.fields
        plugin.selectedLayer = null

        // Metodo corretto da VocalField:
        var layer = qgisProject.mapLayersByName(layerDef.name)[0]
        if (layer) {
            plugin.selectedLayer = layer
            dashBoard.activeLayer = layer
            mainWindow.displayToast("✅ Layer attivo: " + layerDef.name)
        } else {
            mainWindow.displayToast("⚠ Layer " + layerDef.name + " non trovato")
        }

        layerVoiceInput.text = ""
        plugin.lastLayerText = ""
        resetData()
        layerPicker.visible = false
        overlay.visible = true
        focusTimer.start()  // apre tastiera sul form automaticamente
    }

    function findLayer(name) {
        // Usa il layer trovato e impostato in selectLayer
        if (plugin.selectedLayer) return plugin.selectedLayer
        if (dashBoard && dashBoard.activeLayer)
            return dashBoard.activeLayer
        return null
    }

    function resetData() {
        inputArea.text = ""
        var d = {}
        for (var i = 0; i < plugin.currentFields.length; i++)
            d[plugin.currentFields[i].key] = ""
        plugin.parsedData = d
        plugin.okCount = 0
        fieldsModel.refresh()
    }

    Timer {
        id: focusTimer
        interval: 400; repeat: false
        onTriggered: {
            inputArea.forceActiveFocus()
            Qt.inputMethod.show()
            // Avvia mic automaticamente sul form
            formSpeechTimer.start()
        }
    }

    Timer {
        id: formSpeechTimer
        interval: 600; repeat: false
        onTriggered: {
            iface.startSpeechToText(function(text) {
                if (text && text !== "") {
                    inputArea.text = text
                }
            })
        }
    }

    function processVoice(text) {
        var t = text.toLowerCase()
        if (t.indexOf("conferma") !== -1 && plugin.okCount > 0) {
            saveToLayer(); return
        }
        if (t.indexOf("cancella tutto") !== -1) { resetData(); return }
        parseText(text)
    }

    // ── LAYER PICKER ────────────────────────────────────────────
    Rectangle {
        id: layerPicker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent; onClicked: layerPicker.visible = false }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.88, 500)
            height: layerColumn.implicitHeight + 40
            color: "#1a1d27"; radius: 12

            Column {
                id: layerColumn
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: "📍 Seleziona layer"
                    color: "#5ba3ff"; font.pixelSize: 18; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    width: parent.width
                    text: gpsText.text
                    color: gpsText.color; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                // Campo vocale per selezionare layer
                Rectangle {
                    width: parent.width; height: 48
                    color: "#22263a"; radius: 8
                    border.color: layerVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextArea {
                        id: layerVoiceInput
                        anchors.fill: parent; anchors.margins: 8
                        placeholderText: "🎤 Di' il nome del layer..."
                        color: "#e8eaf0"; font.pixelSize: 13; background: null
                        wrapMode: TextArea.NoWrap
                        onTextChanged: {
                            if (text.length > 1) layerVoiceTimer.restart()
                        }
                    }
                }

                // Timer per riconoscere il layer dalla voce
                Timer {
                    id: layerVoiceTimer
                    interval: 600; repeat: false
                    onTriggered: {
                        var t = layerVoiceInput.text.toLowerCase()
                        var found = null
                        for (var i = 0; i < plugin.layerDefs.length; i++) {
                            var def = plugin.layerDefs[i]
                            if (t.indexOf(def.name.toLowerCase()) !== -1 ||
                                t.indexOf(def.label.toLowerCase()) !== -1) {
                                found = def
                                break
                            }
                        }
                        if (found) {
                            layerVoiceInput.text = ""
                            selectLayer(found)
                        }
                    }
                }

                // Bottoni layer
                Repeater {
                    model: plugin.layerDefs
                    delegate: Rectangle {
                        width: parent ? parent.width : 0
                        height: 58; radius: 10
                        color: layerMA.pressed ? "#22405a" : "#1e3a52"
                        border.color: "#2a5a8a"; border.width: 1.5

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 14; spacing: 12
                            Text { text: modelData.icon; font.pixelSize: 24 }
                            Text {
                                text: modelData.label
                                color: "#e8eaf0"; font.pixelSize: 17; font.bold: true
                                Layout.fillWidth: true
                            }
                            Text { text: "›"; color: "#5ba3ff"; font.pixelSize: 22; font.bold: true }
                        }

                        MouseArea {
                            id: layerMA; anchors.fill: parent
                            onClicked: selectLayer(modelData)
                        }
                    }
                }

                Item { height: 4 }
            }
        }
    }

    // ── OVERLAY FORM ────────────────────────────────────────────
    Rectangle {
        id: overlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9999; color: "#bb000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width:  Math.min(parent.width * 0.95, 620)
            height: Math.min(parent.height * 0.90, 720)
            color: "#1a1d27"; radius: 12

            ColumnLayout {
                anchors.fill: parent; anchors.margins: 14; spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: {
                            var def = null
                            for (var i = 0; i < plugin.layerDefs.length; i++)
                                if (plugin.layerDefs[i].name === plugin.selectedLayerName)
                                    def = plugin.layerDefs[i]
                            return def ? def.icon + " " + def.label : "⚡ Voice Parser"
                        }
                        color: "#5ba3ff"; font.pixelSize: 17; font.bold: true; Layout.fillWidth: true
                    }
                    // Bottone cambia layer
                    Rectangle {
                        width: 60; height: 30; radius: 6
                        color: changeM.pressed ? "#1a3a5a" : "#22263a"
                        border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "↩ layer"; color: "#8890a8"; font.pixelSize: 10 }
                        MouseArea { id: changeM; anchors.fill: parent
                            onClicked: { overlay.visible = false; layerPicker.visible = true } }
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xM.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xM; anchors.fill: parent; onClicked: closeAll() }
                    }
                }

                Text {
                    id: gpsText
                    Layout.fillWidth: true
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                }

                Rectangle {
                    Layout.fillWidth: true; height: 56
                    color: "#22263a"; radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Usa 🎤 tastiera oppure digita..."
                            color: "#e8eaf0"; wrapMode: TextArea.Wrap
                            font.pixelSize: 12; background: null
                            // onTextChanged per digitazione normale
                            onTextChanged: {
                                if (text.length > 2) processVoice(text)
                            }
                            // onEditingFinished per input vocale Android
                            // (la tastiera vocale scrive tutto in un colpo)
                            Component.onCompleted: {
                                inputArea.textChanged.connect(function() {
                                    parseTimer.restart()
                                })
                            }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / " + plugin.currentFields.length + " campi ✔"
                    color: plugin.okCount >= plugin.currentFields.length ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2; columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true; height: 54; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent; anchors.margins: 6; spacing: 2
                                Text { text: model.fieldLabel; font.pixelSize: 9; font.bold: true
                                       color: model.fieldOk ? "#27ae60" : "#c0392b" }
                                Text { text: model.fieldValue !== "" ? model.fieldValue : "—"
                                       font.pixelSize: 13; font.bold: model.fieldOk
                                       color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                       elide: Text.ElideRight; width: parent.width }
                            }
                            Text {
                                anchors.right: parent.right; anchors.top: parent.top
                                anchors.margins: 4
                                text: model.fieldType === "picker" ? "▾" : "✎"
                                color: "#5ba3ff"; font.pixelSize: 12
                            }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (model.fieldType === "picker") {
                                        plugin.activeFieldKey = model.fieldKey
                                        plugin.activeFieldOptions = model.fieldOptions
                                        pickerTitle.text = model.fieldLabel
                                        picker.visible = true
                                    } else {
                                        plugin.activeFieldKey = model.fieldKey
                                        freeTextLabel.text = model.fieldLabel
                                        freeTextField.text = model.fieldValue
                                        freeTextEditor.visible = true
                                    }
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Bottone foto
                Rectangle {
                    Layout.fillWidth: true
                    height: 52; radius: 8
                    color: fotoM.pressed ? "#1a3a5a" : (plugin.photo1Path !== "" ? "#0a2018" : "#22263a")
                    border.color: plugin.photo1Path !== "" ? "#27ae60" : "#3a3d50"
                    border.width: 1.5
                    Row {
                        anchors.centerIn: parent; spacing: 8
                        Text {
                            text: plugin.photo1Path !== "" ? "✅" : "📷"
                            font.pixelSize: 20
                            anchors.verticalCenter: parent.verticalCenter
                        }
                        Text {
                            text: plugin.photo1Path !== "" ? "Foto acquisita ✔" : "Scatta foto"
                            color: plugin.photo1Path !== "" ? "#a8f0c6" : "#8890a8"
                            font.pixelSize: 14
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                    MouseArea {
                        id: fotoM; anchors.fill: parent
                        onClicked: {
                            platformUtilities.createDir(qgisProject.homePath, "DCIM")
                            // Invia broadcast Android che MacroDroid intercetta
                            // come trigger "Intento ricevuto"
                            Qt.openUrlExternally("intent://pte.plugin.FOTO_SCATTA#Intent;scheme=pte;end")
                            cameraLoader.active = true
                        }
                    }
                }

                                Text {
                    Layout.fillWidth: true
                    text: "💬 Di' \"conferma\" per salvare"
                    color: "#5ba3ff"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                RowLayout {
                    Layout.fillWidth: true; spacing: 8
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cM.pressed ? "#2a2d40" : "#22263a"; border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"
                               color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea { id: cM; anchors.fill: parent; onClicked: resetData() }
                    }
                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0 ? (okM.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text { anchors.centerIn: parent; text: "✔ CONFERMA"
                               color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                               font.pixelSize: 14; font.bold: true }
                        MouseArea {
                            id: okM; anchors.fill: parent
                            onClicked: saveToLayer()
                        }
                    }
                }
            }
        }
    }

    // ── LINE OVERLAY ─────────────────────────────────────────────
    Rectangle {
        id: lineOverlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9990; color: "#88000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.9, 500)
            height: lineInfoCol.implicitHeight + 32
            color: "#1a1d27"; radius: 12

            Column {
                id: lineInfoCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: parent.top; anchors.margins: 16
                spacing: 10

                Text {
                    width: parent.width
                    text: plugin.currentLineDef ? plugin.currentLineDef.icon + " " + plugin.currentLineDef.label : ""
                    color: "#5ba3ff"; font.pixelSize: 17; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    id: gpsLineText
                    width: parent.width
                    text: "📍 —"; color: "#8890a8"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }

                // Stato punti
                Text {
                    width: parent.width
                    text: plugin.linePoints.length === 0
                        ? "Premi BT e di' "punto iniziale""
                        : plugin.linePoints.length === 1
                        ? "✅ Punto iniziale salvato
Premi BT e di' "vertice" o "fine""
                        : "✅ " + plugin.linePoints.length + " punti
Premi BT e di' "vertice" o "fine""
                    color: "#e8eaf0"; font.pixelSize: 14
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.Wrap
                }

                // Punti salvati
                Repeater {
                    model: plugin.linePoints.length
                    delegate: Text {
                        width: parent ? parent.width : 0
                        text: (index === 0 ? "🟢 Inizio" :
                               index === plugin.linePoints.length - 1 ? "🔴 Ultimo" : "🔵 Vertice " + index) +
                              ": " + plugin.linePoints[index].x.toFixed(4) + ", " + plugin.linePoints[index].y.toFixed(4)
                        color: "#8890a8"; font.pixelSize: 11
                        horizontalAlignment: Text.AlignHCenter
                    }
                }

                // Bottone annulla
                Rectangle {
                    width: parent.width; height: 44; radius: 8
                    color: annullaLineM.pressed ? "#3a1a1a" : "#22263a"
                    border.color: "#e74c3c"; border.width: 1
                    Text { anchors.centerIn: parent; text: "✕ Annulla"; color: "#e74c3c"; font.pixelSize: 14 }
                    MouseArea {
                        id: annullaLineM; anchors.fill: parent
                        onClicked: {
                            plugin.lineMode = false
                            plugin.linePoints = []
                            lineOverlay.visible = false
                        }
                    }
                }
            }
        }
    }

    // ── VOICE OVERLAY PER VERTICI ────────────────────────────────
    Rectangle {
        id: lineVoiceOverlay
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 9995; color: "#cc000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.88, 480)
            height: 200; color: "#1a1d27"; radius: 12

            Column {
                anchors.fill: parent; anchors.margins: 16; spacing: 12

                Text {
                    width: parent.width
                    text: plugin.linePoints.length === 0
                        ? "Di' "punto iniziale""
                        : "Di' "vertice" o "fine""
                    color: "#5ba3ff"; font.pixelSize: 16; font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: lineVoiceInput.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextArea {
                        id: lineVoiceInput
                        anchors.fill: parent; anchors.margins: 8
                        placeholderText: "🎤 Parla..."
                        color: "#e8eaf0"; font.pixelSize: 14; background: null
                        onTextChanged: {
                            if (text.length > 1) lineVoiceTimer.restart()
                        }
                    }
                }

                Timer {
                    id: lineVoiceTimer
                    interval: 600; repeat: false
                    onTriggered: processLineVoice(lineVoiceInput.text)
                }

                // Polling
                Timer {
                    interval: 500; repeat: true
                    running: lineVoiceOverlay.visible
                    onTriggered: {
                        if (lineVoiceInput.text.length > 1)
                            lineVoiceTimer.restart()
                    }
                }

                Text {
                    width: parent.width
                    text: ""punto iniziale" • "vertice" • "fine""
                    color: "#8890a8"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                }
            }
        }
    }

    Timer {
        id: lineVoiceFocusTimer
        interval: 300; repeat: false
        onTriggered: {
            lineVoiceInput.text = ""
            lineVoiceInput.forceActiveFocus()
            Qt.inputMethod.show()
        }
    }

    // ── PICKER ──────────────────────────────────────────────────
    Rectangle {
        id: picker
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: picker.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: Math.min(pickerList.contentHeight + 80, parent.height * 0.75)
            color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 12; spacing: 0
                Text { id: pickerTitle; width: parent.width; height: 36
                       color: "#5ba3ff"; font.pixelSize: 15; font.bold: true
                       verticalAlignment: Text.AlignVCenter }
                ListView {
                    id: pickerList
                    width: parent.width
                    height: parent.parent.height - 80
                    model: plugin.activeFieldOptions; clip: true
                    delegate: Rectangle {
                        width: parent ? parent.width : 0; height: 48; radius: 6
                        color: itemMA.pressed ? "#22263a" : "transparent"
                        border.color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#27ae60" : "transparent"
                        border.width: 1.5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left; anchors.leftMargin: 12
                            text: modelData; font.pixelSize: 14
                            color: plugin.parsedData[plugin.activeFieldKey] === modelData ? "#a8f0c6" : "#e8eaf0"
                            font.bold: plugin.parsedData[plugin.activeFieldKey] === modelData
                        }
                        MouseArea {
                            id: itemMA; anchors.fill: parent
                            onClicked: {
                                var d = plugin.parsedData
                                d[plugin.activeFieldKey] = modelData
                                plugin.parsedData = d
                                var n = 0
                                for (var k in d) if (d[k] !== "") n++
                                plugin.okCount = n
                                fieldsModel.refresh()
                                picker.visible = false
                            }
                        }
                    }
                }
            }
        }
    }

    // ── EDITOR TESTO LIBERO ─────────────────────────────────────
    Rectangle {
        id: freeTextEditor
        visible: false; x: 0; y: 0
        width: parent ? parent.width : 0
        height: parent ? parent.height : 0
        z: 10000; color: "#cc000000"
        MouseArea { anchors.fill: parent; onClicked: freeTextEditor.visible = false }
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width * 0.85, 420)
            height: 190; color: "#1a1d27"; radius: 12
            Column {
                anchors.fill: parent; anchors.margins: 14; spacing: 10
                Text { id: freeTextLabel; color: "#5ba3ff"; font.pixelSize: 15; font.bold: true }
                Rectangle {
                    width: parent.width; height: 52
                    color: "#22263a"; radius: 8
                    border.color: freeTextField.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    TextField {
                        id: freeTextField
                        anchors.fill: parent; anchors.margins: 8
                        color: "#e8eaf0"; background: null; font.pixelSize: 16
                    }
                }
                Rectangle {
                    width: parent.width; height: 46; radius: 8
                    color: saveFreeM.pressed ? "#178a3e" : "#1db954"
                    Text { anchors.centerIn: parent; text: "✔ OK"
                           color: "white"; font.pixelSize: 15; font.bold: true }
                    MouseArea {
                        id: saveFreeM; anchors.fill: parent
                        onClicked: {
                            var d = plugin.parsedData
                            d[plugin.activeFieldKey] = freeTextField.text
                            plugin.parsedData = d
                            var n = 0
                            for (var k in d) if (d[k] !== "") n++
                            plugin.okCount = n
                            fieldsModel.refresh()
                            freeTextEditor.visible = false
                        }
                    }
                }
            }
        }
    }

    // Camera loader - metodo esatto plugin snap ufficiale
    Loader {
        id: cameraLoader
        active: false
        sourceComponent: Component {
            QFieldItems.QFieldCamera {
                visible: false
                Component.onCompleted: open()
                onFinished: function(path) {
                    close()
                    var today = new Date()
                    var filename = "DCIM/pte_" +
                        today.getFullYear() +
                        (today.getMonth()+1).toString().padStart(2,"0") +
                        today.getDate().toString().padStart(2,"0") + "_" +
                        today.getHours().toString().padStart(2,"0") +
                        today.getMinutes().toString().padStart(2,"0") +
                        today.getSeconds().toString().padStart(2,"0") +
                        "." + FileUtils.fileSuffix(path)
                    platformUtilities.renameFile(path, qgisProject.homePath + "/" + filename)
                    plugin.photo1Path = filename
                    mainWindow.displayToast("📷 Foto acquisita!")
                }
                onCanceled: close()
                onClosed: cameraLoader.active = false
            }
        }
    }

    // Timer per auto-salvataggio e chiusura form
    Timer {
        id: autoSaveTimer
        interval: 300
        repeat: false
        onTriggered: {
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureForm.save()
            drawer.close()
            mainWindow.displayToast("✅ " + plugin.selectedLayerName + " salvato!")
            closeAll()
        }
    }

    // ── MODEL ───────────────────────────────────────────────────
    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var fd  = plugin.currentFields[i]
                var val = plugin.parsedData[fd.key] || ""
                append({
                    fieldLabel:   fd.label,
                    fieldKey:     fd.key,
                    fieldValue:   val,
                    fieldOk:      val !== "",
                    fieldType:    fd.type,
                    fieldOptions: fd.options || []
                })
            }
        }
        Component.onCompleted: refresh()
    }

    // ── FUNZIONI ────────────────────────────────────────────────
    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"; return
            }
        }
        gpsText.text = "⚠ GPS non attivo"; gpsText.color = "#e74c3c"
    }

    function parseText(raw) {
        var t = raw.toLowerCase()
        var d = {}

        for (var i = 0; i < plugin.currentFields.length; i++) {
            var fd = plugin.currentFields[i]
            d[fd.key] = plugin.parsedData[fd.key] || ""

            if (fd.type === "picker" && fd.options) {
                // Cerca corrispondenza tra le opzioni
                for (var j = 0; j < fd.options.length; j++) {
                    if (t.indexOf(fd.options[j].toLowerCase()) !== -1) {
                        d[fd.key] = fd.options[j]; break
                    }
                }
                // Sinonimi speciali per PTE
                if (fd.key === "STATO_1") {
                    if (t.indexOf("non realizzato") !== -1 || t.indexOf("non fatto") !== -1)
                        d[fd.key] = "NON Realizzato"
                    else if (t.indexOf("realizzato") !== -1 || t.indexOf("nuovo") !== -1)
                        d[fd.key] = "Realizzato"
                    else if (t.indexOf("esistente") !== -1 || t.indexOf("presente") !== -1)
                        d[fd.key] = "Esistente"
                }
                if (fd.key === "DESCRIPTIO" && plugin.selectedLayerName === "PTE") {
                    if (t.indexOf("muro esterno") !== -1 || t.indexOf("palifica") !== -1)
                        d[fd.key] = "PTE Muro Esterno/Palifica"
                    else if (t.indexOf("sotterraneo") !== -1)
                        d[fd.key] = "PTE Sotterraneo"
                    else if (t.indexOf("colonnina") !== -1)
                        d[fd.key] = "PTE Colonnina"
                    else if (t.indexOf("interno") !== -1)
                        d[fd.key] = "PTE Interno"
                }
            } else if (fd.type === "text") {
                // Estrai numero dopo keyword
                var kw = fd.label.toLowerCase()
                var m  = t.match(new RegExp(kw + "\\s+(\\d+)"))
                if (m) d[fd.key] = m[1]
            }
        }

        plugin.parsedData = d
        var n = 0
        for (var k in d) if (d[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    function processLineVoice(text) {
        var t = text.toLowerCase()
        var pos = positionSource.projectedPosition

        lineVoiceOverlay.visible = false
        lineVoiceInput.text = ""
        Qt.inputMethod.hide()

        if (t.indexOf("iniziale") !== -1 || t.indexOf("primo") !== -1 ||
            t.indexOf("partenza") !== -1 || t.indexOf("inizio") !== -1) {
            // Punto iniziale
            plugin.linePoints = [{ x: pos.x, y: pos.y }]
            mainWindow.displayToast("🟢 Punto iniziale salvato!")
            updateLineGPS()

        } else if (t.indexOf("vertice") !== -1 || t.indexOf("intermedio") !== -1 ||
                   t.indexOf("punto") !== -1 || t.indexOf("aggiunto") !== -1) {
            // Vertice intermedio
            if (plugin.linePoints.length === 0) {
                mainWindow.displayToast("⚠ Prima di' 'punto iniziale'!")
                lineOverlay.visible = true
                return
            }
            var pts = plugin.linePoints
            pts.push({ x: pos.x, y: pos.y })
            plugin.linePoints = pts
            mainWindow.displayToast("🔵 Vertice " + (plugin.linePoints.length - 1) + " salvato!")
            updateLineGPS()

        } else if (t.indexOf("fine") !== -1 || t.indexOf("ultimo") !== -1 ||
                   t.indexOf("arrivo") !== -1 || t.indexOf("finale") !== -1) {
            // Punto finale → salva linea e apri form
            if (plugin.linePoints.length < 1) {
                mainWindow.displayToast("⚠ Prima di' 'punto iniziale'!")
                lineOverlay.visible = true
                return
            }
            var pts2 = plugin.linePoints
            pts2.push({ x: pos.x, y: pos.y })
            plugin.linePoints = pts2
            mainWindow.displayToast("🔴 Punto finale! Apertura form...")
            saveLineFeature()

        } else {
            mainWindow.displayToast("⚠ Di' 'punto iniziale', 'vertice' o 'fine'")
            lineOverlay.visible = true
        }
    }

    function updateLineGPS() {
        lineOverlay.visible = true
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid)
                gpsLineText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
        }
    }

    function calcLineLength(points) {
        if (points.length < 2) return 0
        var total = 0
        for (var i = 1; i < points.length; i++) {
            var dx = points[i].x - points[i-1].x
            var dy = points[i].y - points[i-1].y
            total += Math.sqrt(dx*dx + dy*dy)
        }
        return Math.round(total * 100) / 100
    }

    function saveLineFeature() {
        lineOverlay.visible = false
        var layer = plugin.selectedLayer
        if (!layer) layer = dashBoard ? dashBoard.activeLayer : null
        if (!layer) { mainWindow.displayToast("⚠ Layer non trovato!"); return }

        try {
            // Costruisci WKT linestring
            var wktPoints = []
            for (var i = 0; i < plugin.linePoints.length; i++) {
                wktPoints.push(plugin.linePoints[i].x + " " + plugin.linePoints[i].y)
            }
            var wkt = "LINESTRING(" + wktPoints.join(", ") + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)

            // Calcola lunghezza automatica
            var lunghezza = calcLineLength(plugin.linePoints)
            var fieldNames = feature.fields.names

            // Imposta LUNGHEZZA se esiste
            var liIdx = fieldNames.indexOf("LUNGHEZZA")
            if (liIdx < 0) liIdx = fieldNames.indexOf("lunghezza")
            if (liIdx < 0) liIdx = fieldNames.indexOf("LENGTH")
            if (liIdx >= 0) feature.setAttribute(liIdx, lunghezza)

            // Imposta campi vocali compilati
            var d = plugin.parsedData
            for (var j = 0; j < plugin.currentFields.length; j++) {
                var val = d[plugin.currentFields[j].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[j].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }

            // Apri form con feature precompilata
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()

            // Reset
            plugin.lineMode = false
            plugin.linePoints = []
            plugin.currentLineDef = null
            resetData()

        } catch(e) {
            mainWindow.displayToast("ERRORE linea: " + e)
        }
    }

    function saveToLayer() {
        Qt.inputMethod.hide()
        var layer = findLayer(plugin.selectedLayerName)
        if (!layer) {
            mainWindow.displayToast("⚠ Seleziona " + plugin.selectedLayerName + " nel pannello")
            return
        }
        if (!positionSource || !positionSource.active) {
            mainWindow.displayToast("⚠ GPS non attivo!"); return
        }
        try {
            var pos = positionSource.projectedPosition
            var wkt = "POINT(" + pos.x + " " + pos.y + ")"
            var geometry = GeometryUtils.createGeometryFromWkt(wkt)
            var feature = FeatureUtils.createFeature(layer, geometry)
            var d = plugin.parsedData
            var fieldNames = feature.fields.names
            for (var i = 0; i < plugin.currentFields.length; i++) {
                var val = d[plugin.currentFields[i].key]
                if (val && val !== "") {
                    var idx2 = fieldNames.indexOf(plugin.currentFields[i].key)
                    if (idx2 >= 0) feature.setAttribute(idx2, val)
                }
            }
            // Aggiungi foto se presente
            if (plugin.photo1Path !== "") {
                var fi = fieldNames.indexOf("Foto_1")
                if (fi >= 0) feature.setAttribute(fi, plugin.photo1Path)
            }
            // Salva tramite drawer (metodo che funziona)
            var drawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
            drawer.featureModel.currentLayer = layer
            drawer.featureModel.feature = feature
            drawer.featureModel.applyGeometry()
            drawer.state = "Add"
            drawer.open()
            autoSaveTimer.start()
            overlay.visible = false
            resetData()
        } catch(e) {
            mainWindow.displayToast("ERRORE: " + e)
        }
    }
}
