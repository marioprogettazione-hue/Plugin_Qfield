import QtQuick
import org.qfield
import Theme

Item {
    id: plugin

    QfToolButton {
        id: micBtn
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: {
            iface.mainWindow().displayToast("PTE Voice Parser attivo!")
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
    }
}
