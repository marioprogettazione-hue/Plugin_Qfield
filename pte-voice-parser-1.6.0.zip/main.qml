import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var positionSource: iface.findItemByObjectName('positionSource')
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var overlayFeatureFormDrawer: iface.findItemByObjectName('overlayFeatureFormDrawer')

    property int okCount: 0
    property var parsedData: ({
        stato:"", tipologia:"", quartina:"",
        armadio:"", tipo:"", cavi_attestati:"",
        ubicazione:"", note:""
    })

    property var fieldDefs: [
        { key:"stato",          label:"STATO" },
        { key:"tipologia",      label:"TIPOLOGIA" },
        { key:"quartina",       label:"QUARTINA" },
        { key:"armadio",        label:"ARMADIO" },
        { key:"tipo",           label:"TIPO" },
        { key:"cavi_attestati", label:"CAVI" },
        { key:"ubicazione",     label:"UBICAZIONE" },
        { key:"note",           label:"NOTE" }
    ]

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(micBtn)
    }

    QfToolButton {
        id: micBtn
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_microphone_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            pteDrawer.open()
        }
    }

    // ── Drawer laterale — stesso approccio dei plugin ufficiali ──
    QFieldItems.QFieldDrawer {
        id: pteDrawer

        width: Math.min(mainWindow.width, mainWindow.height) > 600
               ? mainWindow.width * 0.5 : mainWindow.width
        height: mainWindow.height

        edge: Qt.RightEdge

        Rectangle {
            anchors.fill: parent
            color: "#1a1d27"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 14
                spacing: 10

                // Header
                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: "⚡ PTE Voice Parser"
                        color: "#5ba3ff"
                        font.pixelSize: 17
                        font.bold: true
                        Layout.fillWidth: true
                    }
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        color: xMouse.pressed ? "#3a1a1a" : "#22263a"
                        Text { anchors.centerIn: parent; text: "✕"; color: "#aaa"; font.pixelSize: 18 }
                        MouseArea { id: xMouse; anchors.fill: parent; onClicked: pteDrawer.close() }
                    }
                }

                // GPS info
                Rectangle {
                    Layout.fillWidth: true
                    height: 36
                    color: "#22263a"
                    radius: 6
                    Text {
                        id: gpsText
                        anchors.centerIn: parent
                        text: "📍 Premi per aggiornare GPS"
                        color: "#8890a8"
                        font.pixelSize: 11
                    }
                    MouseArea {
                        anchors.fill: parent
                        onClicked: updateGPS()
                    }
                }

                // Input vocale
                Rectangle {
                    Layout.fillWidth: true
                    height: 80
                    color: "#22263a"
                    radius: 8
                    border.color: inputArea.activeFocus ? "#3d8ef0" : "#3a3d50"
                    border.width: 2
                    ScrollView {
                        anchors.fill: parent
                        anchors.margins: 8
                        TextArea {
                            id: inputArea
                            placeholderText: "Usa 🎤 tastiera:\nrealizzato muro esterno quartina 14 armadio 6 transito due cavi palo"
                            color: "#e8eaf0"
                            wrapMode: TextArea.Wrap
                            font.pixelSize: 12
                            background: null
                            onTextChanged: if (text.length > 2) plugin.parseText(text)
                        }
                    }
                }

                // Contatore
                Text {
                    Layout.fillWidth: true
                    text: plugin.okCount + " / 8 campi ✔"
                    color: plugin.okCount >= 5 ? "#2ecc71"
                         : plugin.okCount >= 2 ? "#f39c12" : "#8890a8"
                    font.pixelSize: 12; font.bold: true
                    horizontalAlignment: Text.AlignRight
                }

                // Griglia campi
                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    columnSpacing: 6; rowSpacing: 6
                    Repeater {
                        model: fieldsModel
                        delegate: Rectangle {
                            Layout.fillWidth: true
                            height: 50; radius: 7
                            color:  model.fieldOk ? "#0a2018" : "#200a0a"
                            border.color: model.fieldOk ? "#27ae60" : "#7f1a1a"
                            border.width: 1.5
                            Column {
                                anchors.fill: parent
                                anchors.margins: 6
                                spacing: 2
                                Text {
                                    text: model.fieldLabel
                                    font.pixelSize: 9; font.bold: true
                                    color: model.fieldOk ? "#27ae60" : "#c0392b"
                                }
                                Text {
                                    text: model.fieldValue !== "" ? model.fieldValue : "—"
                                    font.pixelSize: 13; font.bold: model.fieldOk
                                    color: model.fieldOk ? "#a8f0c6" : "#e57373"
                                    elide: Text.ElideRight; width: parent.width
                                }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Bottoni
                RowLayout {
                    Layout.fillWidth: true; spacing: 8

                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: cancelMouse.pressed ? "#2a2d40" : "#22263a"
                        border.color: "#3a3d50"
                        Text { anchors.centerIn: parent; text: "✕ Cancella"; color: "#8890a8"; font.pixelSize: 14 }
                        MouseArea {
                            id: cancelMouse; anchors.fill: parent
                            onClicked: {
                                inputArea.text = ""
                                plugin.parsedData = { stato:"",tipologia:"",quartina:"",
                                    armadio:"",tipo:"",cavi_attestati:"",ubicazione:"",note:"" }
                                plugin.okCount = 0
                                fieldsModel.refresh()
                            }
                        }
                    }

                    Rectangle {
                        height: 48; Layout.fillWidth: true; radius: 8
                        color: plugin.okCount > 0
                            ? (confirmMouse.pressed ? "#178a3e" : "#1db954") : "#2a3a2a"
                        Text {
                            anchors.centerIn: parent; text: "✔ CONFERMA"
                            color: plugin.okCount > 0 ? "white" : "#4a6a4a"
                            font.pixelSize: 14; font.bold: true
                        }
                        MouseArea {
                            id: confirmMouse; anchors.fill: parent
                            enabled: plugin.okCount > 0
                            onClicked: { applyToLayer(); pteDrawer.close() }
                        }
                    }
                }
            }
        }
    }

    // ── Funzioni ─────────────────────────────────────────────────
    function updateGPS() {
        if (positionSource && positionSource.active) {
            var info = positionSource.positionInformation
            if (info.latitudeValid && info.longitudeValid) {
                gpsText.text = "📍 " + info.latitude.toFixed(5) + ", " + info.longitude.toFixed(5)
                gpsText.color = "#2ecc71"
                return
            }
        }
        gpsText.text = "⚠ GPS non attivo"
        gpsText.color = "#e74c3c"
    }

    function normalize(t) {
        t = t.toLowerCase()
        var fixes = [["muore esterno","muro esterno"],["moresterno","muro esterno"],["cavie","cavi"]]
        for (var i = 0; i < fixes.length; i++)
            t = t.split(fixes[i][0]).join(fixes[i][1])
        return t
    }

    function findValue(text, key) {
        var map = {
            "stato": [
                ["realizzato",     ["realizzato","realizzata","nuovo","nuova"]],
                ["esistente",      ["esistente","presente"]],
                ["non realizzato", ["non realizzato","non fatto"]],
                ["da progettare",  ["da progettare"]]
            ],
            "tipologia": [
                ["muro esterno",     ["muro esterno","facciata","su muro"]],
                ["interno edificio", ["interno edificio"]],
                ["muro interno",     ["muro interno"]],
                ["colonnina",        ["colonnina"]],
                ["sotterraneo",      ["sotterraneo","sottoterra"]]
            ],
            "tipo": [
                ["transito",  ["transito","passante"]],
                ["terminale", ["terminale","finale"]]
            ],
            "ubicazione": [
                ["palo",          ["palo","su palo"]],
                ["pozzetto",      ["pozzetto"]],
                ["marciapiede",   ["marciapiede"]],
                ["androne",       ["androne"]],
                ["cortile",       ["cortile"]],
                ["incassato",     ["incassato"]],
                ["intercapedine", ["intercapedine"]],
                ["sottoscala",    ["sottoscala"]],
                ["seminterrato",  ["seminterrato"]],
                ["centralino",    ["centralino"]]
            ]
        }
        var list = map[key] || []
        for (var i = 0; i < list.length; i++) {
            var syns = list[i][1]
            for (var j = 0; j < syns.length; j++)
                if (text.indexOf(syns[j]) !== -1) return list[i][0]
        }
        return ""
    }

    function extractQuartina(text) {
        var m = text.match(/da\s+(\d+)\s+a\s+(\d+)/)
        if (m) return m[1] + ":" + m[2]
        m = text.match(/quartina\s+(\d+)/)
        return m ? m[1] : ""
    }

    function extractNumber(text, keyword) {
        var m = text.match(new RegExp(keyword + "\\s+(\\d+)"))
        return m ? m[1] : ""
    }

    function extractCavi(text) {
        var numeri = {"uno":1,"una":1,"due":2,"tre":3,"quattro":4,
                      "cinque":5,"sei":6,"sette":7,"otto":8,"nove":9,"dieci":10}
        var m = text.match(/(\d+)\s+cavi/)
        if (m) return m[1]
        for (var k in numeri)
            if (text.indexOf(k + " cavi") !== -1) return String(numeri[k])
        return ""
    }

    function extractNote(text) {
        var m = text.match(/note[:\s]+(.+)/)
        return m ? m[1].trim() : ""
    }

    function parseText(raw) {
        var t = normalize(raw)
        var result = {
            stato: findValue(t,"stato"), tipologia: findValue(t,"tipologia"),
            quartina: extractQuartina(t), armadio: extractNumber(t,"armadio"),
            tipo: findValue(t,"tipo"), cavi_attestati: extractCavi(t),
            ubicazione: findValue(t,"ubicazione"), note: extractNote(t)
        }
        plugin.parsedData = result
        var n = 0
        for (var k in result) if (result[k] !== "") n++
        plugin.okCount = n
        fieldsModel.refresh()
    }

    ListModel {
        id: fieldsModel
        function refresh() {
            clear()
            for (var i = 0; i < plugin.fieldDefs.length; i++) {
                var fd = plugin.fieldDefs[i]
                var val = plugin.parsedData[fd.key] || ""
                append({ fieldLabel:fd.label, fieldKey:fd.key, fieldValue:val, fieldOk:val !== "" })
            }
        }
        Component.onCompleted: refresh()
    }

    function applyToLayer() {
        var layer = dashBoard.activeLayer
        if (!layer) { mainWindow.displayToast("⚠ Nessun layer attivo!"); return }

        updateGPS()
        var info = positionSource ? positionSource.positionInformation : null
        if (!info || !info.latitudeValid) { mainWindow.displayToast("⚠ GPS non valido!"); return }

        // Crea geometria punto
        var pos = GeometryUtils.reprojectPoint(
            positionSource.projectedPosition,
            positionSource.coordinateTransformer.destinationCrs,
            layer.crs
        )
        var wkt = 'POINT(' + pos.x + ' ' + pos.y + ')'
        var geometry = GeometryUtils.createGeometryFromWkt(wkt)
        var feature = FeatureUtils.createBlankFeature(layer.fields, geometry)

        // Applica attributi
        var d = plugin.parsedData
        var keys = ["stato","tipologia","quartina","armadio","tipo","cavi_attestati","ubicazione","note"]
        for (var i = 0; i < keys.length; i++) {
            var val = d[keys[i]]
            if (val && val !== "") {
                var idx = feature.fields.names.indexOf(keys[i])
                if (idx >= 0) feature.setAttribute(idx, val)
            }
        }

        // Apri il form di QField con la feature già compilata
        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.featureModel.resetAttributes(true)
        overlayFeatureFormDrawer.state = 'Add'
        overlayFeatureFormDrawer.open()

        mainWindow.displayToast("✅ Feature creata con " + plugin.okCount + " attributi")
    }
}
