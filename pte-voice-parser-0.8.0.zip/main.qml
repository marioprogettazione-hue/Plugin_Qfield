import QtQuick 2.14
import org.qfield 1.0

Item {
    id: root

    Timer {
        interval: 1500
        running: true
        repeat: false
        onTriggered: {
            iface.addItemToPluginsToolbar(micBtn)
            iface.mainWindow().displayToast("PTE 0.8 OK")
        }
    }

    QfToolButton {
        id: micBtn
        text: "PTE"
        onClicked: {
            iface.mainWindow().displayToast("Premi il mic sulla tastiera e parla!")
        }
    }
}
