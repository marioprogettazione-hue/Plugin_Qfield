import QtQuick 2.14
import QtQuick.Controls 2.14
import org.qfield 1.0

Item {
    id: root

    Timer {
        interval: 1500
        running: true
        repeat: false
        onTriggered: {
            iface.addItemToPluginsToolbar(micBtn)
            iface.mainWindow().displayToast("PTE 0.7 OK")
        }
    }

    QfToolButton {
        id: micBtn
        text: "PTE"
        onClicked: dialog.open()
    }

    QfDialog {
        id: dialog
        parent: iface.mainWindow()
        title: "PTE Voice Parser"
        width: parent.width * 0.9
        height: 300

        Column {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 10

            Text {
                text: "Digita il rilievo:"
                color: "white"
                font.pixelSize: 14
            }

            TextField {
                id: inputField
                width: parent.width
                placeholderText: "es: realizzato muro esterno quartina 14..."
                onTextChanged: statusText.text = "Testo: " + text.length + " car."
            }

            Text {
                id: statusText
                text: "In attesa..."
                color: "#aaaaaa"
                font.pixelSize: 12
            }

            Button {
                text: "CONFERMA"
                width: parent.width
                onClicked: {
                    iface.mainWindow().displayToast("Salvato: " + inputField.text)
                    dialog.close()
                }
            }
        }
    }
}
